<template>
  <v-app light v-scroll="onScroll">
    <navigation-bar v-if="!hideLayout.includes($route.path)" :offset-top="offsetTop" />
    <v-content :class="{'layout-padding': $route.path !== '/' && !hideLayout.includes($route.path)}">
      <nuxt/>
    </v-content>
  </v-app>
</template>

<script>
import NavigationBar from "~/components/NavigationBar.vue";
export default {
  components: {
    NavigationBar
  },
  data () {
    return {
      offsetTop: 0,
      hideLayout: ['/login', '/register']
    }
  },
  methods: {
    onScroll () {
      this.offsetTop = window.pageYOffset || document.documentElement.scrollTop
    },
  },
};
</script>
<style>
  .cursor--link {
    cursor: pointer;
  }
  .fixed--center {
    position: fixed;
    top: 50%;
    left: 50%;
  }
   .login-container {
    position: absolute;
    top:0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
  }

  .gramin-bg {
    background-image: url("/image/bg-landing-1.png");
    background-repeat: no-repeat;
    background-size: 100% 100%;
    height: 100vh;
  }

  .layout-padding {
    padding-top: 8vh !important;
  }
</style>

