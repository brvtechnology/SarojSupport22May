export default function (context) {
    const authRequiresRoutes = ['/profile']
    const noAuthRoutes = ['/login', '/register']
    const {route, redirect, store} = context
    const notAuthenticated = !store.getters['users/isLoggedIn']
    if (authRequiresRoutes.includes(route.path) && notAuthenticated) {
        redirect('/login')
    } else if (!notAuthenticated && noAuthRoutes.includes(route.path) ) {
        redirect('/')
    }
}
