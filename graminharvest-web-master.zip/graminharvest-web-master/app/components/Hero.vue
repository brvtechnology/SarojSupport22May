<template>
  <v-parallax src="/image/bg-landing-2.png" contain height="550">
    <v-carousel
      continuous
      cycle
      hide-delimiters
      hide-delimiter-background
      show-arrows-on-hover
    >
      <v-carousel-item
              v-for="(slide, i) in slides"
              :key="i"
      >
        <v-sheet
                color="transparent"
                height="100%"
                tile
        >
          <v-row
                  class="fill-height"
                  align="center"
                  justify="center"
          >
            <v-layout align-center column justify-center black--text>
              <h1 class="display-3 text-uppercase text-center font-weight-black my-2 titleAnim">{{slide.tagLine}}</h1>
              <h3 class="headline text-center">{{slide.tagLineDesc}}</h3>
              <v-btn v-if="slide.link" nuxt :to="slide.link.href" class="mt-2" color="grey darken-3">
                {{slide.link.title}}
              </v-btn>
            </v-layout>
          </v-row>
        </v-sheet>
      </v-carousel-item>
    </v-carousel>
  </v-parallax>
</template>

<script>
export default {
  data () {
    return {
      slides: [
        {
          tagLine: 'GO ORGANIC',
          tagLineDesc: 'Health is wealth - Eat natural, Eat organic'
        },
        {
          tagLine: 'Rural harvest',
          tagLineDesc: 'Buy fresh rural harvest products by graminharvest',
          link: {
            href: '/products/2',
            title: 'Buy'
          }
        }
      ]
    }
  },
  created() {
    if (!this.$store.getters['users/isLoggedIn']) {
      this.slides.push(
          {
            tagLine: 'WELCOME',
            tagLineDesc: 'Resister to get exciting offers and coupons',
            link: {
              href: '/register',
              title: 'Register'
            }
          }
      )
    }
  }
}
</script>


