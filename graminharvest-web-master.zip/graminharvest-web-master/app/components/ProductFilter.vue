<template>
    <v-card
       class="mx-auto"
    >
        <v-list>
            <v-subheader>Filters</v-subheader>
            <v-list-group
                    v-for="item in filters"
                    :key="item.title"
                    v-model="item.active"
            >
                <template v-slot:activator>
                    <v-list-item-content>
                        <v-list-item-title v-text="item.title"></v-list-item-title>
                    </v-list-item-content>
                </template>

                <v-list-item
                        v-if="item.filterType === 'select'"
                        v-for="subItem in item.items"
                        :key="subItem.title"
                        @click=""
                >
                    <v-list-item-action>
                        <v-checkbox color="primary" v-model="subItem.selected"></v-checkbox>
                    </v-list-item-action>

                    <v-list-item-content>
                        <v-list-item-title v-text="subItem.title"></v-list-item-title>
                    </v-list-item-content>
                </v-list-item>
                <v-range-slider
                    class="ma-5"
                    v-if="item.filterType === 'range'"
                    v-model="item.range"
                    :min="item.min"
                    :max="item.max"
                    thumb-label="always"
                ></v-range-slider>
            </v-list-group>
            <div class="ma-5">
                <v-btn block color="primary" @click="$emit('onApplyFilter', filters)">Apply filter</v-btn>
            </div>
        </v-list>
    </v-card>
</template>

<script>
    export default {
        name: "ProductFilter",
        props: {
            filters: Array
        },
        data () {
            return {

            }
        },
    }
</script>

<style scoped>

</style>
