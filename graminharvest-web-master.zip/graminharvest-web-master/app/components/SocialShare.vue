<template>
    <v-bottom-sheet :value="value" @input="$emit('input')" class="mb-5">
            <social-sharing
                    :url="getURL()"
                    :title="title"
                    :description="description"
                    :quote="title"
                    hashtags="gramin-harvest,organic"
                    twitter-user="gramin-harvest"
                    inline-template
            >
                <v-list>
                    <v-subheader>Share to</v-subheader>
                    <!-- Facebook -->
                    <network network="facebook">
                        <v-list-item @click="">
                                <v-list-item-avatar>
                                    <v-avatar size="32px" tile>
                                        <img src="../assets/icons/facebook.png" alt="facebook">
                                    </v-avatar>
                                </v-list-item-avatar>
                                <v-list-item-title>Facebook</v-list-item-title>
                        </v-list-item>
                    </network>
                    <!-- Twitter -->
                    <network network="twitter">
                        <v-list-item @click="">
                            <v-list-item-avatar>
                                <v-avatar size="32px" tile>
                                    <img src="../assets/icons/twitter.png" alt="twitter">
                                </v-avatar>
                            </v-list-item-avatar>
                            <v-list-item-title>Twitter</v-list-item-title>
                        </v-list-item>
                    </network>
                    <!-- Whatsapp -->
                    <network class="hidden-md-and-up" network="whatsapp">
                        <v-list-item @click="">
                            <v-list-item-avatar>
                                <v-avatar size="32px" tile>
                                    <img src="../assets/icons/whatsapp.png" alt="whatsapp">
                                </v-avatar>
                            </v-list-item-avatar>
                            <v-list-item-title>WhatsApp</v-list-item-title>
                        </v-list-item>
                    </network>
                    <!-- Email -->
                    <network network="email">
                        <v-list-item @click="">
                            <v-list-item-avatar>
                                <v-avatar size="32px" tile>
                                    <img src="../assets/icons/email.png" alt="email">
                                </v-avatar>
                            </v-list-item-avatar>
                            <v-list-item-title>Email</v-list-item-title>
                        </v-list-item>
                    </network>
                    <!-- SMS -->
                    <network class="hidden-md-and-up" network="sms">
                        <v-list-item @click="">
                            <v-list-item-avatar>
                                <v-avatar size="32px" tile>
                                    <img src="../assets/icons/sms.png" alt="sms">
                                </v-avatar>
                            </v-list-item-avatar>
                            <v-list-item-title>SMS</v-list-item-title>
                        </v-list-item>
                    </network>
                </v-list>
            </social-sharing>
        </v-bottom-sheet>
</template>

<script>
    export default {
        name: 'social-share',
        props: ['value', 'title', 'description'],
        data () {
            return {
                sheet: false
            }
        },
        methods: {
            getURL () {
                if (window.location.pathname === '/profile') {
                    return window.location.origin
                }
                return window.location.href
            }
        }
    }
</script>

<style scoped>

</style>
