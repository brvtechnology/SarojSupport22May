<template>
    <v-layout row justify-center>
        <v-container grid-list-md>
            <v-card flat>
                <v-card-text class="title pb-0 mb-0 text-center">Refer & Earn</v-card-text>
                <v-card-text class="text-center">
                    Share your refer code with a friend and get &#8377;20
                </v-card-text>
                <v-card-text class="display-1 pb-0 mb-0 text-center">{{referCode}}</v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn outlined color="primary" class="text-capitalize" @click="sharing = true">
                        <v-icon>share</v-icon>
                        Share
                    </v-btn>
                    <v-spacer></v-spacer>
                </v-card-actions>
            </v-card>
        </v-container>
        <social-share
                v-if="sharing === true" v-model="sharing"
                title="Eat natural, Eat organic"
                :description="message"
        ></social-share>
    </v-layout>
</template>

<script>
    export default {
        name: "Refer",
        props: {
            referCode: String,
        },
        data () {
            return {
                sharing: false,
                message: `Register on Graminharvest with ${this.referCode}`
            }
        },
    }
</script>

<style scoped>

</style>
