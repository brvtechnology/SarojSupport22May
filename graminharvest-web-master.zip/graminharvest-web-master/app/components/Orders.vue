<template>
    <v-layout row justify-center>
        <v-container
                class="pa-2"
                fluid
        >
            <v-row>
                <v-col>
                    <v-card v-for="i in 4" :key="i" class="mb-2">
                        <v-card-text>
                            <div class="headline mb-2">Raw Organic Nuts</div>
                            <div class="text-capitalize font-weight-bold subtitle-1">Oder id:
                                <span class="grey--text">ac864375-012e-447b-a330-99eb42068a32</span>
                            </div>
                            <div class="text-capitalize font-weight-bold subtitle-1">
                                Date <span class="mr-1 grey--text">21/08/2019</span>
                                Price <span class="mr-1 grey--text">&#x20b9;500</span>
                                Quantity <span class="mr-1 grey--text">1</span>
                            </div>
                        </v-card-text>
                    </v-card>
                </v-col>
            </v-row>
        </v-container>
    </v-layout>
</template>

<script>
    export default {
        name: "Orders.vue"
    }
</script>

<style scoped>

</style>
