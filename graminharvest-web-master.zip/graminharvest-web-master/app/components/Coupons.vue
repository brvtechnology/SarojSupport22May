<template>
    <v-row justify="center">
        <v-bottom-sheet :value="value" @input="$emit('input')">
            <v-card v-if="coupons && coupons.length > 0">
                <v-list two-line subheader>
                    <v-subheader>Available coupons</v-subheader>
                    <template v-for="(item, i) in coupons">
                        <v-list-item @click="applyCoupon(item)">
                            <v-list-item-content>
                                <v-list-item-title v-text="item.coupon_code"></v-list-item-title>
                                <v-list-item-subtitle v-text="item.description"></v-list-item-subtitle>
                            </v-list-item-content>

                            <v-list-item-action>
                                <v-btn text color="primary">Apply</v-btn>
                            </v-list-item-action>
                        </v-list-item>
                        <v-divider class="mx-4" v-if="i + 1 < coupons.length"></v-divider>
                    </template>
                </v-list>
            </v-card>
        </v-bottom-sheet>
    </v-row>
</template>

<script>
    import coupon from "../store/coupon";

    export default {
        name: "Coupons",
        props: {
            value: Boolean,
            totalAmount: Number
        },
        data () {
            return {
                coupons: []
            }
        },
        methods: {
            async getAvailableCoupons () {
                this.$emit('showCouponLoader', true)
                await this.$store.dispatch('coupon/getCoupons')
                let coupons = this.$store.state.coupon.coupons
                if (coupons && coupons.length > 0) {
                    this.coupons = coupons.filter(c => c.minimum_amount_to_apply < this.totalAmount)
                }
                this.$emit('showCouponLoader', false)
            },
            applyCoupon (coupon) {
                if (coupon.minimum_amount_to_apply > this.totalAmount) {
                    console.log('something went wrong, user is trying to apply not applicable coupon')
                    return
                }
                let totalCouponDiscount = coupon.type === 'percentage'
                        ? (this.totalAmount * coupon.coupon_amount) / 100
                        : coupon.coupon_amount
                coupon.totalCouponDiscount = coupon.type === 'percentage' ? Math.min(totalCouponDiscount, coupon.max_cashback) : totalCouponDiscount
                this.$emit('applyCoupon', coupon)
            }
        },
        async created() {
            await this.getAvailableCoupons()
        }
    }
</script>

<style scoped>

</style>
