<template>
    <section id="what" class="grey lighten-3">
      <v-container>
        <v-wait>
          <clip-loader slot="waiting" class="fixed--center" color="#43a047"></clip-loader>
          <v-layout row wrap py-5>
            <v-flex xs12 pa-4 text-center>
              <h2 class="headline text-uppercase my-1">{{title}}</h2>
              <div class="title font-weight-light grey--text text--lighten-1">{{subtitle}}</div>
            </v-flex>
              <v-flex v-if="productTypes.length > 0" v-for="(service, index) in productTypes" :key="index" xs12 md6 :class="{'py-2': $vuetify.breakpoint.smAndDown, 'pa-3': $vuetify.breakpoint.mdAndUp}">
                <v-hover>
                  <template v-slot:default="{ hover }">
                    <v-card  height="250" data-aos="fade-up">
                      <v-layout>
                        <v-flex xs5>
                          <v-img :src="service.info.image" height="250"> </v-img>
                        </v-flex>
                        <v-flex xs7>
                          <v-card-title primary-title>
                            <div>
                              <div class="title text-capitalize mb-2">{{ service.name }}</div>
                              <div class="grey--text subtitle-2 wrap-text">{{ service.info.desc }}</div>
                              <v-btn nuxt :to="`/products/${service.id}`" color="primary" class="text-capitalize mt-2" ripple>Buy {{service.name}}</v-btn>
                            </div>
                          </v-card-title>
                        </v-flex>
                      </v-layout>
                    </v-card>
                  </template>
                </v-hover>
              </v-flex>
          </v-layout>
        </v-wait>
      </v-container>
    </section>
</template>

<script>
import { mapState } from 'vuex'
import { waitFor } from 'vue-wait'

export default {
  data() {
    return {
      title: 'Organic products',
      subtitle: 'checkout our organic products catalog'
    }
  },
  methods: {
    getProductTypes: waitFor('getProductTypes', async function () {
      await this.$store.dispatch('product/getProductTypes')
    })
  },
  created () {
    this.getProductTypes()
  },
  computed: mapState('product', {
    productTypes: state => state.productTypes,
  })
}
</script>

<style scoped>
  .wrap-text {
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 6; /* number of lines to show */
    -webkit-box-orient: vertical;
  }
</style>
