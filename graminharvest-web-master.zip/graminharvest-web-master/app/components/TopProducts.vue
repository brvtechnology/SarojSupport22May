<template>
    <section id="projects" class="grey lighten-3">
      <v-container>
        <v-layout row wrap py-5>
          <v-flex xs12 pt-4 text-center>
            <h2 class="headline text-uppercase my-1">{{title}}</h2>
            <div class="title font-weight-light grey--text text--lighten-1">{{subtitle}}</div>
          </v-flex>
        </v-layout>
        <v-wait>
          <clip-loader slot="waiting" class="fixed--center" color="#43a047"></clip-loader>
          <v-layout row wrap pb-5>
            <v-flex xs12 sm10 offset-sm1 v-if="topProducts.length === 0">
              <v-card flat color="transparent">
                <v-card-text class="text-center grey--text">
                  <v-icon large>info</v-icon>
                  <div class="title font-weight-light pt-3">Products not available</div>
                </v-card-text>
              </v-card>
            </v-flex>
            <v-flex v-for="(product, index) in topProducts" :key="index.project" xs12 sm6 :class="{'py-2': $vuetify.breakpoint.xs, 'pa-2': $vuetify.breakpoint.sm, 'pa-3': $vuetify.breakpoint.mdAndUp}">
              <v-hover>
                <template v-slot:default="{ hover }">
                  <v-card data-aos="fade-up" height="400px">
                    <v-img class="white--text" height="200px" :src="product.image"></v-img>
                    <v-card-title primary-title>
                      <div>
                        <div class="title">{{ product.name }}</div>
                        <div class="pt-2 subtitle-2 grey--text wrap-text">{{ product.description }}</div>
                        <v-card-actions class="pl-0">
                          <div class="ml-1 grey--text text--darken-2">
                            <span class="text-capitalize font-weight-bold subtitle-1">&#x20b9;{{product.price}}</span>
                            <span>
                                <strike class="red--text subtitle-1">
                                     {{product.realPrice}}
                                </strike>
                            </span>
                            <span class="green--text ml-1 font-weight-bold subtitle-2" v-if="product.discount > 0">
                              {{product.discount}} {{product.discountType === 'Percentage' ? '%' : 'Rs'}} Off
                            </span>
                            <span class="grey--text ml-1 subtitle-1">
                              {{product.stock > 0 ? 'In stock' : 'Out of stock'}}
                            </span>
                          </div>
                        </v-card-actions>
                        <v-btn nuxt :to="`/product/${product.info.friendlyURL}`" color="primary" small ripple class="mt-1">Buy</v-btn>
                      </div>
                    </v-card-title>
                  </v-card>
                </template>
              </v-hover>
            </v-flex>
          </v-layout>
        </v-wait>
      </v-container>
    </section>
</template>

<script>
  import { waitFor } from 'vue-wait'
  export default {
    data() {
      return {
        isVisible: true,
        prevRatio: 0,
        title: 'Top products',
        subtitle: 'Our top products that are brought by our thousands of customer',
        topProducts: []
      }
    },
    methods: {
      getTopProducts: waitFor('getProducts', async function () {
        await this.$store.dispatch('product/getProducts')
        let products = this.$store.state.product.products
        if (products && products.length > 4) {
          products = JSON.parse(JSON.stringify(products))
          products = products.sort((p1, p2) => new Date(p2.createdAt).getTime() - new Date(p1.createdAt).getTime()).slice(0, 4)
        }
        this.topProducts = products
      })
    },
    created () {
      this.getTopProducts()
    }
  };
</script>
<style scoped>
  .wrap-text {
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2; /* number of lines to show */
    -webkit-box-orient: vertical;
  }
</style>

