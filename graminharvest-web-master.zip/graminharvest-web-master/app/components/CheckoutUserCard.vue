<template>
    <div class="pa-4 text-center">
        <v-subheader class="px-0">Contact & Delivery Details</v-subheader>
        <v-row class="fill-height" align="start" justify="start">
            <v-col cols="12" md="4" xl="2">
                <v-hover v-slot:default="{ hover }">
                    <v-card
                            :elevation="hover ? 12 : 2"
                            :class="{ 'on-hover': hover }"
                    >
                        <v-img
                                :src="require('../assets/image/contact_bg.jpg')"
                                height="225px"
                        >
                            <v-card-title class="title white--text ml-2">
                                <v-row
                                        class="fill-height flex-column"
                                        justify="space-between"
                                >
                                    <p class="mt-2 subheading text-left text-capitalize">{{ contact.name }}</p>

                                    <div>
                                        <p class="ma-0 body-1 font-weight-bold font-italic text-left">
                                            {{ contact.phone }}
                                        </p>
                                        <p class="caption font-weight-medium font-italic text-left">
                                            {{ contact.email }}
                                        </p>
                                        <p
                                            class="caption font-weight-medium font-italic text-left"
                                            v-html="getFormattedAddress()">
                                        </p>
                                    </div>
                                </v-row>
                            </v-card-title>
                        </v-img>
                    </v-card>
                </v-hover>
            </v-col>
        </v-row>
    </div>
</template>

<script>
    export default {
        name: "CheckoutUserCard",
        props: {
            contact: Object,
            address: Object
        },
        methods : {
            getFormattedAddress () {
                return `${this.address.address1}<br>
                        ${this.address.address2}<br>
                        ${this.address.city}, ${this.address.state}, ${this.address.pincode}<br>
                        ${this.address.landmark}`
            }
        }
    }
</script>

<style scoped>
    .v-card {
        transition: opacity .0s ease-in-out;
    }

    .v-card:not(.on-hover) {
        opacity: 1;
    }

    .show-btns {
        color: rgba(255, 255, 255, 1) !important;
    }
</style>
