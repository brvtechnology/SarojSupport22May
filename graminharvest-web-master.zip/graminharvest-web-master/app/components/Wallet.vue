<template>
    <v-container>
        <v-wait>
            <clip-loader slot="waiting" class="fixed--center" color="#43a047"></clip-loader>
            <v-card flat v-if="Object.keys(wallet).length > 0">
                <v-flex>
                    <v-card-text primary class="title text-center">
                        Available Balance<br/>&#8377;{{wallet.userDeposit + wallet.userPromoMoney}}
                    </v-card-text>
                </v-flex>
                <v-card-actions>
                    <v-flex class="d-flex justify-center text-center">
                        <v-list-item-action-text class="mr-3">Deposited<br/>&#8377;{{wallet.userDeposit}}</v-list-item-action-text>
                    </v-flex>
                    <v-flex class="d-flex justify-center text-center">
                        <v-list-item-action-text class="mr-3">Promo<br/>&#8377;{{wallet.userPromoMoney}}</v-list-item-action-text>
                    </v-flex>
                </v-card-actions>
                <v-card-text>
                    <div :style="{ 'display': 'block' }">
                        <v-form ref="form">
                            <v-flex xs10 offset-xs1 md6 offset-md3>
                                <v-text-field
                                        outlined
                                        placeholder="Add money to wallet"
                                        v-mask="walletMask"
                                        v-model="addMoney"
                                        :error-messages="depositErrorMsg"
                                ></v-text-field>
                            </v-flex>
                            <v-layout row wrap>
                                <v-flex xs10 offset-xs1 md6 offset-md3>
                                    <v-btn large @click="addMoneyToWallet" ripple class="primary white--text mb-4" :disabled="!addMoney">Add money</v-btn>
                                </v-flex>
                            </v-layout>
                        </v-form>
                    </div>
                </v-card-text>
            </v-card>
        </v-wait>
    </v-container>
</template>

<script>
    import { mask } from 'vue-the-mask'
    import { waitFor } from 'vue-wait'
    export default {
        name: "Wallet",
        directives: {
            mask,
        },
        data () {
            return {
                addMoney: '',
                walletMask: '######',
                wallet: {},
                depositErrorMsg: '',
            }
        },
        methods: {
            addMoneyToWallet () {
                if (this.addMoney < 10) {
                    this.depositErrorMsg = `You Need to Deposit At least 10 Rs`
                    return false
                }
                this.$store.dispatch('wallet/depositMoney', {amount: this.addMoney})
            },
            getWallet: waitFor('fetchWalletBalance', async function () {
                await this.$store.dispatch('wallet/getWallet')
                this.wallet = this.$store.state.wallet.wallet
            })
        },
        created() {
            this.getWallet()
        }
    }
</script>

<style scoped>

</style>
