<template>
    <v-banner class="mt-2 mx-2" elevation="5" :single-line="!$vuetify.breakpoint.smAndDown" sticky v-if="!$store.getters['users/isLoggedIn']">
        <v-icon
            slot="icon"
            color="warning"
            size="36"
        >
            notification_important
        </v-icon>
        Register & Get exciting offer & coupons on checkout
        <template v-slot:actions>
            <v-btn color="primary" text to="/register" class="text-capitalize">
                Register
            </v-btn>
        </template>
    </v-banner>
</template>

<script>
    export default {
        name: "RegisterBanner"
    }
</script>

<style scoped>

</style>
