<template>
  <v-container fluid grid-list-md>
    <v-layout row wrap>
      <v-dialog :value="value" @input="$emit('input')" fullscreen hide-overlay transition="dialog-bottom-transition">
        <v-card flat tile class="elevation-0">
          <!--Toolbar-->
          <v-toolbar flat dark color="primary">
            <v-btn text icon @click.native="$emit('input')">
              <v-icon>arrow_back</v-icon>
            </v-btn>
            <v-toolbar-title>Checkout</v-toolbar-title>
          </v-toolbar>
          <!-- Stepper -->
          <v-stepper v-model="checkoutStep" vertical>
            <v-stepper-step :complete="checkoutStep > 1" step="1">
              Contact Details
            </v-stepper-step>

            <v-stepper-content step="1">
              <v-card flat color="transparent">
                <v-form ref="contactForm" lazy-validation>
                  <v-container>
                    <v-layout row wrap>
                      <v-flex xs12 sm6>
                        <v-text-field
                          outlined
                          v-model="contact.name"
                          :rules="[rules.required, rules.name]"
                          label="Name"
                          append-icon="person"
                        ></v-text-field>

                        <v-text-field
                          outlined
                          v-model="contact.email"
                          :rules="[rules.required, rules.email]"
                          label="Email"
                          append-icon="email"
                        ></v-text-field>

                        <v-text-field
                          outlined
                          v-model="contact.phone"
                          mask="##########"
                          :rules="[rules.required, rules.phone]"
                          label="Phone"
                          append-icon="phone"
                        ></v-text-field>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-form>
              </v-card>
              <v-btn color="primary"  @click="submitContact()">Continue</v-btn>
              <v-btn text @click="$emit('input')">Cancel</v-btn>
            </v-stepper-content>

            <v-stepper-step :complete="checkoutStep > 2" step="2">
              Delivery Address
            </v-stepper-step>

            <v-stepper-content step="2">
              <v-card flat color="transparent">
                <v-form ref="addressForm" lazy-validation>
                  <v-container grid-list-md>
                    <v-layout wrap>
                      <v-flex xs12 sm6>
                        <v-text-field
                          v-model="address.address1"
                          :rules="[rules.required]"
                          label="Address 1"
                        ></v-text-field>
                      </v-flex>
                      <v-flex xs12 sm6>
                        <v-text-field
                          v-model="address.address2"
                          :rules="[rules.required]"
                          label="Address 2"
                        ></v-text-field>
                      </v-flex>
                      <v-flex xs12 sm6>
                        <v-text-field
                          v-model="address.city"
                          :rules="[rules.required, rules.name]"
                          label="City"
                        ></v-text-field>
                      </v-flex>
                      <v-flex xs12 sm6>
                        <v-autocomplete
                          v-model="address.state"
                          :rules="[rules.required]"
                          :items="states"
                          label="State"
                        ></v-autocomplete>.
                      </v-flex>
                      <v-flex xs12 sm6>
                        <v-text-field
                          v-model="address.pincode"
                          mask="######"
                          :rules="[rules.required, rules.pin]"
                          label="Pin Code"
                        ></v-text-field>
                      </v-flex>
                      <v-flex xs12 sm6>
                        <v-text-field
                          v-model="address.landmark"
                          label="Landmark"
                        ></v-text-field>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-form>
              </v-card>
              <v-btn color="primary" @click="submitAddress()">Continue</v-btn>
              <v-btn text @click="checkoutStep = 1">Back</v-btn>
            </v-stepper-content>

            <v-stepper-step :complete="checkoutStep > 3" step="3">
              Order Summary
            </v-stepper-step>

            <v-stepper-content step="3">
              <v-card flat color="transparent">
                <v-subheader>Product Details</v-subheader>
                <v-card-title class="py-0">
                  <div>
                    <v-card
                            class="mx-auto"
                            max-width="400"
                            flat
                    >
                      <template v-for="(p,i) in data.products">
                        <v-list-item three-line :key="i" class="px-0">
                          <v-list-item-content>
                            <v-list-item-title>{{p.name}}</v-list-item-title>
                            <v-list-item-subtitle>
                              Price &#x20b9; {{p.price}}
                            </v-list-item-subtitle>
                            <v-list-item-subtitle>
                              Quantity {{p.quantity}}
                            </v-list-item-subtitle>
                          </v-list-item-content>
                        </v-list-item>
                      </template>
                    </v-card>
                    <div v-if="totalWalletBalance > 0">
                      <v-checkbox
                              color="primary"
                              v-model="useWalletBalance"
                              :label="`Use ${totalWalletBalance} wallet balance`"
                      ></v-checkbox>
                    </div>
                    <div class="mb-3" v-if="$store.getters['users/isLoggedIn']">
                      <v-btn v-if="!appliedCoupon" :loading="showCouponsLoader" :disabled="showCouponsLoader" color="primary" @click="showCoupons = true">Apply coupon</v-btn>
                      <v-chip
                              class="ma-2"
                              close
                              color="primary"
                              label
                              text-color="white"
                              v-else
                              @click:close="appliedCoupon = null"
                      >
                        <v-icon left>free_breakfast</v-icon>
                        {{appliedCoupon.coupon_code}}
                      </v-chip>
                    </div>
                    <v-row class="row-margin-left">
                      <v-col cols="12">
                        <v-row align="start" justify="center">
                          <v-flex class="d-flex text-center" v-if="appliedCoupon">
                            <v-list-item-action-text class="mr-2">
                              <span class="subtitle-1 font-weight-bold green--text">&#8377;{{appliedCoupon.totalCouponDiscount}}</span>
                              <br/>
                              <span class="body-2 font-weight-bold">Coupon</span>
                            </v-list-item-action-text>
                          </v-flex>
                          <v-flex class="d-flex text-center" v-if="useWalletBalance">
                            <v-list-item-action-text class="mr-2">
                              <span class="subtitle-1 font-weight-bold green--text">&#8377;{{totalWalletBalance}}</span>
                              <br/>
                              <span class="body-2 font-weight-bold">Wallet</span>
                            </v-list-item-action-text>
                          </v-flex>
                          <v-flex class="d-flex text-center">
                            <v-list-item-action-text class="mr-2">
                              <span class="subtitle-1 font-weight-bold green--text">&#8377;{{deliveryCharge}}</span>
                              <br/>
                              <span class="body-2 font-weight-bold">Delivery Charges</span>
                            </v-list-item-action-text>
                          </v-flex>
                          <v-flex class="d-flex text-center" v-if="totalWalletBalance">
                            <v-list-item-action-text class="mr-2">
                              <span class="subtitle-1 font-weight-bold green--text">&#8377;{{getTotalAmount()}}</span>
                              <br/>
                              <span class="body-2 font-weight-bold">Total Amount</span>
                            </v-list-item-action-text>
                          </v-flex>
                          <v-flex class="d-flex text-center">
                            <v-list-item-action-text>
                              <span class="subtitle-1 font-weight-bold green--text">
                                &#8377;{{getPayableAmount()}}
                              </span>
                              <br/>
                              <span class="body-2 font-weight-bold">Payable Amount</span>
                            </v-list-item-action-text>
                          </v-flex>
                        </v-row>
                      </v-col>
                    </v-row>
                  </div>
                </v-card-title>
              </v-card>
              <CheckoutUserCard :contact="contact" :address="address" />
              <v-btn color="primary" @click="checkout()">Buy</v-btn>
              <v-btn text @click="checkoutStep = 2">Back</v-btn>
            </v-stepper-content>
          </v-stepper>
        </v-card>
      </v-dialog>
    </v-layout>
    <Coupons
            v-if="showCoupons"
            :totalAmount="getTotalAmount()"
            @showCouponLoader="onShowCouponsLoader"
            @applyCoupon="onApplyCoupon"
            v-model="showCoupons"
    />
  </v-container>
</template>

<script>
    import {isBangaloreZip} from '../api/pincode'
    import Coupons from "./Coupons";
    import CheckoutUserCard from "./CheckoutUserCard";
    export default {
      name: 'checkout',
      components: {CheckoutUserCard, Coupons},
      props: {
        value: Boolean,
        data: {
          type: Object,
          required: true
        },
        resetCart: Boolean
      },
      data () {
        return {
          deliveryCharge: 54,
          contact: {
            name: '',
            email: '',
            phone: ''
          },
          address: {
            address1: '',
            address2: '',
            city: '',
            state: '',
            pincode: '',
            landmark: ''
          },
          checkoutStep: 1,
          states: [
            'Andra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat',
            'Haryana', 'Himachal Pradesh', 'Jammu and Kashmir', 'Jharkhand', 'Karnataka', 'Kerala', 'Madya Pradesh',
            'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Orissa', 'Punjab', 'Rajasthan', 'Sikkim',
            'Tamil Nadu', 'Telagana', 'Tripura', 'Uttaranchal', 'Uttar Pradesh', 'West Bengal'
          ],
          rules: {
            required: value => !!value || 'Field is required.',
            name: value => value.length <= 30 || 'Max 30 characters',
            pin: value => value.length === 6 || 'Pincode should be 6 dight',
            phone: value => value.length === 10 || 'Phone number should be 10 dight',
            email: value => {
              const pattern = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
              return pattern.test(value) || 'Invalid e-mail.'
            }
          },
          totalWalletBalance: 0,
          useWalletBalance: false,
          showCoupons: false,
          showCouponsLoader: false,
          appliedCoupon: null
        }
      },
      methods: {
        submitContact () {
          if (this.$refs.contactForm.validate()) {
            this.checkoutStep = 2
          }
        },
        onShowCouponsLoader (val) {
          this.showCouponsLoader = val
        },
        onApplyCoupon (coupon) {
          this.appliedCoupon = coupon
          this.showCoupons = false
        },
        submitAddress () {
          if (this.$refs.addressForm.validate()) {
            let isBlr = isBangaloreZip(this.address.pincode)
            this.deliveryCharge = isBlr ? 35 : 54
            this.checkoutStep = 3
          }
        },
        async checkout () {
          let orders = this.data.products.map(p => {
            return {
              id: p.id,
              quantity: p.quantity
            }
          })
          let info = {
            orders,
          }

          let payload = {
            contact: this.contact,
            address: this.address,
            useWalletBalance: this.useWalletBalance,
            info,
          }
          if (this.appliedCoupon) {
            payload.couponCode = this.appliedCoupon.coupon_code
          }
          if (this.resetCart) {
            payload.resetCart = this.resetCart
            if (!this.$store.getters['users/isLoggedIn']) {
              payload.cartKey = this.$store.state.product.guestCartId
            }
          }

          if (this.$store.getters['users/isLoggedIn']) {
            await this.$store.dispatch('order/addOrder', payload)
          } else {
            await this.$store.dispatch('order/addOrderGuest', payload)
          }
          const status = this.$store.state.order.orderStatus
          const orderMessage = this.$store.state.order.orderMessage
          if (status) {
           if (orderMessage === 'ORDER_PLACED') {
              this.showOrderSuccess()
            }
          } else {
            this.showOrderFailed()
          }
          this.hideNotification()
        },
        hideNotification () {
          let router = this.$router
          setTimeout(() => {
            let e = document.getElementsByClassName('swal-overlay')
            if (e && e[0] && e[0].classList) {
              e[0].classList.remove('swal-overlay--show-modal')
            }
            router.push({path: '/'})
          }, 1500)
        },
        getTotalAmount () {
          let total = this.deliveryCharge
          this.data.products.forEach((p) => {
            total = total + (p.price * p.quantity)
          })
          return total
        },
        getPayableAmount () {
          let totalAmount = this.getTotalAmount()
          let totalWalletBalance = this.totalWalletBalance
          let useWalletBalance = this.useWalletBalance
          let appliedCoupon = this.appliedCoupon
          if (useWalletBalance && appliedCoupon) {
            return Math.max(totalAmount - totalWalletBalance - appliedCoupon.totalCouponDiscount, 0)
          }
          if (useWalletBalance) {
            return Math.max(totalAmount - totalWalletBalance, 0)
          }
          if (appliedCoupon) {
            return Math.max(totalAmount - appliedCoupon.totalCouponDiscount, 0)
          }
          return totalAmount
        },
        async populateUserDetails () {
          let isLoggedIn = this.$store.getters['users/isLoggedIn']
          if (isLoggedIn) {
            await this.$store.dispatch('users/getCurrentUser')
            let { first_name, last_name, email, phone } = this.$store.state.users.currentUser
            let name = first_name + (last_name ? ' ' + last_name : '')
            Object.assign(this.contact, {name, email, phone})
            await this.$store.dispatch('wallet/getWallet')
            let wallet = this.$store.state.wallet.wallet
            if (wallet) {
              this.totalWalletBalance = wallet.userDeposit + wallet.userPromoMoney
              if (this.totalWalletBalance > this.getTotalAmount()) {
                this.totalWalletBalance = this.getTotalAmount()
              }
              this.useWalletBalance = true
            }
          }
        },
      },
      async created() {
        await this.populateUserDetails()
      },
      notifications: {
        showOrderSuccess: {
          type: 'success',
          title: 'Order Successful',
          message: 'Your order has been successfully placed'
        },
        showOrderInitiated: {
          type: 'info',
          title: 'Order Initiated',
          message: 'Your order has been initiated, Please complete the payment'
        },
        showOrderFailed: {
          type: 'info',
          title: 'Order Failed',
          message: 'Failed to process your order, please try again'
        },
      },
    }
</script>

<style scoped>
  .row-margin-left {
    margin-left: -8px !important;
  }
</style>
