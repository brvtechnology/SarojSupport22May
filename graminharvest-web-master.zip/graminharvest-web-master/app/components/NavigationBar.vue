<template>
  <div>
    <v-navigation-drawer temporary :right="false" v-model="leftDrawer" fixed app>
      <v-toolbar flat dense>
        <v-list>
          <v-item>
            <v-list-item-title @click="$router.push({path: '/'})" class="honeyday-title">{{title}}</v-list-item-title>
          </v-item>
        </v-list>
      </v-toolbar>

      <v-divider></v-divider>

      <v-list dense class="pt-0">
        <v-list-item value="true" v-for="(item, i) in items" :key="i" @click="redirect(item)">
          <v-list-item-action>
            <v-icon color="primary">{{item.icon}}</v-icon>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title v-text="item.title"></v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>
    <v-app-bar :app="$route.path !== '/'" fixed :flat="!isScrolling && $route.path === '/'" :class="{ transparent: !isScrolling && $route.path === '/' }">
      <!--
      <v-toolbar-side-icon @click.stop="leftDrawer = !leftDrawer"></v-toolbar-side-icon>
      <v-toolbar-title>
        <v-tooltip bottom>
          <v-btn slot="activator" @click.stop="redirect('/')" active-class icon class="btn--plain">
            <v-avatar tile size="32">
              <img
                src=""
              >
            </v-avatar>
          </v-btn>Home
        </v-tooltip>
        <span class="hidden-sm-and-down">{{title}}</span>
      </v-toolbar-title>
      -->
      <v-app-bar-nav-icon class="hidden-md-and-up" @click.stop="leftDrawer = !leftDrawer"></v-app-bar-nav-icon>
      <v-flex sm2>
        <!-- <a href="/"><v-img class="logo" src="/image/logo.svg"></v-img></a> -->
        <v-toolbar-title>
          <v-btn text large nuxt href="/">{{title}}</v-btn>
        </v-toolbar-title>
      </v-flex>
      <v-divider class="hidden-sm-and-down" inset vertical></v-divider>
      <v-toolbar-items v-for="(item,i) in items" :key="i" class="hidden-sm-and-down">
        <v-btn text  @click="redirect(item)">
          <span>{{item.title}}</span>
        </v-btn>
      </v-toolbar-items>
      <v-spacer></v-spacer>

      <v-badge
              color="primary"
              overlap
      >
        <template>
          <span class="font-weight-thin caption" v-if="cart.length > 0" slot="badge">{{ cart.length }}</span>
        </template>
        <v-icon size="27" @click.stop="rightDrawer = !rightDrawer">shopping_cart</v-icon>
      </v-badge>

      <v-btn text tile v-if="!$store.getters['users/isLoggedIn']" nuxt to="/login">
        <span class="text-capitalize subheading">Login</span>
      </v-btn>
      <v-btn v-else icon nuxt to="/profile">
        <v-icon size="27">person</v-icon>
      </v-btn>
    </v-app-bar>
    <!-- Cart -->
    <v-navigation-drawer temporary :right="true" v-model="rightDrawer" fixed app width="300">
        <v-list two-line>
          <v-list-item  v-if="cart.length !== 0">
            <v-list-item-content>
              <v-list-item-title class="font-weight-bold">Your Cart</v-list-item-title>
            </v-list-item-content>
          </v-list-item>
          <template v-if="cart.length === 0">
            <v-list-item>
              <v-list-item-content>
                <v-list-item-title class="font-weight-regular text-center">
                  <v-icon class="icon--center">info</v-icon>
                </v-list-item-title>
              </v-list-item-content>
            </v-list-item>
            <v-list-item two-line>
              <v-list-item-content>
                <v-list-item-title class="font-weight-regular text-center">Your cart is empty</v-list-item-title>
                <v-list-item-subtitle class="text-center">
                  <v-btn text color="primary" :to="{path: '/products'}">Products</v-btn>
                </v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>
          </template>
          <template v-for="(item, index) in cart">
            <v-list-item :key="item.id">
              <v-list-item-avatar>
                <v-img :src="item.image"></v-img>
              </v-list-item-avatar>
              <v-list-item-content>
                <v-list-item-title class="font-weight-regular">{{ item.name }}</v-list-item-title>
                <v-list-item-subtitle class="text--primary">
                  <span>
                    <span class="text-capitalize">&#x20b9;{{item.price}}</span>
                    <span
                      class="green--text ml-1"
                      v-if="item.discount > 0"
                    >{{item.discount}} {{item.discountType === 'Percentage' ? '%' : 'Rs'}} Off</span>
                  </span>
                </v-list-item-subtitle>
              </v-list-item-content>

              <v-list-item-action>
                <v-icon small color="red" @click="removeItem(item.id)">close</v-icon>
                <span>
                  <v-icon small @click="updateQuantity(item.id, item.quantity, false)">remove</v-icon>
                  <span class="primary--text">{{item.quantity}}</span>
                  <v-icon
                    v-if="item.quantity < item.stock"
                    small
                    @click="updateQuantity(item.id, item.quantity, true)"
                  >add</v-icon>
                  <v-spacer></v-spacer>
                </span>
              </v-list-item-action>
            </v-list-item>
            <v-divider v-if="index + 1 < cart.length"></v-divider>
          </template>
          <v-btn
            @click.native="checkout"
            class="ml-4 mt-2 primary"
            v-if="cart.length > 0"
          >
            <v-icon small left>shopping_basket</v-icon>
            <span class="text-capitalize">Buy</span>
          </v-btn>
        </v-list>
    </v-navigation-drawer>
    <checkout v-if="buy" :data="buyProduct" v-model="buy" reset-cart></checkout>
  </div>
</template>

<script>
import Checkout from './Checkout'
export default {
  components: {Checkout},
  name: "navbar",
  props: ['offsetTop'],
  data() {
    return {
      items: [
        {
          icon: "bubble_chart",
          title: "Products",
          url: "/products",
        },
        {
          icon: "supervised_user_circle",
          title: "About Us",
          url: "/about-us",
          target: '#about'
        },
        {
          icon: "perm_contact_calendar",
          title: "Contact Us",
          url: "contact-us",
          target: '#contact'
        }
      ],
      leftDrawer: false,
      rightDrawer: false,
      title: "Gramin Harvest",
      buy: false,
      buyProduct: {},
      cart: []
    };
  },
  methods: {
    redirect (item) {
      if (item.target && this.$route.path === '/') {
        this.$vuetify.goTo(item.target)
      } else {
        this.$router.push({path: item.url})
      }
    },
    checkout () {
      this.buyProduct = {
        products: this.cart,
        resetCart: true
      }
      this.buy = true
    },
    updateQuantity (id, quantity, isAdd) {
      let newQuantity = isAdd ? quantity + 1 : quantity - 1
      let cartData = {
        id, quantity: newQuantity, mode: 'quantity'
      }
      this.$store.dispatch('product/updateCart', cartData)
    },
    removeItem (id) {
      let cartData = {id, mode: 'remove'}
      this.$store.dispatch('product/updateCart', cartData)
    },
    gotoOrders () {
      this.$router.push({path: '/orders'})
    },
    async getCart () {
      await this.$store.dispatch('product/getCart')
      this.cart = this.$store.state.product.cart
    }
  },
  computed: {
    isScrolling () {
      return this.offsetTop > 100
    },
    showCartBadge () {
      return this.cart.length > 0
    }
  },
  async created() {
    await this.getCart()
    let vm = this
    this.$store.subscribe((mutation, state) => {
      if (mutation.type === 'product/UPDATE_CART') {
        vm.$set(vm, 'cart', state.product.cart)
      }
    })
  }
};
</script>

<style scoped>
.icon--center {
  text-align: center;
}
</style>
