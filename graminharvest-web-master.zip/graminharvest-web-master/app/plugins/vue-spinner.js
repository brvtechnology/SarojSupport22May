import Vue from 'vue'
import ClipLoader from 'vue-spinner/src/ClipLoader'

Vue.component('clip-loader', ClipLoader)