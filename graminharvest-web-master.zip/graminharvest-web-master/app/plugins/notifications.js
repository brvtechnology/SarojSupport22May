import Vue from 'vue'
import VueNotifications from 'vue-notifications'
import swal from 'sweetalert'

function toast ({title, message, type, urlName}) {
  if (type === VueNotifications.types.warn) type = 'warning'
  return swal(title, message, type, {
    button: urlName ? urlName : false
  })
}

const options = {
  success: toast,
  error: toast,
  info: toast,
  warn: toast
}

Vue.use(VueNotifications, options)
