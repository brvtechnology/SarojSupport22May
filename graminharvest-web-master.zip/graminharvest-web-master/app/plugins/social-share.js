import Vue from 'vue'
import SocialShare from "../components/SocialShare";
import VueSocialSharing from 'vue-social-sharing'

Vue.use(VueSocialSharing)
Vue.component('social-share', SocialShare)
