<template>
  <div class="honey-bg">
    <v-layout justify-center>
      <v-container grid-list-md>
        <v-breadcrumbs>
          <v-breadcrumbs-item href="/" router>
            Home
          </v-breadcrumbs-item>
          <v-breadcrumbs-item :disabled="true">
            About us
          </v-breadcrumbs-item>
        </v-breadcrumbs>
      </v-container>
    </v-layout>
    <v-layout>
      <v-flex xs12 sm8 offset-sm2>
        <v-card class="mt-0 elevation-3 mb-5">
          <v-card-text class="text-center display-1 font-weight-bold">Gramin Harvest</v-card-text>

          <v-card-text class="px-8">
            <template>
              <p class="text-left">Established in the year&nbsp;<strong>2011,</strong>&nbsp;at Bengaluru Karnataka, India, we,
                <strong>&nbsp;“Gramin Harvest”&nbsp;</strong>are a young and dynamic organization, engaged in producing
                <strong>Natural Honey, Bee Colonies, Hive Boxes, and All Bee-Keeping related equipment</strong>.
                These are widely appreciated by our esteemed customers for features like purity, longer shelf life and delicious taste.
              </p><p>&nbsp;</p><p>Our owns apiaries in Bangalore, Uttara Kannada (in the Western Ghats) and Kodagu (Coorg) in southern
              India and is currently engaged in manufacturing, trading and exporting AGMARK Grade-A gourmet honey, and supplying bee colonies
              and beekeeping equipment. It is recognized by India's APEDA (Agricultural and Processed Food Products Export Development Authority)
              and exports pristine honey around the world, including the EU, USA and UAE.</p><p><br></p><p>We are a member of FKCCI
              (Federation of Karnataka Chambers of Commerce &amp; Industry) and APEDA (Agricultural and Processed Food Products Export
              Development Authority)</p><p>&nbsp;</p><p>Being a customer driven company, we put in all our efforts to provide maximum
              satisfaction to the patrons. The dexterous procuring agents working with us, search the market to
              examine the best vendors of the industry. These vendors process our offered range using superior quality
              ingredients under hygienic conditions. Our quality controllers make regular visit at vendors' premises, to ensure
              that ethical business policies are being followed in the production process. Apart from this, we also check the quality
              of procured products on defined parameters, such as purity, effectiveness and taste. This helps in eliminating the defective
              range and offer flawless products to the customers. We are also backed by a wide distribution network, which facilitates us to
              supply the products within the stipulated time frame to the customers located at every nook and corner of the world.Our
              customers can purchase these from us, at market leading prices.</p><p><br></p>
            </template>
          </v-card-text>
        </v-card>
      </v-flex>
    </v-layout>
  </div>
</template>

<script>
    export default {
      name: 'about-us',
      data () {
        return {

        }
      }
    }
</script>

<style scoped>

</style>
