<template>
    <v-layout justify-center>
        <v-container grid-list-md>
            <v-layout wrap>
                <v-flex xs12 md8 offset-md2 xl6 offset-xl3>
                    <RegisterBanner />
                </v-flex>
                <v-flex xs8>
                    <v-breadcrumbs>
                        <v-breadcrumbs-item href="/" router>
                            Home
                        </v-breadcrumbs-item>
                        <v-breadcrumbs-item href="/products" router :disabled="!filter">
                            Products
                        </v-breadcrumbs-item>
                        <v-breadcrumbs-item v-if="!!filter" :disabled="true">
                            {{getProductType(filter)}}
                        </v-breadcrumbs-item>
                    </v-breadcrumbs>
                </v-flex>
                <v-flex xs4>
                    <v-btn class="mt-2" text v-show="$vuetify.breakpoint.xsOnly" @click="isFilterVisible = !isFilterVisible">
                        <v-icon small>filter_list</v-icon><span class="text-capitalize primary--text">&nbsp;filter</span>
                    </v-btn>
                </v-flex>
            </v-layout>
            <v-wait>
                <clip-loader slot="waiting" class="fixed--center" color="#43a047"></clip-loader>
                <v-layout wrap>
                    <v-flex md3>
                        <div v-if="$vuetify.breakpoint.smAndUp || isFilterVisible">
                            <ProductFilter
                                    :filters="filters"
                                    @onApplyFilter="applyFilter"
                            />
                        </div>
                    </v-flex>
                    <v-flex md9 xs12>
                        <v-layout wrap>
                            <v-flex xs12 sm10 offset-sm1 v-if="products.length === 0">
                                <v-card flat color="transparent">
                                    <v-card-text class="text-center grey--text">
                                        <v-icon large>info</v-icon>
                                        <div class="title font-weight-light pt-3">Products not available</div>
                                        <v-btn text color="primary" :to="{path: '/'}">Back Home</v-btn>
                                    </v-card-text>
                                </v-card>
                            </v-flex>
                            <v-flex v-for="(product,i) in products" :key="i" xs12 sm6 md4>
                                <v-card
                                        elevation="4"
                                        class="mx-auto img-corner-radius cursor--link"
                                        @click.native="redirectToProductDetails(product.info.friendlyURL)"
                                >
                                    <v-img
                                            :aspect-ratio="10/9"
                                            :src="product.image"
                                    >
                                    </v-img>
                                    <v-card-title>
                                        <div>
                                            <span class="title font-weight-medium text-capitalize">{{product.name}}</span>
                                            <div class="d-flex">
                                                <div class="ml-1 grey--text text--darken-2">
                                                    <span class="text-capitalize font-weight-bold subtitle-1">&#x20b9;{{product.price}}</span>
                                                    <span>
                                                <strike class="red--text subtitle-1">
                                                     {{product.realPrice}}
                                                </strike>
                                            </span>
                                                    <span class="green--text ml-1 font-weight-bold subtitle-2" v-if="product.discount > 0">
                                              {{product.discount}} {{product.discountType === 'Percentage' ? '%' : 'Rs'}} Off
                                            </span>
                                                    <span class="grey--text ml-1 subtitle-1">
                                              {{product.stock > 0 ? 'In stock' : 'Out of stock'}}
                                            </span>
                                                </div>
                                            </div>
                                            <div class="ml-1 text--darken-2">
                                                <v-icon small class="primary--text">loyalty</v-icon>&nbsp;
                                                <span class="subtitle-2 font-weight-light text-capitalize">{{getProductType(product.productType)}}</span>
                                            </div>
                                        </div>
                                    </v-card-title>
                                    <v-divider class="mx-2"></v-divider>
                                    <v-card-actions>
                                        <v-btn
                                                color="primary"
                                                @click.native="checkout(product)"
                                                small
                                                class="text-center"
                                        >
                                            Buy
                                        </v-btn>
                                        <v-spacer></v-spacer>
                                        <v-tooltip bottom>
                                            <template v-slot:activator="{ on }">
                                                <v-btn v-on="on" @click.native="addToCart(product)" :disabled="!!isCartItem(product.id)" icon>
                                                    <v-icon color="primary">
                                                        add_shopping_cart
                                                    </v-icon>
                                                </v-btn>
                                            </template>
                                            <span>{{!isCartItem(product.id) ? 'Add to cart': 'Added to your cart'}}</span>
                                        </v-tooltip>
                                        <v-tooltip bottom>
                                            <template v-slot:activator="{ on }">
                                                <v-btn v-on="on" icon>
                                                    <v-icon color="primary" @click.native="share(product)">share</v-icon>
                                                </v-btn>
                                            </template>
                                            Share
                                        </v-tooltip>
                                    </v-card-actions>
                                </v-card>
                                <v-spacer />
                            </v-flex>
                        </v-layout>
                    </v-flex>
                </v-layout>
            </v-wait>
        </v-container>
        <social-share
          v-if="sharing === true" v-model="sharing"
          :title="shareData.name"
          :description="shareData.description"
        ></social-share>

        <checkout v-if="buy == true" :data="buyProduct" v-model="buy"></checkout>
    </v-layout>
</template>

<script>
    import Checkout from '../../components/Checkout'
    import { waitFor } from 'vue-wait'
    import { mapState } from 'vuex'
    import RegisterBanner from "../../components/RegisterBanner";
    import ProductFilter from "../../components/ProductFilter";
    import product from "../../store/product";

    export default {
        components: {ProductFilter, RegisterBanner, Checkout},
        name: 'products',
        data: () => ({
            buy: false,
            buyProduct: {},
            shareData: {},
            sharing: false,
            isFav: false,
            products: [],
            filter: null,
            filters: [],
            isFilterVisible: false,
        }),
        methods: {
            share (product) {
                this.shareData = product
                this.sharing = true
            },
            checkout (product) {
                let products = []
                let p = JSON.parse(JSON.stringify(product))
                p.quantity = 1
                products.push(p)
                this.buyProduct = {products}
                this.buy = true
            },
            redirectToProductDetails (id) {
                if (!this.sharing && !this.buy && !this.isFav) {
                    this.$router.push({path: `/product/${id}`})
                }
                this.isFav = false
            },
            getProductTypes: waitFor('getProductTypes', async function () {
                await this.$store.dispatch('product/getProductTypes')
            }),
            getProducts: waitFor('getProducts', async function () {
                await this.$store.dispatch('product/getProducts')
                this.products = this.$store.state.product.products
                let filter = this.$route.params.id
                if (filter) {
                    this.filterProduct(parseInt(filter))
                }
                this.getFilters()
            }),
            filterProduct (type = null) {
                let products = this.$store.state.product.products
                if (type) {
                    products = products.filter(p => p.productType === type)
                }
                this.filter = type
                this.products = products
            },
            addToCart (item) {
                this.isFav = true
                item.quantity = 1
                let cartData = {
                    mode: 'add',
                    item
                }
                this.$store.dispatch('product/updateCart', cartData)
            },
            isCartItem (id) {
                return this.cart.find(f => f.id === id)
            },
            getProductType (id) {
                let type = this.productTypes.find(pt => pt.id === id)
                return type ? type.name : ''
            },
            getFilterProductTypes () {
                let types = [{ id: 0, name: 'all' }]
                return types.concat(this.productTypes)
            },
            getFilters () {
                let filters = []
                let isActive = this.$vuetify.breakpoint.smAndUp
                const param = this.$route.params.id
                let categoryFilter = this.productTypes.map(p => {
                    return {
                        id: p.id,
                        title: p.name,
                        selected: param && p.id === parseInt(param)
                    }
                })
                filters.push({
                    title: 'Category',
                    active: isActive,
                    filterType: 'select',
                    items: categoryFilter
                })
                const priceArr = this.$store.state.product.products.map(p => p.price)
                let maxPrice = Math.max(...priceArr)
                let minPrice = Math.min(...priceArr)
                filters.push({
                    title: 'Price',
                    active: isActive,
                    filterType: 'range',
                    range: [minPrice, maxPrice],
                    min: minPrice,
                    max: maxPrice
                })
                const discountArr = this.$store.state.product.products.map(p => {
                    return {
                        title: `${p.discount} ${p.discountType === 'Percentage' ? '%' : 'Rs'} Off`,
                        discount: p.discount,
                        discountType: p.discountType,
                        selected: false
                    }
                })
                filters.push({
                    title: 'Discount',
                    active: isActive,
                    filterType: 'select',
                    items: [...new Set(discountArr)]
                })
                this.filters = filters
            },
            applyFilter (filters) {
                let categoryFilter = filters.find(f => f.title === 'Category')
                let selectedCategoryIds = []
                let products = this.$store.state.product.products
                if (categoryFilter) {
                    selectedCategoryIds = categoryFilter.items.filter(i => i.selected).map(i => i.id)
                }
                if (Array.isArray(selectedCategoryIds) && selectedCategoryIds.length > 0) {
                    products = this.$store.state.product.products.filter(p => selectedCategoryIds.includes(p.productType))
                }
                if (Array.isArray(products) && products.length > 0) {
                    let priceFilter = filters.find(f => f.title === 'Price')
                    if (priceFilter) {
                        let priceRange = priceFilter.range
                        if (Array.isArray(priceRange) && priceRange.length > 1) {
                            products = products.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1])
                        }
                    }
                }
                if (Array.isArray(products) && products.length > 0) {
                    let discountFilter = filters.find(f => f.title === 'Discount')
                    if (discountFilter) {
                        let discountItems = discountFilter.items.filter(i => i.selected)
                        if (Array.isArray(discountItems) && discountItems.length > 0) {
                            products = products.filter(p =>
                                discountItems.map(d => d.discount).includes(p.discount)
                                && discountItems.map(d => d.discountType).includes(p.discountType))
                        }
                    }
                }
                this.filters = filters
                this.products = products
                this.isFilterVisible = !this.isFilterVisible
            }
        },
        computed: mapState('product', {
            productTypes: state => state.productTypes,
            cart: state => state.cart
        }),
        created () {
            this.getProductTypes()
            this.getProducts()
        }
    }
</script>

<style scoped>
    .img-corner-radius {
        border-radius: 8px!important;
    }
    .v-card--reveal {
        align-items: center;
        bottom: 0;
        justify-content: center;
        opacity: .5;
        position: absolute;
        width: 100%;
    }
</style>
