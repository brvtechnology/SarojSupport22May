<template>
  <div class="honey-bg">
    <v-layout justify-center>
      <v-container grid-list-md>
        <v-breadcrumbs>
          <v-breadcrumbs-item href="/" router>
            Home
          </v-breadcrumbs-item>
          <v-breadcrumbs-item :disabled="true">
            Contact us
          </v-breadcrumbs-item>
        </v-breadcrumbs>
      </v-container>
    </v-layout>
      <v-layout column
        wrap
        class="mb-5"
        align-center>
        <v-container grid-list-md>
          <v-layout row wrap align-center>
            <v-flex xs12 md6 offset-md3>
              <v-card class="pb-0 elevation-1">
                <v-card-text class="text-center">
                  <v-avatar size="100">
                    <v-img :src="require('../assets/image/contact-us.jpg')"></v-img>
                  </v-avatar>
                </v-card-text>
                <v-card-text primary-title>
                  <div class="text-center">
                    <h2 class="headline font-weight-bold">
                      Need Any <span class="primary--text">Help</span>?
                    </h2>
                    <p class="grey--text">If you have any question, you can contact us over phone or email</p>
                    <span>
                      <span class="font-weight-bold">
                        Deepti
                      </span>
                      <br/>
                      <v-icon color="primary" small>phone</v-icon>
                      +91 7022634356
                      <br v-if="$vuetify.breakpoint.smAndDown"/>
                      <v-icon color="primary" class="ml-3" small>email</v-icon>
                      marketing@honeyday.in
                    </span>
                  </div>
                </v-card-text>
                <v-card-actions class="text-center">
                  <v-spacer />
                  <v-tooltip bottom>
                    <template v-slot:activator="{ on }">
                      <v-btn v-on="on" color="white" icon
                             href="tel:+917022634356"
                      >
                        <v-icon color="blue" size="30">
                          phone
                        </v-icon>
                      </v-btn>
                    </template>
                    Call us
                  </v-tooltip>
                  <v-tooltip bottom>
                    <template v-slot:activator="{ on }">
                      <v-btn v-on="on" color="white" icon
                             href="mailto:honeydaybeefarms@gmail.com"
                      >
                        <v-avatar tile size="30">
                          <v-img src="/image/email.png"></v-img>
                        </v-avatar>
                      </v-btn>
                    </template>
                    E-mail us
                  </v-tooltip>
                  <v-tooltip bottom>
                    <template v-slot:activator="{ on }">
                      <v-btn v-on="on" color="white" icon href="https://www.facebook.com/honeydaybfarms/">
                        <v-avatar tile size="30">
                          <v-img src="/image/facebook-logo.png"></v-img>
                        </v-avatar>
                      </v-btn>
                    </template>
                    Contact us on facebook
                  </v-tooltip>
                  <v-spacer />
                </v-card-actions>
              </v-card>
            </v-flex>
          </v-layout>
        </v-container>
      </v-layout>
  </div>
</template>

<script>
    export default {
      name: 'contact-us',
      data () {
        return {
          img: '/image/logo.svg'
        }
      }
    }
</script>

<style scoped>
 .contact {
   margin-left: 10rem !important;
   margin-right: 10rem !important;
 }
</style>
