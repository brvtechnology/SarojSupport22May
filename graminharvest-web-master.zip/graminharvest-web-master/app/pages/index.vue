<template>
  <div>
    <Hero />
    <product-category />
    <Process />
    <top-products />
    <section id="about">
      <v-container>
        <v-layout row wrap py-5>
          <v-flex sm6 pa-4>
            <v-img :src="about.image" data-aos="fade-right"></v-img>
          </v-flex>
          <v-flex sm6 pa-4>
            <h2 class="display-2 font-weight-thin green--text text--lighten-3">{{about.title}}</h2>
            <h4 class="headline my-1 grey--text text--lighten-1">{{about.subtitle}}</h4>
            <p class="subheading">{{about.description}}</p>
            <v-btn text nuxt ripple tile to="/about-us">Learn More</v-btn>
          </v-flex>
        </v-layout>
      </v-container>
    </section>

    <section id="contact" class="grey lighten-3">
      <v-container>
        <v-layout row wrap py-5>
          <v-flex xs12 pt-4 text-center>
            <h2 class="headline text-uppercase my-1">{{contactTitle.title}}</h2>
            <div class="title font-weight-light grey--text text--lighten-1">{{contactTitle.subtitle}}</div>
          </v-flex>
        </v-layout>
        <v-layout row wrap pb-5>
          <v-flex sm12 md6 offset-md3>
            <v-form class="text-center">
                <v-text-field type="text" label="Name" outlined></v-text-field>
                <v-text-field type="email" label="Email" outlined></v-text-field>
                <v-textarea outlined label="Message"></v-textarea>
                <v-btn large class="white--text" color="primary" mx-5>Send message</v-btn>
            </v-form>

          </v-flex>
        </v-layout>
      </v-container>
    </section>
  </div>
</template>

<script>
import Hero from '../components/Hero.vue'
import ProductCategory from '../components/ProductCategory.vue'
import Process from '../components/Process.vue'
import TopProducts from '../components/TopProducts.vue'

export default {
  components: {
    Hero,
    ProductCategory,
    Process,
    TopProducts
  },
  data () {
    return {
      show: false,
      about: {
        title: 'About Gramin Harvest',
        subtitle: 'Pioneer of organic food',
        image: 'https://www.ekapija.com/thumbs/povrce_240715_tw630.jpg',
        description: "Established in the year 2015, at Bengaluru Karnataka, India, we,  “ Gramin Harvest” are a young and dynamic organization, engaged in producing Organic foods. These are widely appreciated by our esteemed customers for features like purity, longer shelf life and delicious taste. Being a customer driven company, we put in all our efforts to provide maximum satisfaction to the patrons. The dexterous procuring agents working with us, search the market to examine the best vendors of the industry. We are also backed by a wide distribution network, which facilitates us to supply the products within the stipulated time frame to the customers located at every nook and corner of the world.Our customers can purchase these from us, at market leading prices."
      },
      contactTitle: {
        title: 'Get in touch',
        subtitle: 'Contact us for any query, we are happy to help you out.'
      }
    }
  }
}
</script>

<style lang="scss">
  $nice-ease: cubic-bezier(.45,.16,0,.77);

  .titleAnim {
    animation: .5s blurIn ease;
  }
  @-webkit-keyframes blurIn {
    0% {
      filter: blur(20px);
      }
    100% {
      filter: blur(0);
      }
  }
   @-webkit-keyframes fadeIn {
    0% {
      opacity: 0;
      }
    100% {
      opacity: 1;
      }
  }
</style>
