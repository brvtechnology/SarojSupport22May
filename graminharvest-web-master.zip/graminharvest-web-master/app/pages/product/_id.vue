<template>
  <v-layout>
    <v-container grid-list-md>
      <v-breadcrumbs>
        <v-breadcrumbs-item href="/" router>
          Home
        </v-breadcrumbs-item>
        <v-breadcrumbs-item href="/products" router>
          Products
        </v-breadcrumbs-item>
        <v-breadcrumbs-item v-if="!!product" :disabled="true">
          {{product.name}}
        </v-breadcrumbs-item>
      </v-breadcrumbs>
      <v-wait>
        <clip-loader slot="waiting" class="fixed--center" color="#43a047"></clip-loader>
        <v-flex xs12 sm10 offset-sm1 v-if="Object.keys(product).length === 0">
          <v-card flat color="transparent">
            <v-card-text class="text-center grey--text">
              <v-icon large>info</v-icon>
              <div class="title font-weight-light pt-3">Oops! Product not available</div>
              <v-btn text color="primary" :to="{path: '/'}">Back Home</v-btn>
            </v-card-text>
          </v-card>
        </v-flex>
        <v-layout wrap v-else>
          <v-flex xs12 sm6>
            <v-img
              :aspect-ratio="6/5"
              :src="product.image"
            ></v-img>
          </v-flex>
          <v-flex xs12 sm6>
            <v-card
              flat
              :class="$vuetify.breakpoint.xsOnly ? 'mx-auto' : 'mx-auto ml-5'"
              class=""
              color="transparent"
            >
              <v-card-title>
                <div>
                  <span class="headline primary--text text-capitalize text-center">{{product.name}}</span>
                  <p class="subtitle-1 mt-3 mb-4">
                    {{product.description}}
                  </p>
                  <div class="d-flex my-3">
                    <div class="grey--text text--darken-2">
                      <span class="text-capitalize title">&#x20b9; {{product.price}}</span>
                      <span class="text-capitalize subtitle-1">
                        <strike class="red--text">
                             {{product.realPrice}}
                        </strike>
                      </span>
                      <span class="green--text ml-1 subtitle-1 font-weight-bold" v-if="product.discount > 0">
                        {{product.discount}} {{product.discountType === 'Percentage' ? '%' : 'Rs'}} Off
                      </span>
                    </div>
                  </div>
                  <div class="my-3 subtitle-1">
                    {{product.stock > 0 ? 'In stock' : 'Out of stock'}}
                  </div>
                </div>
              </v-card-title>
              <v-card-actions>
                <v-btn
                  large class="text-center"
                  color="primary" @click.native="addToCart(product)" :disabled="!!isCartItem(product.id)">
                  <v-icon left>add_shopping_cart</v-icon>
                  {{!isCartItem(product.id) ? 'cart' : 'In cart'}}
                </v-btn>
                <v-btn
                  color="primary"
                  @click.native="buyProduct"
                  large
                  class="text-center"
                >
                  <v-icon left>shopping_basket</v-icon>
                  Buy
                </v-btn>
                <v-btn
                    color="primary"
                    @click.native="sharing = true"
                    large
                    class="text-center"
                >
                  <v-icon left>share</v-icon>
                  Share
                </v-btn>
              </v-card-actions>
            </v-card>
          </v-flex>
        </v-layout>
      </v-wait>
    </v-container>
    <social-share
            v-if="sharing === true" v-model="sharing"
            :title="product.name"
            :description="product.description"
    ></social-share>
    <checkout v-if="buy" :data="checkoutItem" v-model="buy"></checkout>
  </v-layout>
</template>

<script>
    import Checkout from '../../components/Checkout'
    import { mapState } from 'vuex'
    import { waitFor } from 'vue-wait'

    export default {
      components: {Checkout},
      name: 'product-detail',
      data () {
        return {
          buy: false,
          checkoutItem: {},
          sharing: false
        }
      },
      methods: {
        getProduct:waitFor('getProduct', async function () {
          let id = this.$route.params.id
          if (id) {
            await this.$store.dispatch('product/getProduct', id)
          }
        }),
        addToCart (item) {
          this.isFav = true
          item.quantity = 1
          let cartData = {
            mode: 'add',
            item
          }
          this.$store.dispatch('product/updateCart', cartData)
        },
        isCartItem (id) {
          return this.cart.find(f => f.id === id)
        },
        buyProduct () {
          let products = []
          let p = JSON.parse(JSON.stringify(this.product))
          p.quantity = 1
          products.push(p)
          this.checkoutItem = {products}
          this.buy = true
        }
      },
      computed: mapState('product', {
        product: state => state.product,
        cart: state => state.cart
      }),
      created () {
        this.getProduct()
      }
    }
</script>

<style scoped>

</style>
