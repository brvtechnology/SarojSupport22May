<template>
    <v-layout justify-center>
        <v-container grid-list-md>
            <v-wait>
                <clip-loader slot="waiting" class="fixed--center" color="#43a047"></clip-loader>
                <v-card flat v-if="user">
                    <v-card-text class="pt-12" :class="{'align-left': $vuetify.breakpoint.smAndDown, 'text-center': $vuetify.breakpoint.mdAndUp}">
                        <span>
                             <span class="display-1 text-capitalize">
                                {{user.first_name}}{{user.last_name ? ' ' + user.last_name : ''}}
                            </span>
                            <v-btn small text color="error" class="text-capitalize align-right" @click="logout">
                                <v-icon left small>power_settings_new</v-icon>
                                Logout
                            </v-btn>
                        </span>
                    </v-card-text>
                    <v-layout row wrap>
                        <v-flex class="md4 xs12 offset-md2">
                            <v-list two-line>
                                <v-list-item>
                                    <v-list-item-icon>
                                        <v-icon color="primary">phone</v-icon>
                                    </v-list-item-icon>

                                    <v-list-item-content>
                                        <v-list-item-title>{{user.phone}}</v-list-item-title>
                                        <v-list-item-subtitle>Mobile</v-list-item-subtitle>
                                    </v-list-item-content>
                                </v-list-item>
                            </v-list>
                        </v-flex>
                        <v-flex class="md4 xs12">
                            <v-list two-line :class="{'align-right': $vuetify.breakpoint.mdAndUp}">
                                <v-list-item>
                                    <v-list-item-icon>
                                        <v-icon color="primary">mail</v-icon>
                                    </v-list-item-icon>

                                    <v-list-item-content>
                                        <v-list-item-title>{{user.email}}</v-list-item-title>
                                        <v-list-item-subtitle>E-mail</v-list-item-subtitle>
                                    </v-list-item-content>
                                </v-list-item>
                            </v-list>
                        </v-flex>
                    </v-layout>
                </v-card>
            </v-wait>
            <v-card>
                <v-tabs
                        v-model="tab"
                        centered
                        icons-and-text
                >
                    <v-tabs-slider></v-tabs-slider>

                    <v-tab href="#tab-1">
                        Refer
                        <v-avatar size="35">
                            <Refer />
                        </v-avatar>
                    </v-tab>

                    <v-tab href="#tab-2">
                        Wallet
                        <v-avatar size="35">
                            <Wallet />
                        </v-avatar>
                    </v-tab>

                    <v-tab href="#tab-3">
                        Orders
                        <v-avatar size="35">
                            <Order />
                        </v-avatar>
                    </v-tab>
                </v-tabs>

                <v-tabs-items v-model="tab">
                    <v-tab-item
                            v-for="i in 3"
                            :key="i"
                            :value="'tab-' + i"
                    >
                        <ReferFriend :refer-code="user.info.refer.referCode" v-if="user && i === 1" />
                        <AddWallet v-if="i === 2" />
                        <Orders v-if="i === 3" />
                    </v-tab-item>
                </v-tabs-items>
            </v-card>
        </v-container>
    </v-layout>
</template>

<script>
    import Refer from '../assets/icons/refer.svg'
    import Wallet from '../assets/icons/wallet.svg'
    import Order from '../assets/icons/order.svg'
    import ReferFriend from '../components/Refer'
    import AddWallet from '../components/Wallet'
    import Orders from '../components/Orders'
    import { waitFor } from 'vue-wait'

    export default {
        name: "profile.vue",
        components: {Refer, Wallet, Order, ReferFriend, AddWallet, Orders},
        data () {
            return {
                tab: null,
                user: null
            }
        },
        methods: {
            logout () {
                this.$store.dispatch('users/logout')
                this.$router.push({path: '/'})
            },
            getCurrentUser: waitFor('fetchCurrentUser', async function () {
                await this.$store.dispatch('users/getCurrentUser')
                this.user = this.$store.state.users.currentUser
            })
        },
        created() {
            this.getCurrentUser()
        }
    }
</script>

<style scoped>
    .align-right {
        float: right;
    }
</style>
