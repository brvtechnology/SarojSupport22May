<template>
    <div class="gramin-bg">
        <v-layout flex align-center justify-center class="login-container">
            <v-flex xs12 sm6>
                <v-card class="pt-5" hover>
                    <v-card-text>
                        <div>
                            <v-flex xs12 pb-4 text-center>
                                <v-avatar @click="() => $router.push({path: '/'})">
                                    <v-icon x-large color="primary" style="font-size: 65px;">settings_remote</v-icon>
                                </v-avatar>
                                <h3 class="headline mt-2 font-weight-thin">Gramin Harvest</h3>
                            </v-flex>
                            <v-form v-model="valid" ref="form">
                                <v-flex xs12 sm10 offset-sm1>
                                    <v-text-field
                                        outlined
                                        label="E-mail"
                                        prepend-inner-icon="person"
                                        v-model="email"
                                        :rules="emailRules"
                                        required
                                    ></v-text-field>
                                </v-flex>
                                <v-flex xs12 sm10 offset-sm1>
                                    <v-text-field
                                        outlined
                                        label="Password"
                                        prepend-inner-icon="lock"
                                        v-model="password"
                                        min="8"
                                        :append-icon="e1 ? 'visibility' : 'visibility_off'"
                                        @click:append="e1 = !e1"
                                        :type="e1 ? 'password' : 'text'"
                                        :rules="passwordRules"
                                        required
                                ></v-text-field>
                                </v-flex>
                                <v-layout wrap class="mb-2">
                                    <v-flex xs12 sm4 offset-sm1>
                                        <v-btn large @click="login" ripple class="primary white--text" :class=" {disabled: !valid }">Login</v-btn>
                                    </v-flex>
                                    <v-flex xs12 sm4 offset-sm3>
                                        <v-btn class="text-capitalize" text href="/">Forgot password?</v-btn>
                                    </v-flex>
                                </v-layout>
                            </v-form>
                            <v-divider></v-divider>
                            <v-layout row wrap class="mb-4">
                                <v-flex xs12 sm6 offset-sm1>
                                    <v-card-title class="subtitle-1">
                                        Don't have an account?&nbsp;
                                        <nuxt-link to="/register">Register</nuxt-link>
                                    </v-card-title>
                                </v-flex>
                            </v-layout>
                        </div>
                    </v-card-text>
                </v-card>
            </v-flex>
        </v-layout>
    </div>
</template>

<script>

export default {
    name: 'Login',
    data () {
        return {
            valid: false,
            errorHelpText: {
                email: null,
                password: null
            },
            e1: true,
            password: '',
            passwordRules: [
                (v) => !!v || 'Password is required'
            ],
            email: '',
            emailRules: [
                (v) => !!v || 'E-mail is required',
                (v) => /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(v) || 'E-mail must be valid'
            ]
        }
    },
    notifications: {
      showLoginSuccessMsg: {
        type: 'success',
        title: 'Login Successful',
        message: 'Successful'
      },
      showLoginWarnMsg: {
        type: 'info',
        title: 'Login Failed',
        message: 'Warning'
      },
    },
    methods: {
        async login () {
            let router = this.$router
            if (this.$refs.form.validate()) {
                await this.$store.dispatch('users/login', {email: this.email, password: this.password})
                if (this.$store.state.users.loginResult.type !== 'success') {
                    this.showLoginWarnMsg({message: this.$store.state.users.loginResult.msg})
                } else {
                    this.showLoginSuccessMsg({message: this.$store.state.users.loginResult.msg, timeout: 1000})
                    setTimeout(() => {
                        let e = document.getElementsByClassName('swal-overlay')
                        if (e && e[0] && e[0].classList) {
                            e[0].classList.remove('swal-overlay--show-modal')
                        }
                        router.push({path: '/'})
                    }, 1000)
                }
            }
        }
    }
}
</script>

<style>

</style>


