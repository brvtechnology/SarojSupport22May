<template>
    <v-layout flex justify-center class="gramin-bg">
        <v-flex xs12 sm6>
            <v-flex xs12 py-4 text-center>
                <v-avatar @click="() => $router.push({path: '/'})">
                    <v-icon x-large color="primary" style="font-size: 65px;">settings_remote</v-icon>
                </v-avatar>
                <h3 class="headline mt-2 font-weight-thin">Gramin Harvest</h3>
            </v-flex>
            <v-stepper v-model="stepper" vertical>
                <v-stepper-step :complete="stepper > 1" step="1">Register</v-stepper-step>
                <!-- Register -->
                <v-stepper-content step="1">
                    <v-card class="pb-5" hover>
                        <v-card-text>
                            <div :style="{ 'display': isHidden ? 'none' : 'block' }" :key="String(isHidden)">
                                <v-form v-model="valid" ref="form">
                                    <v-flex xs12 sm10 offset-sm1>
                                        <v-text-field
                                                outlined
                                                label="Name"
                                                prepend-inner-icon="person"
                                                v-model="user.name"
                                                :rules="rules.nameRule"
                                                required
                                        ></v-text-field>
                                    </v-flex>
                                    <v-flex xs12 sm10 offset-sm1>
                                        <v-text-field
                                                outlined
                                                label="E-mail"
                                                prepend-inner-icon="mail"
                                                v-model="user.email"
                                                :rules="rules.emailRules"
                                                required
                                        ></v-text-field>
                                    </v-flex>
                                    <v-flex xs12 sm10 offset-sm1>
                                        <v-text-field
                                                outlined
                                                label="Phone"
                                                v-mask="phoneMask"
                                                prepend-inner-icon="phone"
                                                v-model="user.phone"
                                                :rules="rules.phoneRules"
                                                required
                                        ></v-text-field>
                                    </v-flex>
                                    <v-flex xs12 sm10 offset-sm1>
                                        <v-text-field
                                                outlined
                                                label="Password"
                                                prepend-inner-icon="lock"
                                                v-model="user.password"
                                                min="6"
                                                :append-icon="e1 ? 'visibility' : 'visibility_off'"
                                                @click:append="e1 = !e1"
                                                :type="e1 ? 'text' : 'password'"
                                                :rules="rules.passwordRules"
                                                required
                                        ></v-text-field>
                                    </v-flex>
                                    <v-flex xs12 sm10 offset-sm1>
                                        <v-card-title class="subtitle-1">
                                            By continuing, you are accepting our terms and conditions
                                        </v-card-title>
                                    </v-flex>
                                    <v-layout wrap>
                                        <v-flex xs12 sm4 offset-sm1>
                                            <v-btn large @click="register" ripple class="primary white--text mb-4" :class=" {disabled: !valid }">Register</v-btn>
                                        </v-flex>
                                    </v-layout>
                                </v-form>
                                <v-divider></v-divider>
                                <v-layout row wrap class="mb-4">
                                    <v-flex xs12 sm6 offset-sm1>
                                        <v-card-title class="subtitle-1">
                                            Already have an account?&nbsp;
                                            <nuxt-link to="/login">Login</nuxt-link>
                                        </v-card-title>
                                    </v-flex>
                                </v-layout>
                            </div>
                        </v-card-text>
                    </v-card>
                </v-stepper-content>
                <v-stepper-step :complete="stepper > 2" step="2">Verify</v-stepper-step>
                <!-- Verify -->
                <v-stepper-content step="2">
                    <v-card v-if="$store.state.users.currentUser">
                        <v-card-text>
                            <div class="headline mb-2">Hi {{$store.state.users.currentUser.first_name}}</div>
                            Please verify your contact details
                        </v-card-text>

                        <v-card-text class="py-1 my-0">
                               <span>
                                   <span class="font-weight-bold">{{$store.state.users.currentUser.email}}</span>
                                   <v-icon v-if="otp.email.verified" color="primary">check_circle</v-icon>
                                   <v-btn v-else small text color="primary" class="text-none" @click="sendOtp('email')">{{otp.email.sent? 'Resend': 'Verify'}}</v-btn>
                                </span>
                            <v-flex xs12 sm7 class="mt-1">
                                <v-form v-model="emailOtpValid" ref="emailOtpForm" autocomplete="off">
                                    <v-text-field
                                            v-if="otp.email.sent && !otp.email.verified"
                                            outlined
                                            v-model="otp.email.value"
                                            label="Enter OTP"
                                            type="password"
                                            v-mask="otpMask"
                                            :rules="rules.otpRules"
                                            required
                                    >
                                        <template v-slot:append>
                                            <v-fade-transition leave-absolute>
                                                <v-btn color="primary" @click="verifyOtp('email')">Submit</v-btn>
                                            </v-fade-transition>
                                        </template>
                                    </v-text-field>
                                </v-form>
                            </v-flex>
                        </v-card-text>

                        <v-card-text class="pt-0 mt-0">
                               <span>
                                   <span class="font-weight-bold">{{$store.state.users.currentUser.phone}}</span>
                                   <v-icon v-if="otp.phone.verified" color="primary">check_circle</v-icon>
                                   <v-btn v-else small text color="primary" class="text-none" @click="sendOtp('phone')">{{otp.phone.sent? 'Resend': 'Verify'}}</v-btn>
                                </span>
                            <v-flex xs12 sm7 class="mt-1">
                                <v-form v-model="phoneOtpValid" ref="phoneOtpForm" autocomplete="off">
                                    <v-text-field
                                            outlined
                                            v-if="otp.phone.sent && !otp.phone.verified"
                                            v-model="otp.phone.value"
                                            label="Enter OTP"
                                            type="password"
                                            v-mask="otpMask"
                                            :rules="rules.otpRules"
                                            required
                                    >
                                        <template v-slot:append>
                                            <v-fade-transition leave-absolute>
                                                <v-btn color="primary" @click="verifyOtp('phone')">Submit</v-btn>
                                            </v-fade-transition>
                                        </template>
                                    </v-text-field>
                                </v-form>
                            </v-flex>
                        </v-card-text>
                        <v-divider></v-divider>
                        <v-card-actions>
                            <v-btn @click="resetOtpForm" text>Back</v-btn>
                        </v-card-actions>
                    </v-card>
                </v-stepper-content>
                <v-stepper-step step="3">Referral</v-stepper-step>
                <!-- Referral -->
                <v-stepper-content step="3">
                    <v-card class="pb-5" hover>
                        <v-card-text>
                            <div :style="{ 'display': isHidden ? 'none' : 'block' }" :key="String(isHidden)">
                                <v-form v-model="valid" ref="form">
                                    <v-flex xs12 sm10 offset-sm1>
                                        <v-text-field
                                                outlined
                                                placeholder="Have a referral code?"
                                                v-model="referralCode"
                                        ></v-text-field>
                                    </v-flex>
                                    <v-layout wrap>
                                        <v-flex xs12 sm4 offset-sm1>
                                            <v-btn large @click="addReferral" ripple class="primary white--text mb-4" :disabled="!referralCode">Submit</v-btn>
                                            <v-btn @click="addReferral" text ripple class="mb-4 text-capitalize">Skip</v-btn>
                                        </v-flex>
                                    </v-layout>
                                </v-form>
                            </div>
                        </v-card-text>
                    </v-card>
                </v-stepper-content>
            </v-stepper>
        </v-flex>
    </v-layout>
</template>

<script>
    import { mask } from 'vue-the-mask'

    export default {
    name: 'registration',
    directives: {
        mask,
    },
    data () {
        return {
            stepper: 1,
            valid: false,
            emailOtpValid: false,
            phoneOtpValid: false,
            isHidden: false,
            errorHelpText: {
                email: null,
                password: null
            },
            phoneMask: '##########',
            otpMask: '####',
            e1: false,
            user: {
                name: '',
                email: '',
                phone: '',
                password: '',
            },
            rules: {
                nameRule: [
                    v => !!v || 'Name is required',
                    v => (v && v.length <= 30) || 'Name must be less than 30 characters'
                ],
                emailRules: [
                    (v) => !!v || 'E-mail is required',
                    (v) => /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(v) || 'E-mail must be valid'
                ],
                passwordRules: [
                    v => !!v || 'Password is required',
                    v => (v && v.length <= 30) || 'Password must be less than 20 characters',
                    v => (v && v.length >= 6) || 'Name must be greater than 6 characters'
                ],
                phoneRules: [
                    v => !!v || 'Phone is required',
                    v => v && v.length === 10 || 'Phone number should be 10 dight',
                ],
                otpRules: [
                    v => !!v || 'OTP is required',
                    v => v && v.length === 4 || 'OTP should be 4 dight',
                ],
            },
            otp: {
                email: {
                    sent: false,
                    verified: false,
                    value: ''
                },
                phone: {
                    sent: false,
                    verified: false,
                    value: ''
                }
            },
            referralCode: ''
        }
  },
  notifications: {
    showRegistrationWarnMsg: {
        type: 'info',
        title: 'Oops',
        message: 'Registration Failed'
    },
      showRegistrationSuccessMsg: {
          type: 'success',
          title: 'Successful',
          message: 'Registration is Successful'
      },
      showReferralWarnMsg: {
          type: 'info',
          title: 'Oops',
          message: 'Referral code is not valid'
      },
  },
  methods: {
      async register () {
          if (this.$refs.form.validate()) {
              let newUser = JSON.parse(JSON.stringify(this.user));
              let name = newUser.name.trim().split(' ')
              newUser.firstName = name[0]
              if (name[1]) {
                  newUser.lastName = name[1]
              }
              delete newUser.name
              await this.$store.dispatch('users/register', newUser)
              if (this.$store.state.users.registrationResult.type !== 'success') {
                  this.showRegistrationWarnMsg({message: this.$store.state.users.registrationResult.msg})
              } else {
                  this.stepper = 2
              }
          }
      },
      async sendOtp (type) {
        await this.$store.dispatch('users/sendOtp', type)
        if (type === 'email') {
            if (this.$store.state.users.otpEmail.hasError) {
                this.showRegistrationWarnMsg({title: 'E-mail verification failed', message: this.$store.state.users.otpEmail.message})
            } else {
                this.otp.email.sent = true
            }
        } else {
            if (this.$store.state.users.otpPhone.hasError) {
                this.showRegistrationWarnMsg({title: 'Phone verification failed', message: this.$store.state.users.otpPhone.message})
            } else {
                this.otp.phone.sent = true
            }
        }
      },
      async verifyOtp (type) {
          let validated = type === 'email' ? this.$refs.emailOtpForm.validate() : this.$refs.phoneOtpForm.validate()
          if (validated) {
            await this.$store.dispatch('users/verifyOtp', {type, otp: type === 'email' ? this.otp.email.value : this.otp.phone.value})
            if (type === 'email') {
                if (this.$store.state.users.otpEmail.hasError) {
                    this.showRegistrationWarnMsg({title: 'E-mail verification failed', message: this.$store.state.users.otpEmail.message})
                } else if(this.$store.state.users.otpEmail.verified){
                    this.otp.email.verified = true
                }
            } else {
                if (this.$store.state.users.otpPhone.hasError) {
                    this.showRegistrationWarnMsg({title: 'Phone verification failed', message: this.$store.state.users.otpPhone.message})
                } else if(this.$store.state.users.otpPhone.verified){
                    this.otp.phone.verified = true
                }
            }

            if (this.$store.getters['users/isLoggedIn']) {
                this.stepper = 3
            }

          }
      },
      resetOtpForm () {
          this.otp = {
              email: {
                  sent: false,
                      verified: false,
                      value: ''
              },
              phone: {
                  sent: false,
                      verified: false,
                      value: ''
              }
          }
          this.stepper = 1
      },
      async addReferral () {
          let router = this.$router
          await this.$store.dispatch('users/addReferral', {referrerId: this.referralCode})
          if (this.$store.state.users.addReferralMessage !== 'success') {
              this.showReferralWarnMsg({timeout: 2000})
          } else {
              this.showRegistrationSuccessMsg({timeout: 2000})
          }
          setTimeout(() => {
              let e = document.getElementsByClassName('swal-overlay')
              if (e && e[0] && e[0].classList) {
                  e[0].classList.remove('swal-overlay--show-modal')
              }
              router.push({path: '/'})
          }, 2000)
      }
  }
}
</script>

<style>
 .login-container {
	position: absolute;
	top:0;
	bottom: 0;
	left: 0;
	right: 0;
	margin: auto;
 }
</style>


