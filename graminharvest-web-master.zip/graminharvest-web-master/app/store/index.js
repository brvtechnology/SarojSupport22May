const cookieparser = process.server ? require('cookieparser') : undefined

export const actions = {
    nuxtServerInit ({ commit, dispatch, rootState }, { req }) {
        if (req.headers.cookie && cookieparser) {
            try {
                const parsed = cookieparser.parse(req.headers.cookie)
                let token = parsed.token
                if (token) {
                    commit('users/SET_AUTH_TOKEN', {token})
                }
                let guestCartId = parsed.guest_cart_id
                if (guestCartId) {
                    commit('product/ADD_GUEST_CART_ID', {guestCartId})
                }
                console.log('Access token from state in nuxtServerInit: ', rootState.users.accessToken)
                console.log('Guest Cart id from state in nuxtServerInit: ', rootState.product.guestCartId)
            } catch (err) {
                console.log('no cookie found in nuxtServerInit')
            }
        }
    }
}
