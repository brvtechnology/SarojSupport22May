import { STORE_COUPONS } from '../util/mutation-types'
import { GET_COUPONS } from '../api/api-endpoints'
import api from '../api'

const state = () => ({
    coupons: []
})

// getters
const getters = {}

// actions
const actions = {
    async getCoupons ({ commit }) {
        let {data} = await api.get(GET_COUPONS)
        commit(STORE_COUPONS, {coupons: data})
    }
}

// mutations
const mutations = {
    [STORE_COUPONS] (state, {coupons}) {
        state.coupons = coupons
    }
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}
