// state
import { PRODUCTS, PRODUCT, PRODUCT_TYPE, FAVOURITES, ADD_TO_CART, UPDATE_CART, UPDATE_QUANTITY, REMOVE_ITEM, ADD_GUEST_CART_ID, REMOVE_GUEST_CART_ID } from '../util/mutation-types'
import { GET_PRODUCTS, GET_PRODUCT_TYPES, ADD_TO_CART as ADD_CART, ADD_TO_CART_GUEST, GET_CART, GET_CART_GUEST } from '../api/api-endpoints'
import api from '../api'
const Cookie = process.client ? require('js-cookie') : undefined

const state = () => ({
  products: [],
  product: {},
  productTypes: [],
  favourites: [],
  cart: [],
  guestCartId: null
})

// getters
const getters = {}

// actions
const actions = {
  async getProducts ({ commit }) {
    let {data} = await api.get(GET_PRODUCTS)
    commit(PRODUCTS, {products: data})
  },
  async getProduct ({ commit, state }, id) {
    let {data} = await api.get(`${GET_PRODUCTS}?name=${id}`)
    commit(PRODUCT, {product: data})
  },
  async getProductTypes ({ commit }) {
    let {data} = await api.get(GET_PRODUCT_TYPES)
    commit(PRODUCT_TYPE, {productTypes: data})
  },
  async updateCart ({ commit, state, rootGetters }, cartData) {
    if (cartData.mode === 'add') {
      commit(ADD_TO_CART, {item: cartData.item})
    } else if (cartData.mode === 'quantity') {
      commit(UPDATE_QUANTITY, {id: cartData.id, quantity: cartData.quantity})
    } else {
      commit(REMOVE_ITEM, {id: cartData.id})
    }
    if (rootGetters['users/isLoggedIn']) {
      let {data} = await api.post(ADD_CART, {cartItems: state.cart})
      commit(UPDATE_CART, {items: data.cartItems})
    } else {
      let req = {cartItems: state.cart}
      if (state.guestCartId) {
        req.uuid = state.guestCartId
      }
      let {data} = await api.post(ADD_TO_CART_GUEST, req)
      commit(UPDATE_CART, {items: data.cartItems})
      if (!state.guestCartId && data.uuid) {
        commit(ADD_GUEST_CART_ID, {guestCartId: data.uuid})
      }
    }
  },
  async getCart ({ commit, rootGetters, state }) {
    let {data} = rootGetters['users/isLoggedIn']
        ? await api.get(GET_CART)
        : await api.get(GET_CART_GUEST + (state.guestCartId ? `?uuid=${state.guestCartId}` : ''))
    if (data) {
      commit(UPDATE_CART, {items: data.cartItems})
    }
  }
}

// mutations
const mutations = {
  [PRODUCTS] (state, {products}) {
    state.products = products
  },
  [PRODUCT] (state, {product}) {
    state.product = product
  },
  [PRODUCT_TYPE] (state, {productTypes}) {
    state.productTypes = productTypes
  },
  [FAVOURITES] (state, {favourite}) {
    if (state.favourites.find(f => f.id === favourite.id)) {
      state.favourites = state.favourites.filter(f => f.id !== favourite.id)
    } else {
      state.favourites.push(favourite)
    }
  },
  [ADD_TO_CART] (state, {item}) {
    if (!state.cart.find(c => c.id === item.id)) { state.cart.push(item) }
  },
  [UPDATE_CART] (state, {items}) {
    state.cart = items
  },
  [UPDATE_QUANTITY] (state, {id, quantity}) {
    let cartItem = state.cart.find(c => c.id === id)
    if (cartItem) {
      if (quantity < 1) {
        state.cart = state.cart.filter(c => c.id !== id)
      } else {
        cartItem.quantity = quantity
      }
    }
  },
  [REMOVE_ITEM] (state, {id}) {
    let cartItem = state.cart.find(c => c.id === id)
    if (cartItem) {
      state.cart = state.cart.filter(c => c.id !== id)
    }
  },
  [ADD_GUEST_CART_ID] (state, {guestCartId}) {
    state.guestCartId = guestCartId
    if (Cookie) {
      Cookie.set('guest_cart_id', guestCartId) // for server rendering
    }
  },
  [REMOVE_GUEST_CART_ID] (state) {
    state.guestCartId = null
    if (Cookie) {
      Cookie.remove('guest_cart_id')
    }
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
