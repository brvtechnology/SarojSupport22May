import {LOGIN, LOGIN_SUCCESS, LOGIN_FAILED, LOGOUT, STOP_GREET, REGISTER, REGISTER_SUCCESS, REGISTER_FAILED, SEND_OTP, VERIFY_OTP, CREATE_REFERRAL, SAVE_CURRENT_USER, SET_AUTH_TOKEN} from '../util/mutation-types'
import api from '../api'
import {LOGIN as USER_LOGIN, REGISTER as USER_REGISTER, OTP_SEND, OTP_VERIFY, ADD_REFERRAL, GET_USER_DATA} from '../api/api-endpoints'
const Cookie = process.client ? require('js-cookie') : undefined

// state
const state = () => ({
  accessToken: null,
  currentUser: {},
  pending: false,
  showGreetings: false,
  loginResult: {},
  registrationPending: false,
  registrationResult: {},
  otpEmail: {
    hasError: false,
    message: '',
    verified: false
  },
  otpPhone: {
    hasError: false,
    message: '',
    verified: false
  },
  addReferralMessage: ''
})

// getters
const getters = {
  isLoggedIn: state => {
    return !!state.accessToken
  }
}

// actions
const actions = {
  async login ({commit, dispatch}, user) {
    commit(LOGIN)
    try {
      let {data: userData} = await api.post(USER_LOGIN, user)
      commit(LOGIN_SUCCESS, {token: userData.authToken, user: userData.user})
      await dispatch('product/getCart', null, {root: true})
    } catch (e) {
      let response = e.response
      if (response && response.status === 400) {
        commit(LOGIN_FAILED, {msg: response.data.message})
      }
    }
  },
  async register ({commit}, user) {
    commit(REGISTER)
    try {
      let {data: userData} = await api.post(USER_REGISTER, user)
      commit(REGISTER_SUCCESS, {user: userData})
    } catch (e) {
      let response = e.response
      if (response && response.status === 400) {
        commit(REGISTER_FAILED, {msg: response.data.message})
      }
    }
  },
  async logout ({commit}) {
    commit(LOGOUT)
  },
  async sendOtp ({commit, dispatch, state}, type) {
    try {
      let payload = {
        userId: state.currentUser.id,
        type
      }
      await api.post(OTP_SEND, payload)
      commit(SEND_OTP, {type, hasError: false})
    } catch (e) {
      let response = e.response
      if (response && response.status === 400) {
        commit(SEND_OTP, {type, hasError: true, message: response.data.message})
      }
    }
  },
  async verifyOtp ({commit, dispatch, state}, payload) {
    try {
      payload.userId =state.currentUser.id
      let {data} = await api.post(OTP_VERIFY, payload)
      if (data && data.code === 'GRAMIN-200') {
        commit(LOGIN_SUCCESS, {token: data.token, user: data.user})
      }
      commit(VERIFY_OTP, {type: payload.type, hasError: false})
    } catch (e) {
      let response = e.response
      if (response && response.status === 400) {
        commit(VERIFY_OTP, {type: payload.type, hasError: true, message: response.data.message})
      }
    }
  },
  async addReferral ({commit}, referrerId) {
    try {
      await api.post(ADD_REFERRAL, referrerId)
      commit(CREATE_REFERRAL, {msg: 'success'})
    } catch (e) {
      let response = e.response
      if (response && response.status === 400) {
        commit(CREATE_REFERRAL, {msg: response.data.message})
      }
    }
  },
  async getCurrentUser ({commit}) {
    try {
      let {data: user} = await api.post(GET_USER_DATA)
      commit(SAVE_CURRENT_USER, {user})
    } catch (e) {
      let response = e.response
      if (response && response.status === 400) {
        console.log('unable to fetch user')
      }
    }
  },
}

// mutations
const mutations = {
  [LOGIN] (state) {
    state.pending = true
  },
  [LOGIN_SUCCESS] (state, {token, user}) {
    state.pending = false
    state.accessToken = token
    if (Cookie) {
      Cookie.set('token', token) // for server rendering
    }
    state.currentUser = user
    state.loginResult = {
      type: 'success',
      msg: `Welcome ${state.currentUser.first_name}`
    }
  },
  [LOGIN_FAILED] (state, {msg}) {
    state.pending = false
    state.accessToken = null
    if (Cookie) {
      Cookie.remove('token')
    }
    state.currentUser = {}
    state.loginResult = {
      type: 'failed',
      msg: msg
    }
  },
  [SET_AUTH_TOKEN] (state, {token}) {
    state.accessToken = token
  },
  [REGISTER] (state) {
    state.registrationPending = true
  },
  [REGISTER_SUCCESS] (state, {user}) {
    state.registrationPending = false
    state.currentUser = user
    state.registrationResult = {
      type: 'success',
      msg: `Welcome ${state.currentUser.name}`
    }
  },
  [REGISTER_FAILED] (state, {msg}) {
    state.registrationPending = false
    state.accessToken = null
    if (Cookie) {
      Cookie.remove('token')
    }
    state.currentUser = {}
    state.registrationResult = {
      type: 'failed',
      msg: msg
    }
  },
  [LOGOUT] (state) {
    state.accessToken = null
    if (Cookie) {
      Cookie.remove('token')
    }
    state.currentUser = null
  },
  [STOP_GREET] (state) {
    state.showGreetings = false
  },
  [SEND_OTP] (state, {type, hasError, message = ''}) {
    if (type === 'email') {
      state.otpEmail.hasError = hasError
      state.otpEmail.message = message
    } else {
      state.otpPhone.hasError = hasError
      state.otpPhone.message = message
    }
  },
  [VERIFY_OTP] (state, {token, message, type}) {
    if (token) {
      state.accessToken = token
      if (Cookie) {
        Cookie.set('token', token) // for server rendering
      }
    }
    if (message) {
      if (type === 'email') {
        state.otpEmail.verified = false
        state.otpEmail.hasError = true
        state.otpEmail.message = message
      } else {
        state.otpPhone.verified = false
        state.otpPhone.hasError = true
        state.otpPhone.message = message
      }
    } else {
      if (type === 'email') {
        state.otpEmail.verified = true
        state.otpEmail.hasError = false
        state.otpEmail.message = ''
      } else {
        state.otpPhone.verified = true
        state.otpPhone.hasError = false
        state.otpPhone.message = ''
      }
    }
  },
  [CREATE_REFERRAL] (state, {msg}) {
    state.addReferralMessage = msg
  },
  [SAVE_CURRENT_USER] (state, {user}) {
    state.currentUser = user
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
