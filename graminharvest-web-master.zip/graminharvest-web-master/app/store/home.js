// state
import { HOME } from '../util/mutation-types'
import { GET_HOME } from '../api/api-endpoints'
import api from '../api'

const state = () => ({
  items: []
})

// getters
const getters = {}

// actions
const actions = {
  async getHome ({ commit }) {
    let {data} = await api.get(GET_HOME)
    commit(HOME, {items: data})
  }
}

// mutations
const mutations = {
  [HOME] (state, {items}) {
    state.items = items
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
