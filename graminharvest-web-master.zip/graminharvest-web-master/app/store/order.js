// state
import {ORDER_STATUS, GET_ORDERS, REMOVE_GUEST_CART_ID} from '../util/mutation-types'
import {ADD_ORDER, GET_USER_ORDERS, ADD_ORDER_GUEST} from '../api/api-endpoints'
import api from '../api'

const state = () => ({
  orderStatus: false,
  orderMessage: '',
  orders: []
})

// getters
const getters = {}

// actions
const actions = {
  async addOrder ({ commit, rootGetters, dispatch }, payload) {
    try {
      let {data} = await api.post(ADD_ORDER, payload)
      if (data) {
        if (data.hasPaymentLink) {
          commit(ORDER_STATUS, {status: true, message: 'ORDER_INITIATED'})
          window.location.href = data.paymentLink
        }
        if (data.isCompleted) {
          commit(ORDER_STATUS, {status: true, message: 'ORDER_PLACED'})
        }
      }
    } catch (e) {
      let response = e.response
      if (response && response.status === 400) {
        commit(ORDER_STATUS, {status: false, message: response.data.message})
      }
    }
  },
  async addOrderGuest ({ commit, dispatch }, payload) {
    try {
      let {data} = await api.post(ADD_ORDER_GUEST, payload)
      if (data && data.hasPaymentLink) {
        commit(ORDER_STATUS, {status: true, message: 'ORDER_INITIATED'})
        window.location.href = data.paymentLink
      }
      if (payload.cartKey) {
        commit(`product/${REMOVE_GUEST_CART_ID}`)
      }
    } catch (e) {
      let response = e.response
      if (response && response.status === 400) {
        commit(ORDER_STATUS, {status: false, message: response.data.message})
      }
    }
  },

  async getOrders ({ commit }) {
    let {data} = await api.get(GET_USER_ORDERS)
    commit(GET_ORDERS, {orders: data})
  }
}

// mutations
const mutations = {
  [ORDER_STATUS] (state, {status, message}) {
    state.orderStatus = status
    state.orderMessage = message
  },
  [GET_ORDERS] (state, {orders}) {
    if (orders) { state.orders = orders }
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
