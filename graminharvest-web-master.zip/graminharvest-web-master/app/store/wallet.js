import { WALLET_BALANCE, ADD_TO_WALLET } from '../util/mutation-types'
import { DEPOSIT_MONEY, GET_WALLET } from '../api/api-endpoints'
import api from '../api'

// state
const state = () => ({
    wallet: {},
    paymentUrl: ''
})

// getters
const getters = {}

// actions
const actions = {
    async getWallet ({ commit }) {
        let {data: wallet} = await api.get(GET_WALLET)
        commit(WALLET_BALANCE, {wallet})
    },
    async depositMoney ({ commit }, amount) {
        let {data: paymentUrl} = await api.post(DEPOSIT_MONEY, amount)
        commit(ADD_TO_WALLET, paymentUrl)
        window.location.href = paymentUrl
    }
}

// mutations
const mutations = {
    [WALLET_BALANCE] (state, {wallet}) {
        state.wallet = wallet
    },
    [ADD_TO_WALLET] (state, {paymentUrl}) {
        state.paymentUrl = paymentUrl
    }
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}
