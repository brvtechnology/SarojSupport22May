
'use strict'
module.exports = function (sequelize, DataTypes) {
  return sequelize.define('UserOtp', {
    user_id: {
      type: DataTypes.INTEGER,
      field: 'user_id',
      allowNull: false,
      unique: true
    },
    email_otp: {
      type: DataTypes.INTEGER,
      field: 'email_otp',
      allowNull: true
    },
    phone_otp: {
      type: DataTypes.STRING,
      field: 'phone_otp',
      allowNull: true
    }
  })
}
