const config = require('config')
const sgMail = require('@sendgrid/mail')
sgMail.setApiKey(config.get('sendGridKey'))
const defaultSender = config.get('senderEmail.emailId')

const sendMail = async (to, subject, text) => {
  return sgMail.send({ to, from: defaultSender, subject, text })
}

module.exports = {
  sendMail
}
