const bulkUpdate = async (queryRequest) => {
  try {
    let sequelize = queryRequest.db.sequelize
    console.log(queryRequest)
    let query =
    `UPDATE "${queryRequest.modelName}s"  set ${queryRequest.attributeName} = :value
     WHERE ${queryRequest.conditionAttributeName} IN (:conditionArr)
    `
    console.log(query)
    const result = await sequelize.query(query,
      {replacements: {
        value: queryRequest.value,
        conditionArr: queryRequest.conditionArr},
      type: sequelize.QueryTypes.SELECT})
    return result
  } catch (error) {
    throw new Error(error)
  }
}

module.exports = {
  bulkUpdate
}
