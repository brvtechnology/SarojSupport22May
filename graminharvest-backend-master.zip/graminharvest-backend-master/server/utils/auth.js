'use strict'
const config = require('config')

// validate jwt token
const AUTH_TYPE_APP = 'app'

const validateAppJWT = async function (decoded, request) {
  if (!decoded || !decoded.valid || AUTH_TYPE_APP !== decoded.type) {
    return { isValid: false }
  } else {
    return { isValid: true }
  }
}

var validateBasicAuth = function (request, username, password) {
  const users = config.get('swaggerUser.users')
  if (users.indexOf(username) < 0) {
    return { isValid: false, credentials: null }
  }

  const isValid = password === config.get('swaggerUser.password')
  let credentials = null
  if (isValid) {
    credentials = {name: username}
  }

  return { isValid, credentials }
}

module.exports = {
  validateAppJWT,
  validateBasicAuth
}
