'use strict'

const boom = require('boom')
const config = require('config')
const uuidv4 = require('uuid/v4')
const walletService = require('./walletService')
const { placeOrderSuccessfully } = require('../order/orderHandler')
const REDIRECT_URL = config.get('app.clientGateway') + '/profile'
const CALLBACK_URL = config.get('app.backendGateway') + '/' + config.get('app.name') + '/api/v1/wallet/confirmPaymentStatus'

const depositMoney = async (req) => {
  try {
    /* Algo :
      1.check user has wallet
      2.check user exist
      3.get url from instamojo with confirmation
      4.create transaction request
    */

    let db = req.getDb()
    let wallet = db.getModel('UserPaymentInfo')
    let TransactionTable = db.getModel('UserPaymentTransaction')
    let UserDb = db.getModel('UserWeb')

    let { amount } = req.payload
    let {id: userId} = req.auth.credentials
    // Find if User Has a Wallet
    let findUserWallet = await wallet.findOne({where: {userId}, plain: true})
    if (!findUserWallet) {
      return boom.badRequest(`Wallet with user Id: ${userId} doesn't exists`)
    }
    let userDetail = await UserDb.findById(userId)
    if (!userDetail) return boom.badRequest("User Doesn't Exist")
    if (!userDetail.phone_verified || !userDetail.email_verified) return boom.badRequest('User phone or e-mail is not verified')
    let paymentRequestBody = {
      purpose: 'ADD_TO_WALLET',
      amount,
      phone: userDetail.phone,
      email: userDetail.email,
      buyer_name: userDetail.first_name,
      redirect_url: REDIRECT_URL,
      send_email: true,
      webhook: CALLBACK_URL,
      send_sms: true,
      allow_repeated_payments: false
    }
    console.log(paymentRequestBody)
    let initiatePayment = await walletService.initiatePayment(paymentRequestBody)
    if (initiatePayment && initiatePayment.success) {
      let paymentRequest = initiatePayment.payment_request
      if (!paymentRequest) {
        return boom.badRequest('Something Went Wrong! Try Again!!!')
      }
      let makeTransactionDetail = {
        userId,
        orderId: uuidv4(),
        transactionAmount: amount,
        transactionId: paymentRequest.id,
        statusCode: 0, // -1 : Failed, Success: 1, 0: Pending
        purpose: 'ADD_TO_WALLET',
        paymentUrl: paymentRequest.longurl,
        info: Object.assign({}, paymentRequest, {paymentGatewayName: 'INSTAMOJO'})
      }

      TransactionTable.create(makeTransactionDetail)
      return paymentRequest.longurl
    } else return boom.badRequest('Something Went Wrong! Try Again!!!')
  } catch (error) {
    const errorMessage = `Failed to Deposit Money in Wallet---Contact HelpDesk`
    return boom.badRequest(errorMessage)
  }
}

const getUserBalance = async (req) => {
  try {
    let db = req.getDb()
    const Wallet = db.getModel('UserPaymentInfo')
    const {id: userId} = req.auth.credentials
    return await Wallet.findOne({where: {userId}})
  } catch (e) {
    return boom.badRequest('Unable to fetch user wallet')
  }
}

const confirmPaymentStatus = async (req) => {
  try {
    let db = req.getDb()
    let TransactionTable = db.getModel('UserPaymentTransaction')
    let UserWalletModel = db.getModel('UserPaymentInfo')
    let UserModel = db.getModel('UserWeb')
    let orderModel = db.getModel('Order')
    let {payment_id: paymentId, payment_request_id: paymentRequestId, status, purpose, fees} = req.payload
    console.log('Request payload for confirm payment: ', req.payload)
    let findOrder = await orderModel.findOne({where: {info: { pid: paymentRequestId }}, raw: true})
    let findTransaction = await TransactionTable.findOne({where: { transactionId: paymentRequestId }, plain: true})
    if (purpose === 'BUY_PRODUCT' && findOrder && status === 'Credit' && findOrder.info.paymentStatus === 'Initiated') {
      // check if user id is 0
      if (findOrder.userId === 0) {
        // TO DO: update transaction order
        await placeOrderSuccessfully({orderModel, orderObj: findOrder})
        await TransactionTable.update({
          statusCode: 1
        }, {where: {orderId: findOrder.orderId}})
      } else {
        // To DO: update Transaction order
        await walletService.deductFromWallet({WalletModel: UserWalletModel, moneyToDeductFromWallet: findOrder.walletAmount, userId: findOrder.userId})
        await placeOrderSuccessfully({orderModel, orderObj: findOrder})
        await TransactionTable.update({
          statusCode: 1
        }, {where: {orderId: findOrder.orderId}})
      }
    } else if (purpose === 'ADD_TO_WALLET' && findTransaction.statusCode === 0 && status === 'Credit') {
      await walletService.addMoneyToWallet(findTransaction.transactionAmount, UserWalletModel, UserModel, findTransaction.userId, 'addToDeposit')
      let modifiedInfo = Object.assign({}, findTransaction.info, {instamojo_payment_id: paymentId})
      let modifiedStatus = 1 // Making Status as Success
      await findTransaction.updateAttributes({ info: modifiedInfo, statusCode: modifiedStatus, feesPaid: fees })
    } else if (findTransaction && findTransaction.status === 0 && status === 'Failed') {
      let modifiedInfo = Object.assign({}, findTransaction.info, {instamojo_payment_id: paymentId})
      let modifiedStatus = -1 // Making Status as Failed
      await findTransaction.updateAttributes({ info: modifiedInfo, status: modifiedStatus, feesPaid: fees })
    } else return ('Ok')

    return ('Ok')
  } catch (error) {
    console.log(error)
    return ('OK')
  }
}

module.exports = {
  depositMoney,
  getUserBalance,
  confirmPaymentStatus
}
