'use strict'

const config = require('config')

const walletHandler = require('./walletHandler')
const walletValidations = require('./walletValidations')

const API = '/' + config.get('app.name') + '/api/v1/wallet'

const routes = []

routes.push({
  path: API + '/depositMoney',
  method: 'POST',
  handler: walletHandler.depositMoney,
  options: {
    auth: 'jwt-app',
    tags: ['api'],
    validate: walletValidations.depositMoney
  }
})

routes.push({
  path: API + '/getUserBalance',
  method: 'GET',
  handler: walletHandler.getUserBalance,
  options: {
    auth: 'jwt-app',
    tags: ['api']
  }
})
routes.push({
  path: API + '/confirmPaymentStatus',
  method: 'POST',
  handler: walletHandler.confirmPaymentStatus,
  options: {
    auth: false,
    tags: ['api'],
    validate: walletValidations.confirmPaymentStatus
  }
})
/*
routes.push({
  path: API + '/getUserPaymentInfo',
  method: 'GET',
  handler: walletHandler.getUserPaymentInfo,
  options: {
    auth: 'jwt-app',
    tags: ['api']
  }
})
 */
// routes.push({
//   path: API + '/addPromoMoney',
//   method: 'POST',
//   handler: walletHandler.addPromoMoney,
//   options: {
//     auth: {
//       strategy: 'jwt-question-engine',
//       scope: 'admin'
//     },
//     tags: ['api'],
//     validate: walletValidations.addPromoMoney
//   }
// })
/*
routes.push({
  // path: API + '/findLastNTransactions/{currentPage}',
  path: API + '/findLastNTransactions',
  method: 'GET',
  handler: walletHandler.findLastNTransactions,
  options: {
    auth: 'jwt-app',
    tags: ['api'],
    validate: walletValidations.findLastNTransactions
  }
})
 */

module.exports = routes
