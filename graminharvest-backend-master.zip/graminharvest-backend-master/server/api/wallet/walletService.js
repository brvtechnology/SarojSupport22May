'use strict'

const config = require('config')
const axios = require('axios')
const boom = require('boom')
const uuidv4 = require('uuid/v4')
const {sendSMS} = require('../awsUtils/awsHandler')
const PAYMENT_GATEWAY_URL = config.get('instamojo.createrequesturl')
const PAYMENT_HEADERS = config.get('instamojo.headers')

const initiatePayment = async (data) => {
  let paymentReq
  try {
    paymentReq = await axios({
      method: 'POST',
      url: PAYMENT_GATEWAY_URL,
      headers: PAYMENT_HEADERS,
      data
    })
  } catch (err) {
    console.log(err)
    console.log(err.data.message)
  }
  return paymentReq.data
}

const createWallet = async (Wallet, userId) => {
  try {
    let user = {userId, paymentInfo: []}
    // check if wallet already created
    let userWallet = await Wallet.findOne({where: { userId }})
    if (!userWallet) {
      let userWallet = await Wallet.create(user)
      if (!userWallet) { /** Just being extra paranoid */
        throw new Error(`Wallet creation failed`)
      }
    }
    return 'success'
  } catch (error) {
    return boom.internal('Wallet Creation Failed')
  }
}

const addMoneyToWallet = async (moneyToAdd, userWalletModel, userModel, userId, mode, UserPromoTrxModel) => {
  let userWalletUpdated
  if (moneyToAdd && userWalletModel && userId && mode) {
    let [userWallet, user] = await Promise.all([
      userWalletModel.findOne({where: {userId}}),
      userModel.findById(userId)])
    if (!userWallet || !user || !user.phone || !user.email || !user.phone_verified || !user.email_verified) throw new Error('Something Went Wrong')
    let userPhone = user.phone
    if (mode === 'addToDeposit' && moneyToAdd > 9.0) {
      let modifiedUserDeposit = userWallet.userDeposit + moneyToAdd // Add money to user deposit Money
      userWalletUpdated = await userWallet.updateAttributes({userDeposit: modifiedUserDeposit})
      await sendSMS({
        phone: `${userPhone}`,
        message: `\nRs${moneyToAdd} is Added to Wallet.\n#organic \nwww.graminharvest.com`,
        subject: 'Money Added to Wallet',
        source: 'DepositToWallet'
      })
    } else if (mode === 'addToPromo') {
      var promoStatus = 0
      // let trackPromoMoneyini
      let modifiedUserPromo = userWallet.userPromoMoney + moneyToAdd // Add money to user promo Money
      let [userWalletUpdated, trackPromoMoneyini] = await Promise.all([
        userWallet.updateAttributes({userPromoMoney: modifiedUserPromo}),
        await trackPromoMoneyCreate(userId, moneyToAdd, 'Money added to wallet as promo', UserPromoTrxModel, promoStatus)])
      if (!userWalletUpdated) console.log('Error while updating user wallet')
      await sendSMS({
        phone: `${userPhone}`,
        message: `Hi ${user.first_name}, \nRs${moneyToAdd} promo money has been added to your wallet
        \n#organic, \nwww.graminharvest.com`,
        subject: 'Promo Money Added',
        source: 'PromoMoneyToWallet'
      })
      promoStatus = 1
      await trackPromoMoneyUpdate(userId, moneyToAdd, 'Money added to wallet as promo', UserPromoTrxModel, promoStatus, trackPromoMoneyini)
    } else throw new Error('Mode Not Supported or Wrong Amount')
  } else throw new Error('All Values Are not Provided')
  if (userWalletUpdated) return userWalletUpdated
}

const trackPromoMoneyCreate = async (userId, promoAmount, purposeMessage, userPromoTrxModel, promoStatus) => {
  let userPromoUpdated = await userPromoTrxModel.create({userId: userId,
    promoMoney: promoAmount,
    orderId: uuidv4(),
    purpose: purposeMessage,
    statusCode: promoStatus }, {returning: true})
  if (!userPromoUpdated) console.log('Failed to insert into UserPromoTransactions')
  console.log('value of userPromoUpdated:' + userPromoUpdated.dataValues)
  return userPromoUpdated.dataValues.orderId
}
const trackPromoMoneyUpdate = async (userId, promoAmount, purposeMessage, UserPromoTrxModel, promoStatus, trackPromoMoneyini) => {
  UserPromoTrxModel.update({statusCode: promoStatus}, {where: {orderId: trackPromoMoneyini, statusCode: 0}})
}

const payMoneyFromWallet = async (WalletModel, OrderTransactionModel, userId, orderId, amount) => {
  try {
    let wallet = await WalletModel.findOne({where: {userId}, raw: true})
    if (!wallet) {
      return boom.badRequest('Failed to fetch user wallet')
    }
    let {userDeposit, userPromoMoney} = wallet
    let order = {
      userId: userId,
      orderId: orderId,
      transactionAmount: amount,
      purpose: 'BUY_PRODUCT',
      statusCode: 0
    }
    if ((userDeposit + userPromoMoney) < amount) {
      return boom.badRequest("You don't have enough balance to your wallet")
    } else if (userPromoMoney > amount) {
      let updatedUserPromoMoney = userPromoMoney - amount
      await Promise.all([
        OrderTransactionModel.create(order),
        wallet.updateAttributes({userPromoMoney: updatedUserPromoMoney})
      ])
      return 'success'
    } else {
      let updatedUserDepositMoney = userDeposit - (amount - userPromoMoney)
      let updatedUserPromoMoney = 0
      await Promise.all([
        OrderTransactionModel.create(order),
        wallet.updateAttributes({userDeposit: updatedUserDepositMoney, userPromoMoney: updatedUserPromoMoney})
      ])
      return 'success'
    }
  } catch (error) {
    return boom.badRequest('Unable to pay money from wallet')
  }
}
const deductFromWallet = async ({WalletModel, moneyToDeductFromWallet, userId}) => {
  try {
    let wallet = await WalletModel.findOne({where: {userId}, raw: true})
    if (!wallet) {
      return boom.badRequest('Failed to fetch user wallet')
    }
    let {userDeposit, userPromoMoney} = wallet
    if ((userDeposit + userPromoMoney) < moneyToDeductFromWallet) {
      return boom.badRequest("You don't have enough balance to your wallet")
    } else if (userPromoMoney > moneyToDeductFromWallet) {
      let updatedUserPromoMoney = userPromoMoney - moneyToDeductFromWallet
      await WalletModel.update({userPromoMoney: updatedUserPromoMoney}, {where: {userId}})

      return 'success'
    } else {
      let updatedUserDepositMoney = userDeposit - (moneyToDeductFromWallet - userPromoMoney)
      let updatedUserPromoMoney = 0
      await WalletModel.update({userDeposit: updatedUserDepositMoney, userPromoMoney: updatedUserPromoMoney}, {where: {userId}})

      return 'success'
    }
  } catch (error) {
    return boom.badRequest('Unable to pay money from wallet')
  }
}

module.exports = {
  initiatePayment,
  createWallet,
  addMoneyToWallet,
  payMoneyFromWallet,
  deductFromWallet
}
