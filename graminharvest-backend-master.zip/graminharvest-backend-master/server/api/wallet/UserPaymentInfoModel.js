'use strict'

module.exports = (sequelize, DataTypes) => {
  return sequelize.define('UserPaymentInfo', {
    userId: {
      type: DataTypes.INTEGER,
      field: 'user_id',
      allowNull: false
    },
    paymentInfo: {
      type: DataTypes.JSONB,
      field: 'payment_info',
      allowNull: true
    },
    userDeposit: {
      type: DataTypes.DOUBLE,
      field: 'user_deposit_money',
      allowNull: false,
      defaultValue: 0
    },
    userPromoMoney: {
      type: DataTypes.DOUBLE,
      field: 'user_promo_money',
      allowNull: false,
      defaultValue: 0
    },
    userLockedMoney: {
      type: DataTypes.DOUBLE,
      field: 'user_locked_money',
      allowNull: false,
      defaultValue: 0
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: true
    }

  })
}
