'use strict'

module.exports = (sequelize, DataTypes) => {
  return sequelize.define('UserOrderTransaction', {
    userId: {
      type: DataTypes.INTEGER,
      field: 'user_id',
      allowNull: false
    },
    orderId: {
      type: DataTypes.UUID,
      field: 'order_id',
      allowNull: false
    },
    transactionAmount: {
      type: DataTypes.DOUBLE,
      field: 'transaction_amount',
      allowNull: false
    },
    purpose: {
      type: DataTypes.TEXT,
      field: 'purpose',
      allowNull: false
    },
    statusCode: {
      type: DataTypes.INTEGER,
      field: 'status_code',
      allowNull: false
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: true
    }
  })
}
