'use strict'

module.exports = (sequelize, DataTypes) => {
  return sequelize.define('UserPaymentTransaction', {
    userId: {
      type: DataTypes.INTEGER,
      field: 'user_id',
      allowNull: false
    },
    orderId: {
      type: DataTypes.UUID,
      field: 'order_id',
      allowNull: false
    },
    transactionAmount: {
      type: DataTypes.DOUBLE,
      field: 'transaction_amount',
      allowNull: false
    },
    feesPaid: {
      type: DataTypes.DOUBLE,
      field: 'fees_paid',
      allowNull: true
    },
    transactionId: {
      type: DataTypes.TEXT,
      field: 'transaction_id',
      allowNull: false
    },
    statusCode: {
      type: DataTypes.INTEGER,
      field: 'status_code',
      allowNull: false
    },
    purpose: {
      type: DataTypes.TEXT,
      field: 'purpose',
      allowNull: false
    },
    paymentUrl: {
      type: DataTypes.TEXT,
      field: 'payment_url',
      allowNull: false
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: false
    }

  })
}
