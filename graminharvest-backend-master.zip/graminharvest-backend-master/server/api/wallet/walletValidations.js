'use strict'

const joi = require('joi')

const depositMoney = {
  payload: {
    amount: joi.number().integer().positive().required()
  },
  options: {
    allowUnknown: false
  }
}

const confirmPaymentStatus = {
  payload: {
    payment_id: joi.string().required(),
    payment_request_id: joi.string().required(),
    status: joi.string().required(),
    fees: joi.string().required()
  },
  options: {
    allowUnknown: true
  }
}

module.exports = {
  depositMoney,
  confirmPaymentStatus
}
