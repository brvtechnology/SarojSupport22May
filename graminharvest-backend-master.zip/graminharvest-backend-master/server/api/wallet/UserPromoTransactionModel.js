'use strict'

module.exports = (sequelize, DataTypes) => {
  return sequelize.define('UserPromoTransactions', {
    userId: {
      type: DataTypes.INTEGER,
      field: 'user_id',
      allowNull: false
    },
    promoMoney: {
      type: DataTypes.DOUBLE,
      field: 'promo_amount',
      allowNull: false
    },
    orderId: {
      type: DataTypes.UUID,
      field: 'order_id',
      allowNull: false
    },
    purpose: {
      type: DataTypes.TEXT,
      field: 'purpose',
      allowNull: false
    },
    statusCode: {
      type: DataTypes.INTEGER,
      field: 'status_code',
      allowNull: false
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: true
    }

  })
}
