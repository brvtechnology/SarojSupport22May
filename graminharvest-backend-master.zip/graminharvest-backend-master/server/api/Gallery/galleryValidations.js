'use strict'

const joi = require('joi')

const addImageToGallery = {
  payload: {
    name: joi.string().required(),
    description: joi.string().allow(null),
    image_url: joi.string().required(),
    info: joi.object().allow(null)
  },
  options: {
    allowUnknown: true
  }
}

const editImageToGallery = {
  payload: {
    img_id: joi.number().integer().required(),
    name: joi.string().required(),
    description: joi.string().required(),
    image_url: joi.string().required(),
    info: joi.object().allow(null)
  },
  options: {
    allowUnknown: true
  }
}

module.exports = {
  addImageToGallery,
  editImageToGallery
}
