'use strict'

const config = require('config')

const productTypeHandler = require('./galleryHandler')
const productTypeValidations = require('./galleryValidations')

const API = '/' + config.get('app.name') + '/api/1.0/gallery'

const routes = []

routes.push({
  path: API + '/addImageToGallery',
  method: 'POST',
  handler: productTypeHandler.addImageToGallery,
  options: {
    auth: false,
    tags: ['api'],
    validate: productTypeValidations.addImageToGallery
  }
})

routes.push({
  path: API + '/editImageToGallery',
  method: 'POST',
  handler: productTypeHandler.editImageToGallery,
  options: {
    auth: false,
    tags: ['api'],
    validate: productTypeValidations.editImageToGallery
  }
})

routes.push({
  path: API + '/getImageGallery',
  method: 'GET',
  handler: productTypeHandler.getImageGallery,
  options: {
    auth: false,
    tags: ['api']
  }
})
routes.push({
  path: API + '/getImageGalleryWeb',
  method: 'GET',
  handler: productTypeHandler.getImageGalleryWeb,
  options: {
    auth: false,
    tags: ['api']
  }
})

module.exports = routes
