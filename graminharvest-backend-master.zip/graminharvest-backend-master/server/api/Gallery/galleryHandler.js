'use strict'

const boom = require('boom')

const logger = require('../../utils/logger')

const addImageToGallery = async (req) => {
  try {
    let db = req.getDb()
    let productType = db.getModel('Gallery')
    return await productType.create(req.payload)
  } catch (error) {
    const errorMessage = `Failed to add Image Item`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const editImageToGallery = async function (req) {
  try {
    let db = req.getDb()
    let {img_id: id} = req.payload
    let imgModel = db.getModel('Gallery')
    let desiredproductType = await imgModel.findById(id)
    if (desiredproductType) {
      return desiredproductType.updateAttributes(req.payload)
    } else return boom.badRequest('Editing Image Failed')
  } catch (error) {
    const errorMessage = `Failed to edit Image`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getImageGallery = async (req) => {
  try {
    let db = req.getDb()
    let galleryModel = db.getModel('Gallery')
    return await galleryModel.findAll()
  } catch (error) {
    const errorMessage = `Failed to get Gallery Image`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getImageGalleryWeb = async (req) => {
  try {
    let db = req.getDb()
    let galleryModel = db.getModel('Gallery')
    let allgalleryImages = await galleryModel.findAll({raw: true})
    return allgalleryImages.filter(agi => agi.info.show === 'Yes')
  } catch (error) {
    const errorMessage = `Failed to get Gallery Image`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

module.exports = {
  addImageToGallery,
  editImageToGallery,
  getImageGallery,
  getImageGalleryWeb
}
