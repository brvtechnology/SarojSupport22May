'use strict'

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('Gallery', {
    name: {
      type: DataTypes.STRING,
      field: 'img_name',
      allowNull: false
    },
    description: {
      type: DataTypes.STRING,
      field: 'img_description',
      allowNull: true
    },
    image_url: {
      type: DataTypes.STRING,
      field: 'img_src',
      allowNull: false
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: false
    }
  })
}
