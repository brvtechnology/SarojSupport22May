
'use strict'

const boom = require('boom')
const httpStatus = require('http-status')
const logger = require('../../utils/logger')
const JWT = require('jsonwebtoken')
// const moment = require('moment')
const config = require('config')
const userService = require('../admin/userService.js')
const {createReferral} = require('./userService.js')
const awsHandler = require('../awsUtils/awsHandler')
const {sendMail} = require('../../utils/email')
const { createWallet } = require('../wallet/walletService')

const login = async (req) => {
  try {
    let db = req.getDb()
    let User = db.getModel('UserWeb')
    let {email, password} = req.payload
    let user = await User.findOne({where: {email, email_verified: true, phone_verified: true}})

    if (!user) {
      return boom.badRequest('E-mail not found')
    }
    let {password: saltedPassword, salt} = user.dataValues

    if (await !userService.validatePassword(saltedPassword, salt, password)) {
      return boom.badRequest('E-mail or password is incorrect')
    } else {
      // Return Data to Front end
      let token =
                    {
                      valid: true,
                      id: user.dataValues.id,
                      type: 'app',
                      exp: new Date().getTime() + 30 * 60 * 1000
                    }
      delete user.password
      delete user.salt
      return {
        authToken: JWT.sign(token, config.get('authSecrets.app')),
        user
      }
    }
  } catch (error) {
    const errorMessage = `Failed to login`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: httpStatus.BAD_REQUEST, message: errorMessage })
  }
}
const register = async (req) => {
  try {
    let {email, password, firstName, lastName, phone} = req.payload
    let db = req.getDb()
    let User = db.getModel('UserWeb')
    let user = await User.findOne({where: {email, email_verified: true}})
    if (user) {
      return boom.badRequest('E-mail already exists, please try with other e-mail')
    } else {
      let {saltedPassword, salt} = userService.saltHashPassword(password)
      let userDetails = await User.create({email, password: saltedPassword, salt, first_name: firstName, last_name: lastName, phone})

      delete userDetails.password
      delete userDetails.salt
      return userDetails
    }
  } catch (error) {
    const errorMessage = `Failed to Register`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: httpStatus.BAD_REQUEST, message: errorMessage })
  }
}

const sendOtp = async (req) => {
  try {
    let {type} = req.payload
    let db = req.getDb()
    let UserModel = db.getModel('UserWeb')
    let OtpModel = db.getModel('UserOtp')
    let {userId} = req.payload
    if (!(type === 'email' || type === 'phone')) throw new Error('Type Mismatch!!!')

    let user = await UserModel.findById(userId)
    // if (type === 'email' && user.email_verified) return ('Email Already Verified')
    // if (type === 'phone' && user.phone_verified) return ('Phone Number Already Verified')
    await sendOtpService({OtpModel, userId, type, email: user.email, phone: user.phone})
    // saveUserOtpInDb({OtpModel, userId, type, otp})
    return 'success'
  } catch (error) {
    const errorMessage = `Failed to Send Otp`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: httpStatus.BAD_REQUEST, message: errorMessage })
  }
}

// const saveUserOtpInDb = async ({OtpModel, userId, type, email, phone}) => {
//   console.log(userId, type, email, phone)
//   let userData = await OtpModel.findOne({where: {user_id: userId}})
//   if (!userData) {
//     await OtpModel.create({
//       user_id: userId,
//       email_otp: email,
//       phone_otp: phone
//     })
//   } else {
//     if (type === 'email') {
//       await OtpModel.update({email_otp: email})
//     } else if (type === 'phone') {
//       await OtpModel.update({phone_otp: phone})
//     } else {
//       return 'Type Mismatch'
//     }
//   }
// }

const allUsers = async (req) => {
  try {
    let db = req.getDb()
    let UserModel = db.getModel('UserWeb')
    return UserModel.findAll()
  } catch (error) {
    const errorMessage = `Failed to Get Users`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const sendOtpService = async ({OtpModel, userId, type, email, phone}) => {
  console.log('*****************************')
  let otp = generateOtp()
  let payload
  let userOtp = await OtpModel.findOne({where: {user_id: userId}})
  if (type === 'email') {
    let msg = `Here is your Otp to register in GraminHarvest ${otp}.\nPlease Note: Otp is valid for 15 minutes.\nDo not share this OTP with anyone.`

    await sendMail(email, 'Otp To Register in GraminHarvest', msg)
    payload = {
      email_otp: otp,
      user_id: userId
    }
  } else if (type === 'phone') {
    let data = {
      message: `Here is Otp for Graminharvest. Use it to verify your Mobile : ${otp}`,
      phone,
      subject: 'Otp for Registration'
    }
    await awsHandler.sendSMS(data)
    payload = {
      phone_otp: otp,
      user_id: userId
    }
  } else throw new Error('type Mismatch')
  if (!userOtp) {
    let x = await OtpModel.create(payload)
    console.log(x)
  } else {
    let x = await OtpModel.update(payload, {where: {user_id: userId}})
    console.log(x)
  }
}

function generateOtp () {
  var digits = '0123456789'
  let OTP = ''
  for (let i = 0; i < 4; i++) {
    OTP += digits[Math.floor(Math.random() * 10)]
  }
  return parseInt(OTP)
}
const verifyOtp = async (req) => {
  try {
    let {type, otp, userId} = req.payload
    let db = req.getDb()
    let UserModel = db.getModel('UserWeb')
    let OtpModel = db.getModel('UserOtp')
    let [userOtp] = await Promise.all([OtpModel.findOne({where: {user_id: userId}, raw: true})])
    console.log(otp, userOtp)
    // if (type === 'email' && user.email_verified) return ('Email Already Verified')
    // if (type === 'phone' && user.phone_verified) return ('Phone Number Already Verified')
    if (!userOtp) return boom.badRequest('Please generate an OTP')
    if (type === 'email' && otp === parseInt(userOtp.email_otp)) {
      await UserModel.update({email_verified: true}, {where: {id: userId}})
      return await validateUser(userId, UserModel, db.getModel('Cart'), db.getModel('UserPaymentInfo'))
    } else if (type === 'phone' && otp === parseInt(userOtp.phone_otp)) {
      await UserModel.update({phone_verified: true}, {where: {id: userId}})
      return await validateUser(userId, UserModel, db.getModel('Cart'), db.getModel('UserPaymentInfo'))
    }
    return boom.badRequest('OTP is not valid')
  } catch (error) {
    console.log(error)
    const errorMessage = `Otp Verification Failed`
    return boom.boomify(error, { statusCode: httpStatus.BAD_REQUEST, message: errorMessage })
  }
}

const checkAuth = async (req) => {
  let {id} = req.auth.credentials
  let db = req.getDb()
  let UserModel = db.getModel('UserWeb')
  let Cart = db.getModel('Cart')
  let Wallet = db.getModel('UserPaymentInfo')
  return validateUser(id, UserModel, Cart, Wallet)
}

const validateUser = async (id, UserModel, Cart, Wallet) => {
  try {
    let user = await UserModel.findOne({where: {id, email_verified: true, phone_verified: true}})
    if (!user) {
      return {
        code: 'GRAMIN-400',
        message: 'User not valid'
      }
    }

    let token = {
      valid: true,
      id: user.dataValues.id,
      type: 'app',
      exp: new Date().getTime() + 30 * 60 * 1000
    }
    // create wallet
    await createWallet(Wallet, id)
    let cart = await Cart.findOne({where: {userId: id}})
    if (!cart) {
      await Cart.create({ userId: id, cartItems: [] })
    }
    return {token: JWT.sign(token, config.get('authSecrets.app')), user, code: 'GRAMIN-200', message: 'User successfully validated'}
  } catch (e) {
    return boom.badRequest('Failed to generate token')
  }
}

const forGotPassword = async (req) => {
  try {
    let {type, email, phone} = req.payload
    let db = req.getDb()
    let UserModel = db.getModel('UserWeb')
    let OtpModel = db.getModel('UserOtp')
    let user
    if (type === 'email') {
      user = await UserModel.findOne({where: {email, email_verified: true}, raw: true})
      if (!user) throw new Error("This Email Doesn't Exist In our System")
    } else if (type === 'mobile') {
      user = await UserModel.findOne({where: {phone, phone_verified: true}})
      if (!user) throw new Error("This Number Doesn't Exist In our System")
    } else throw new Error('Type Mismatch!!!')

    await sendOtpService({OtpModel, userId: user.id, type, email: user.email, phone: user.phone})
    return `Otp Sent to your ${type}`
  } catch (error) {
    console.log(error)
    const errorMessage = `Otp Verification Failed`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: httpStatus.BAD_REQUEST, message: errorMessage })
  }
}
const changePassword = async (req) => {
  try {
    let {newPassword} = req.payload
    let {id: userId} = req.auth.credentials
    let db = req.getDb()
    let UserModel = db.getModel('UserWeb')
    let user = await UserModel.findOne({where: {id: userId}})

    let rawUser = user.dataValues
    console.log(rawUser)

    if (!rawUser.email_verified || !rawUser.phone_verified) throw new Error('Verify Your Mobile or Email')
    let {saltedPassword, salt} = userService.saltHashPassword(newPassword)
    await UserModel.update({password: saltedPassword, salt}, {where: {id: userId}})
    return 'success'
  } catch (error) {
    console.log(error)
    const errorMessage = `Otp Verification Failed`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: httpStatus.BAD_REQUEST, message: errorMessage })
  }
}
const getUserData = async (req) => {
  try {
    let {id: userId} = req.auth.credentials
    let db = req.getDb()
    let UserModel = db.getModel('UserWeb')
    let user = await UserModel.findOne({where: {id: userId}, raw: true})

    delete user.salt
    delete user.password
    return user
  } catch (error) {
    console.log(error)
    const errorMessage = `Can not get user details`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: httpStatus.BAD_REQUEST, message: errorMessage })
  }
}

const addReferral = async (req) => {
  try {
    let {referrerId} = req.payload
    let db = req.getDb()
    let UserWebModel = db.getModel('UserWeb')
    let WalletModel = db.getModel('UserPaymentInfo')
    let {id: userId} = req.auth.credentials
    await createReferral(referrerId, UserWebModel, userId, WalletModel)
    return 'success'
  } catch (error) {
    return boom.badRequest('Failed to Add Referral')
  }
}

module.exports = {
  login,
  register,
  sendOtp,
  verifyOtp,
  allUsers,
  forGotPassword,
  changePassword,
  getUserData,
  addReferral,
  checkAuth
}
