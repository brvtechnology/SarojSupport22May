
'use strict'
module.exports = function (sequelize, DataTypes) {
  return sequelize.define('UserWeb', {
    first_name: {
      type: DataTypes.STRING,
      field: 'first_name',
      allowNull: true
    },
    last_name: {
      type: DataTypes.STRING,
      field: 'last_name',
      allowNull: true
    },
    email: {
      type: DataTypes.STRING,
      field: 'email',
      allowNull: true
    },
    email_verified: {
      type: DataTypes.BOOLEAN,
      field: 'email_verified',
      allowNull: false,
      defaultValue: false
    },
    password: {
      type: DataTypes.STRING,
      field: 'password',
      allowNull: false
    },
    salt: {
      type: DataTypes.STRING,
      field: 'salt',
      allowNull: false
    },

    phone: {
      type: DataTypes.STRING,
      field: 'phone',
      allowNull: true
    },
    phone_verified: {
      type: DataTypes.BOOLEAN,
      field: 'phone_verified',
      allowNull: false,
      defaultValue: false
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: true
    }
  })
}
