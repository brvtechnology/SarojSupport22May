'use strict'

const Joi = require('joi')

const login = {
  payload: {
    email: Joi.string().required(),
    password: Joi.string().required()
  },
  options: {
    allowUnknown: false
  }
}

const register = {
  payload: {
    firstName: Joi.string().required(),
    lastName: Joi.string(),
    email: Joi.string().required(),
    password: Joi.string().required(),
    phone: Joi.number().required()

  },
  options: {
    allowUnknown: false
  }
}

const sendOtp = {
  payload: {
    type: Joi.string().required(),
    userId: Joi.number().required()

  },
  options: {
    allowUnknown: false
  }
}
const verifyOtp = {
  payload: {
    type: Joi.string().required(),
    otp: Joi.number().required(),
    userId: Joi.number().required()

  },
  options: {
    allowUnknown: false
  }
}
const forGotPassword = {
  payload: {
    type: Joi.string().required(),
    email: Joi.string(),
    phone: Joi.string()
  },
  options: {
    allowUnknown: false
  }
}
const changePassword = {
  payload: {
    newPassword: Joi.string().required()
  },
  options: {
    allowUnknown: false
  }
}

const addReferral = {
  payload: {
    referrerId: Joi.string().allow(null).allow('')
  },
  options: {
    allowUnknown: false
  }
}

module.exports = {
  login,
  register,
  sendOtp,
  verifyOtp,
  forGotPassword,
  changePassword,
  addReferral
}
