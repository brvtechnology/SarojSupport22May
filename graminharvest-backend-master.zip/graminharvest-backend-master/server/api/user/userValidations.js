'use strict'

const Joi = require('joi')

const user = {
  payload: {
    socialId: Joi.string().allow(null),
    first_name: Joi.string().allow(null),
    last_name: Joi.string().allow(null),
    name: Joi.string().allow(null),
    email: Joi.string().email().allow(null),
    gender: Joi.any().allow(null),
    picture: Joi.string().allow(null),
    provider: Joi.string().required(),
    phone: Joi.object({
      isVerified: Joi.boolean().allow(null),
      value: Joi.string().allow(null)
    }),
    source: Joi.string().required()
  },
  options: {
    allowUnknown: true
  }
}

module.exports = {
  user
}
