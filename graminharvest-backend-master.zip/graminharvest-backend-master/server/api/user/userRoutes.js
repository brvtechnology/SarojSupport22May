'use strict'

const config = require('config')

const userHandler = require('./userHandler')
const userValidations = require('./userValidations')
const userHandlerV1 = require('./userHandlerV1')
const userValidationsV1 = require('./userValidationsV1')

const API = '/' + config.get('app.name') + '/api/1.0/user/web'
const GRAMINAPI = '/v1/' + config.get('app.name') + '/ecommerce/user'
const routes = []

routes.push({
  path: API + '/login',
  method: 'POST',
  handler: userHandler.login,
  options: {
    tags: ['api'],
    validate: userValidations.user
  }
})

routes.push({
  path: API + '/all',
  method: 'GET',
  handler: async function (req) {
    try {
      let db = req.getDb()
      let User = db.getModel('UserWeb')
      let result = await User.all()
      return result.map(d => d.dataValues)
    } catch (error) {
      const errorMessage = `Failed to get Categories`
      console.log(errorMessage)
    }
  },
  options: {
    auth: 'jwt-app',
    tags: ['api']
  }
})

routes.push({
  path: API + '/allUsers',
  method: 'GET',
  handler: userHandler.allUsers,
  options: {
    tags: ['api'],
    auth: 'jwt-app'
  }
})

routes.push({
  path: GRAMINAPI + '/login',
  method: 'POST',
  handler: userHandlerV1.login,
  options: {
    tags: ['api'],
    auth: false,
    validate: userValidationsV1.login
  }
})
routes.push({
  path: GRAMINAPI + '/register',
  method: 'POST',
  handler: userHandlerV1.register,
  options: {
    tags: ['api'],
    auth: false,
    validate: userValidationsV1.register
  }
})
routes.push({
  path: GRAMINAPI + '/sendOtp',
  method: 'POST',
  handler: userHandlerV1.sendOtp,
  options: {
    tags: ['api'],
    auth: false,
    validate: userValidationsV1.sendOtp
  }
})
routes.push({
  path: GRAMINAPI + '/verifyOtp',
  method: 'POST',
  handler: userHandlerV1.verifyOtp,
  options: {
    tags: ['api'],
    auth: false,
    validate: userValidationsV1.verifyOtp
  }
})
routes.push({
  path: GRAMINAPI + '/forgot',
  method: 'POST',
  handler: userHandlerV1.forGotPassword,
  options: {
    tags: ['api'],
    auth: false,
    validate: userValidationsV1.forGotPassword
  }
})
routes.push({
  path: GRAMINAPI + '/changePassword',
  method: 'POST',
  handler: userHandlerV1.changePassword,
  options: {
    tags: ['api'],
    auth: 'jwt-app',
    validate: userValidationsV1.changePassword
  }
})
routes.push({
  path: GRAMINAPI + '/getUserData',
  method: 'POST',
  handler: userHandlerV1.getUserData,
  options: {
    tags: ['api'],
    auth: 'jwt-app'
  }
})

routes.push({
  path: GRAMINAPI + '/addReferral',
  method: 'POST',
  handler: userHandlerV1.addReferral,
  options: {
    auth: 'jwt-app',
    tags: ['api'],
    validate: userValidationsV1.addReferral
  }
})

routes.push({
  path: GRAMINAPI + '/auth',
  method: 'POST',
  handler: userHandlerV1.checkAuth,
  options: {
    auth: 'jwt-app',
    tags: ['api']
  }
})

module.exports = routes
