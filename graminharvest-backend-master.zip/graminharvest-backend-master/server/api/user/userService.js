const Hashids = require('hashids')
const uuid = require('uuid')
const addMoneyToWallet = require('../wallet/walletService')
/*
  @referrerId - the unique referral Id, if one user has referred by some other existing user
  @referCode - an existing user will use this when referring a new user
  @referredArr - list of users referred by a particular user
*/
const createReferral = async (referrerId, UserWebModel, authUserId, WalletModel) => {
  let referrer
  let invalidReferral = false
  let user = await UserWebModel.findById(authUserId)
  if (!user) {
    throw new Error('User does not exists')
  }
  if (referrerId) {
    referrer = await UserWebModel.findOne({where: {info: {refer: {referCode: referrerId}}}})
    if (!referrer) {
      invalidReferral = true
    } else if (authUserId === referrer.id) {
      throw new Error('Hey, you should not refer yourself..:P')
    }
  }
  let hashids = new Hashids(uuid.v4(), 8)
  let referCode = hashids.encode(authUserId)
  // add referral details
  let refer = {
    referrerId: referrer ? referrer.id : null,
    referCode,
    referredArr: []
  }
  if (refer.referrerId) {
    addMoneyToWallet(20, WalletModel, UserWebModel, refer.referrerId, 'addToPromo')
  }
  await user.updateAttributes({info: {refer}})

  if (referrer) {
    // update referred by user
    let refer = referrer.dataValues.info.refer
    refer.referredArr.push(authUserId)
    await referrer.updateAttributes({info: {refer}})
  }

  if (invalidReferral) {
    throw new Error('Invalid refer code')
  }
}

module.exports = {
  createReferral
}
