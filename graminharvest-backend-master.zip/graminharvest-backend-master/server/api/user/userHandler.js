
'use strict'

const boom = require('boom')
const httpStatus = require('http-status')
const logger = require('../../utils/logger')
const JWT = require('jsonwebtoken')
const config = require('config')

const login = async (req) => {
  try {
    let db = req.getDb()
    let User = db.getModel('UserWeb')
    let Cart = db.getModel('Cart')
    let query = req.payload.email ? {email: req.payload.email} : {socialId: req.payload.socialId}
    let user = await User.findOne({where: query})

    if (user) {
      req.payload.lastLogin = req.payload.source
      delete req.payload.source
      user = await user.updateAttributes(req.payload)
    } else {
      req.payload.firstLogin = req.payload.source
      delete req.payload.source
      user = await User.create(req.payload)
      user.dataValues.isNewUser = true
      await Cart.create({ userId: user.id, cartItems: [] })
    }

    if (!user) {
      throw new Error('Error occured while login')
    }

    let token = {
      valid: true,
      id: user.dataValues.id,
      type: 'app',
      exp: new Date().getTime() + 30 * 60 * 1000
    }

    return {
      user: user.dataValues,
      token: JWT.sign(token, config.get('authSecrets.app'))
    }
  } catch (error) {
    const errorMessage = `Failed to login`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: httpStatus.INTERNAL_SERVER_ERROR, message: errorMessage })
  }
}

const allUsers = async (req) => {
  try {
    let db = req.getDb()
    let UserModel = db.getModel('UserWeb')
    return UserModel.findAll()
  } catch (error) {
    const errorMessage = `Failed to Get Users`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

module.exports = {
  login,
  allUsers
}
