'use strict'

const joi = require('joi')

const addCoupon = {
  payload: {
    coupon_code: joi.string().required(),
    description: joi.string().required(),
    expiry_date: joi.string().allow(null).default(null),
    allowedPerUser: joi.number().required(),
    type: joi.string().allow(['percentage', 'amount']),
    minimum_amount_to_apply: joi.number().allow(null).default(0),
    coupon_amount: joi.number().required().description('can be either percentage or amount'),
    max_cashback: joi.number().required(),
    info: joi.object().allow(null).default(null)
  },
  options: {
    allowUnknown: true
  }
}
const expireCoupon = {
  payload: {
    coupon_code: joi.string().required()
  },
  options: {
    allowUnknown: true
  }
}

module.exports = {
  addCoupon,
  expireCoupon
}
