'use strict'

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('coupon_orders', {
    coupon_code: {
      type: DataTypes.TEXT,
      field: 'coupon_code',
      allowNull: false
    },
    user_id: {
      type: DataTypes.INTEGER,
      field: 'user_id',
      allowNull: false
    },
    order_id: {
      type: DataTypes.TEXT,
      field: 'order_id',
      allowNull: false
    },
    cashback_received: {
      type: DataTypes.INTEGER,
      field: 'cashback_received',
      allowNull: false
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: true
    }
  })
}
