'use strict'

const config = require('config')

const couponHandler = require('./couponHandler')
const couponValidations = require('./couponValidations')

const API = '/' + config.get('app.name') + '/api/1.0/coupon'

const routes = []

routes.push({
  path: API + '/addCoupon',
  method: 'POST',
  handler: couponHandler.addCoupon,
  options: {
    auth: false,
    tags: ['api'],
    validate: couponValidations.addCoupon
  }
})
routes.push({
  path: API + '/getCoupons',
  method: 'GET',
  handler: couponHandler.getCoupons,
  options: {
    auth: false,
    tags: ['api']
  }
})
routes.push({
  path: API + '/getCouponsWeb',
  method: 'GET',
  handler: couponHandler.getCouponsWeb,
  options: {
    auth: 'jwt-app',
    tags: ['api']
  }
})
routes.push({
  path: API + '/expireCoupon',
  method: 'POST',
  handler: couponHandler.expireCoupon,
  options: {
    auth: false,
    tags: ['api'],
    validate: couponValidations.expireCoupon
  }
})

module.exports = routes
