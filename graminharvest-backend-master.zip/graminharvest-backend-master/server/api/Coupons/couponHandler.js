'use strict'

const boom = require('boom')
const logger = require('../../utils/logger')
const moment = require('moment')
const Sequelize = require('sequelize')
const Op = Sequelize.Op
const _ = require('lodash')
const addCoupon = async (req) => {
  try {
    const db = req.getDb()
    const CouponModel = db.getModel('Coupons')
    let {
      coupon_code: couponCode,
      description,
      expiry_date: expiryCode,
      allowedPerUser,
      type,
      minimum_amount_to_apply: minAmtToApply,
      coupon_amount: couponmAmt,
      max_cashback: maxCashBack,
      info
    } = req.payload
    let isCouponExist = await CouponModel.findOne({where: {coupon_code: couponCode}, raw: true})
    if (isCouponExist) throw new Error('this coupon code is not unique')
    else {
      let c = await CouponModel.create({
        coupon_code: couponCode,
        description,
        expiry_date: expiryCode,
        allowedPerUser,
        type,
        minimum_amount_to_apply: minAmtToApply,
        coupon_amount: couponmAmt,
        max_cashback: maxCashBack,
        info
      })
      return c
    }
  } catch (error) {
    console.log(error)
    const errorMessage = `Failed to Place order`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}
const getCoupons = async (req) => {
  try {
    let db = req.getDb()
    const CouponModel = db.getModel('Coupons')
    return await CouponModel.findAll()
  } catch (error) {
    console.log(error)
    const errorMessage = `Failed to GET order`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}
const expireCoupon = async (req) => {
  try {
    let db = req.getDb()
    const CouponModel = db.getModel('Coupons')
    let {coupon_code: couponCode} = req.payload
    await CouponModel.update({expiry_date: moment().utc().format()}, {where: {coupon_code: couponCode}})
    return 'success'
  } catch (error) {
    console.log(error)
    const errorMessage = `Failed to GET order`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}
const getCouponsWeb = async (req) => {
  try {
    let db = req.getDb()
    const CouponModel = db.getModel('Coupons')
    const CouponOrderModel = db.getModel('coupon_orders')
    let {id: userId} = req.auth.credentials
    let [coupons, couponOrders] = await Promise.all([CouponModel.findAll({
      where: {
        expiry_date: {
          [Op.gte]: moment().utc().format()
        }
      },
      raw: true
    }),
    CouponOrderModel.findAll({where: {user_id: userId}, raw: true})])

    if (!(coupons && coupons.length)) return []
    if (!(couponOrders && couponOrders.length)) return coupons
    let couponOrdersGrouped = _.groupBy(couponOrders, 'coupon_code')

    let filteredCoupons = []

    coupons.forEach(c => {
      Object.keys(couponOrdersGrouped).forEach(co => {
        if (c.coupon_code === co) {
          console.log(c)
          console.log(couponOrdersGrouped[co].length)
          if (c.allowedPerUser > couponOrdersGrouped[co].length) filteredCoupons.push(c)
        }
      })
    })
    coupons.forEach(c => {
      if (Object.keys(couponOrdersGrouped).indexOf(c.coupon_code) < 0) filteredCoupons.push(c)
    })
    return filteredCoupons
  } catch (error) {
    console.log(error)
    const errorMessage = `Failed to GET order`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}
module.exports = {
  addCoupon,
  getCoupons,
  expireCoupon,
  getCouponsWeb
}
