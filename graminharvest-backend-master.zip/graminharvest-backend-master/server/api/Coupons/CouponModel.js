'use strict'

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('Coupons', {
    coupon_code: {
      type: DataTypes.TEXT,
      field: 'coupon_code',
      allowNull: false
    },
    description: {
      type: DataTypes.TEXT,
      field: 'description',
      allowNull: false
    },
    expiry_date: {
      type: DataTypes.TEXT,
      field: 'expiry_date',
      allowNull: false
    },
    allowedPerUser: {
      type: DataTypes.INTEGER,
      field: 'allowed_per_user',
      allowNull: false
    },
    type: {
      type: DataTypes.TEXT,
      field: 'type',
      allowNull: false
    },
    minimum_amount_to_apply: {
      type: DataTypes.INTEGER,
      field: 'minimum_amount_to_apply',
      allowNull: false
    },
    coupon_amount: {
      type: DataTypes.INTEGER,
      field: 'coupon_amount',
      allowNull: false
    },
    max_cashback: {
      type: DataTypes.INTEGER,
      field: 'max_cashback',
      allowNull: false
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: true
    }
  })
}
