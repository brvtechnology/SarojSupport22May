'use strict'

const joi = require('joi')

const addEvent = {
  payload: {
    eventName: joi.string().required(),
    eventAddress: joi.string().required(),
    eventDescription: joi.string().required(),
    eventDate: joi.string().required(),
    eventTime: joi.string().required(),
    fee: joi.number().integer().required(),
    eventDuration: joi.number().required(),
    paymentLink: joi.string().required(),
    info: joi.object().required()
  },
  options: {
    allowUnknown: true
  }
}

const editEvent = {
  payload: {
    eventId: joi.number().integer().required(),
    eventName: joi.string().required(),
    eventAddress: joi.string().required(),
    eventDescription: joi.string().required(),
    eventDate: joi.string().required(),
    eventTime: joi.string().required(),
    fee: joi.number().integer().required(),
    eventDuration: joi.number().required(),
    paymentLink: joi.string().required(),
    info: joi.object().required()
  },
  options: {
    allowUnknown: true
  }
}

const getEvents = {
  query: {
    eventId: joi.number().integer().required()
  },
  options: {
    allowUnknown: true
  }
}
const getEventsWeb = {
  query: {
    eventId: joi.number().integer().required()
  },
  options: {
    allowUnknown: true
  }
}

module.exports = {
  addEvent,
  editEvent,
  getEvents,
  getEventsWeb
}
