'use strict'

const config = require('config')

const eventHandler = require('./eventHandler')
const eventValidations = require('./eventValidations')

const API = '/' + config.get('app.name') + '/api/1.0/event'

const routes = []

routes.push({
  path: API + '/addEvent',
  method: 'POST',
  handler: eventHandler.addEvent,
  options: {
    auth: false,
    tags: ['api'],
    validate: eventValidations.addEvent
  }
})

routes.push({
  path: API + '/editEvent',
  method: 'POST',
  handler: eventHandler.editEvent,
  options: {
    auth: false,
    tags: ['api'],
    validate: eventValidations.editEvent
  }
})

routes.push({
  path: API + '/getEvents',
  method: 'GET',
  handler: eventHandler.getEvents,
  options: {
    auth: false,
    tags: ['api'],
    validate: eventValidations.getEvents
  }
})

routes.push({
  path: API + '/getEventsWeb',
  method: 'GET',
  handler: eventHandler.getEventsWeb,
  options: {
    auth: false,
    tags: ['api'],
    validate: eventValidations.getEventsWeb
  }
})

module.exports = routes
