'use strict'

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('Events', {
    eventName: {
      type: DataTypes.STRING,
      field: 'event_name',
      allowNull: false
    },
    eventDescription: {
      type: DataTypes.TEXT,
      field: 'event_description',
      allowNull: false
    },
    eventAddress: {
      type: DataTypes.TEXT,
      field: 'event_address',
      allowNull: false
    },
    eventDate: {
      type: DataTypes.STRING,
      field: 'event_date',
      allowNull: false
    },
    eventTime: {
      type: DataTypes.STRING,
      field: 'event_time',
      allowNull: false
    },
    eventDuration: {
      type: DataTypes.FLOAT,
      field: 'event_duration',
      allowNull: false
    },
    fee: {
      type: DataTypes.INTEGER,
      field: 'event_fee',
      allowNull: false
    },
    paymentLink: {
      type: DataTypes.TEXT,
      field: 'payment_link',
      allowNull: false
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: false
    }
  })
}
