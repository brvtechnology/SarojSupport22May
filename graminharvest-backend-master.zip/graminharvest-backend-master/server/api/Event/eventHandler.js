'use strict'

const boom = require('boom')

const logger = require('../../utils/logger')

const moment = require('moment')

const addEvent = async function (req) {
  try {
    let db = req.getDb()
    let Events = db.getModel('Events')
    let result = await Events.create(req.payload)
    return result
  } catch (error) {
    const errorMessage = `Failed to add Event`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const editEvent = async function (req) {
  try {
    let db = req.getDb()
    let {eventId: id} = req.payload
    let Events = db.getModel('Events')
    let desiredEvent = await Events.findById(id)
    if (desiredEvent) {
      return desiredEvent.updateAttributes(req.payload)
    } else return boom.badRequest('Editing Event Failed')
  } catch (error) {
    const errorMessage = `Failed to edit Event`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getEvents = async (req) => {
  try {
    let db = req.getDb()
    let Events = db.getModel('Events')
    let {eventId} = req.query
    console.log(eventId)
    if (eventId === 0) {
      // If productId is 0 backend assumes that client wants all product
      return await Events.findAll()
    } else {
      return await Events.findById(eventId)
    }
  } catch (error) {
    console.log(error)
    const errorMessage = `Failed to get Events`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getEventsWeb = async (req) => {
  try {
    let db = req.getDb()
    let Events = db.getModel('Events')
    let {eventId} = req.query
    if (eventId === 0) {
      // If eventId is 0 backend assumes that client wants all product
      let allEvents = await Events.findAll({raw: true})
      let allEventArr = allEvents.filter(event => {
        let date = moment(event.eventDate + ' ' + event.eventTime, 'YYYY-MM-DD HH:mm')
        return (date > moment() && event.info.show === 'Yes')
      })
      return allEventArr
    } else {
      let singleEvent = await Events.findById(eventId)
      let date = moment(singleEvent.eventDate + ' ' + singleEvent.eventTime, 'YYYY-MM-DD HH:mm')
      if (date > moment() && singleEvent.info.show === 'Yes') return singleEvent
      else return {}
    }
  } catch (error) {
    console.log(error)
    const errorMessage = `Failed to get Events`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

module.exports = {
  addEvent,
  editEvent,
  getEvents,
  getEventsWeb
}
