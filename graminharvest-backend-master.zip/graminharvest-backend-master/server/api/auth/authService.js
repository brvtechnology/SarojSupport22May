'use strict'

const isValidUser = async function (id) {
  // TODO need to check user id is valid or not in DB
  return id === '12345'
}

module.exports = {
  isValidUser
}
