'use strict'

const joi = require('joi')

const authRequestValidation = {
  authRequestValidation: {
    payload: {
      id: joi.string().required(),
      secret: joi.string().valid('supersu'),
      type: joi.string().required()
    }
  }
}

module.exports = authRequestValidation
