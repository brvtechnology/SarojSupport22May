'use strict'

const boom = require('boom')
const httpStatus = require('http-status')

const authController = require('./authController')
const logger = require('../../utils/logger')

const generateAuthToken = async function (req) {
  const authRequest = req.payload

  try {
    return await authController.generateAuthToken(authRequest)
  } catch (error) {
    const errorMessage = `Failed to get auth token for id: ${authRequest.id}`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: httpStatus.INTERNAL_SERVER_ERROR, message: errorMessage })
  }
}

module.exports = {
  generateAuthToken
}
