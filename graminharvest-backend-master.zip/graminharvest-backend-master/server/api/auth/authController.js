'use strict'

const JWT = require('jsonwebtoken')
const config = require('config')
// const boom = require('boom')
// const httpStatus = require('http-status')

const AUTH_TYPE_APP = 'app'
// const authService = require('./authService')
const logger = require('../../utils/logger')

const generateAuthToken = async function (authRequest) {
  if (AUTH_TYPE_APP === authRequest.type) {
    // let isValidUser = await authService.isValidUser(authRequest.id)
    logger.error(authRequest.id)
    // if (isValidUser) {
    var token = {
      valid: true,
      id: authRequest.id,
      type: authRequest.type,
      exp: new Date().getTime() + 30 * 60 * 1000
    }
    return JWT.sign(token, config.get('authSecrets.app'))
    // } else {
    // const errorMessage = `clinic id: ${authRequest.id} is not valid`
    // logger.error(errorMessage)
    // return boom.boomify({ statusCode: httpStatus.BAD_REQUEST, message: errorMessage })
  }
}

module.exports = {
  generateAuthToken
}
