'use strict'

const config = require('config')

const authHandler = require('./authHandler')
const authValidations = require('./authValidations')

const API = '/' + config.get('app.name') + '/api/1.0'

const routes = []

//  POST generateAuthToken
routes.push({
  path: API + '/auth',
  method: 'POST',
  handler: authHandler.generateAuthToken,
  options: {
    tags: ['api'],
    validate: authValidations.authRequestValidation
  }
})

module.exports = routes
