var crypto = require('crypto')

/*
 Generates random string of characters i.e salt
 Dont use same salt for all passwords,
 Need unique random salt for every password, so as to defeat precomputed rainbow attacks
 */
var genRandomString = function (length) {
  return crypto.randomBytes(Math.ceil(length / 2))
    .toString('hex') /** convert to hexadecimal format */
    .slice(0, length) /** return required number of characters */
}

/*
 Hash password along with salt with sha512
 */
var sha512 = function (password, salt) {
  var hash = crypto.createHmac('sha512', salt) /* Hashing algorithm sha512 */
  hash.update(password)
  var value = hash.digest('hex')
  return {
    salt: salt,
    passwordHash: value
  }
}

function saltHashPassword (userpassword) {
  var salt = genRandomString(16) /* Gives us salt of length 16 */
  var passwordData = sha512(userpassword, salt)
  console.log('UserPassword = ' + userpassword)
  console.log('Passwordhash = ' + passwordData.passwordHash)
  console.log('nSalt = ' + passwordData.salt)
  return {saltedPassword: passwordData.passwordHash, salt: passwordData.salt}
}

function validatePassword (saltedPassword, salt, plaintextPassword) {
  if (sha512(plaintextPassword, salt).passwordHash === saltedPassword) {
    return true
  } else {
    return false
  }
}
module.exports = {
  saltHashPassword,
  validatePassword
}
