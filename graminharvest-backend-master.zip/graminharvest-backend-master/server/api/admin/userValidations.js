'use strict'

const Joi = require('joi')

const login = {
  payload: {
    email: Joi.string().required(),
    password: Joi.string().required()
  }
}

const register = {
  payload: {
    email: Joi.string().required(),
    password: Joi.string().required()
  }
}

module.exports = {
  login,
  register
}
