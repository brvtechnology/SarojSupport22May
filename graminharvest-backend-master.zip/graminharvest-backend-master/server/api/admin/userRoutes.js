'use strict'

const config = require('config')

const userHandler = require('./userHandler')
const userValidations = require('./userValidations')

const API = '/' + config.get('app.name') + '/api/1.0/user'

const routes = []

routes.push({
  path: API + '/login',
  method: 'POST',
  handler: userHandler.login,
  options: {
    tags: ['api'],
    validate: userValidations.login
  }
})

routes.push({
  path: API + '/register',
  method: 'POST',
  handler: userHandler.register,
  options: {
    tags: ['api'],
    validate: userValidations.register
  }
})

module.exports = routes
