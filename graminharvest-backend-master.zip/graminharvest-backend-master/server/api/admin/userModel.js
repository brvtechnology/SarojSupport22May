
'use strict'
module.exports = function (sequelize, DataTypes) {
  return sequelize.define('User', {
    email: {
      type: DataTypes.STRING,
      field: 'email',
      allowNull: false
    },
    password: {
      type: DataTypes.STRING,
      field: 'password',
      allowNull: false
    },
    salt: {
      type: DataTypes.STRING,
      field: 'salt',
      allowNull: false
    }
  })
}
