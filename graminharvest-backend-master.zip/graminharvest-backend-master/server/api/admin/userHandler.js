'use strict'
const boom = require('boom')
const logger = require('../../utils/logger')
const userService = require('./userService')
const JWT = require('jsonwebtoken')
const config = require('config')

const login = async (req) => {
  try {
    let db = req.getDb()
    let User = db.getModel('User')

    let {email, password} = req.payload
    let user = await User.findOne({where: {email}})

    if (!user) {
      throw boom.unauthorized('Email not found!')
    }

    // validate user password against stored salted password and salt
    let saltedPassword = user.dataValues.password
    let salt = user.dataValues.salt
    if (await !userService.validatePassword(saltedPassword, salt, password)) {
      // return res.response('User password invalid!').code(403)
      throw boom.unauthorized('User password does not match!')
    }

    let token = {
      valid: true,
      id: user.dataValues.id,
      type: 'app',
      exp: new Date().getTime() + 30 * 60 * 1000
    }

    let auth = {
      user: user.dataValues.email,
      token: JWT.sign(token, config.get('authSecrets.app'))
    }
    return auth
  } catch (error) {
    const errorMessage = `Failed to login!`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const register = async (req) => {
  try {
    let db = req.getDb()
    let User = db.getModel('User')

    let {email, password} = req.payload
    let user = await User.findOne({where: {email}})

    if (user) {
      throw boom.conflict('Email address already registered!')
    }

    let {saltedPassword, salt} = userService.saltHashPassword(password)

    user = await User.create({email: email, password: saltedPassword, salt: salt})

    return 'User created: ' + email
  } catch (error) {
    const errorMessage = `User registration failed`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

module.exports = {
  login,
  register
}
