'use strict'

const config = require('config')

const awsHandler = require('./awsHandler')
const awsValidations = require('./awsValidations')

const API = '/' + config.get('app.name') + '/api/1.0/aws'

const routes = []

routes.push({
  path: API + '/s3/uploadFile',
  method: 'POST',
  handler: awsHandler.s3uploadFile,
  options: {
    // auth: 'jwt-app',
    tags: ['api'],
    validate: awsValidations.s3uploadFile
  }
})

routes.push({
  path: API + '/testEmailService',
  method: 'POST',
  handler: awsHandler.testEmailService,
  options: {
    auth: 'jwt-app',
    tags: ['api'],
    validate: awsValidations.testEmailService
  }
})
routes.push({
  path: API + '/getUploadedImageLinks',
  method: 'GET',
  handler: awsHandler.getUploadedImageLinks,
  options: {
    // auth: 'jwt-app',
    tags: ['api']
  }
})
routes.push({
  path: API + '/deletePhoto',
  method: 'POST',
  handler: awsHandler.deletePhoto,
  options: {
    auth: false,
    tags: ['api'],
    validate: awsValidations.deletePhoto
  }
})
module.exports = routes
