'use strict'

const boom = require('boom')
const httpStatus = require('http-status')
const logger = require('../../utils/logger')
const AWS = require('aws-sdk')
const config = require('config')
const awsService = require('./awsService')
const uuid = require('uuid')

let accesskey = config.get('aws.s3.accessKeyId')
let secretkey = config.get('aws.s3.secretAccessKey')
let region = config.get('aws.s3.region')

AWS.config.update({accessKeyId: accesskey, secretAccessKey: secretkey, region: region})

const s3uploadFile = async function (req, res) {
  try {
    let bucketName = config.get('aws.s3.bucketName')
    let fileURL
    let urlList = []
    let db = req.getDb()
    let imageLinks = db.getModel('imageLinks')

    let photos = req.payload.photos
    if (photos.constructor !== Array) {
      photos = []
      photos.push(req.payload.photos)
    }

    for (let eachPhoto of photos) {
      let uploadName = uuid.v4()
      // Create a promise on S3 service object
      let s3obj = new AWS.S3({apiVersion: '2006-03-01'})
      await awsService.s3uploadservice(eachPhoto, uploadName, bucketName, s3obj)

      fileURL = 'https://s3.' + region + '.amazonaws.com/' + bucketName + '/' + uploadName
      urlList.push(fileURL)
    }
    console.log(urlList)
    await imageLinks.create({imageLinks: fileURL})
    return 'Success'
  } catch (error) {
    const errorMessage = `Failed to upload file to s3`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: httpStatus.INTERNAL_SERVER_ERROR, message: errorMessage })
  }
}

const sendSMS = async (data) => {
  let {accessKeyId: accesskey, secretAccessKey: secretkey, region} = config.get('aws.sns')
  console.log(accesskey, secretkey, region)
  AWS.config.update({accessKeyId: accesskey, secretAccessKey: secretkey, region: region})
  let sns = new AWS.SNS()
  sns.setSMSAttributes(
    {
      attributes: {
        DefaultSMSType: 'Transactional'
      }
    },
    function (error) {
      if (error) {
        console.log(error)
      }
    }
  )
  const regex = /(\+?91)/g
  const subst = ``
  data.phone = data.phone.replace(regex, subst)

  let params = {
    Message: data.message,
    MessageStructure: 'string',
    PhoneNumber: `91${data.phone}`,
    Subject: data.subject
  }
  console.log(params)
  let response = await sns.publish(params).promise()
  return response
}

// test handler to send mail using nodemailer

const testEmailService = async (req) => {
  try {
    let {FromMail, name, subject, msg} = req.payload
    msg = `${name} is sending ths msg`
    return await awsService.emailSendingService(FromMail, subject, msg)
  } catch (error) {
    console.log(error)
    return error
  }
}
const getUploadedImageLinks = async (req) => {
  try {
    let db = req.getDb()
    let imageLinks = db.getModel('imageLinks')
    return await imageLinks.findAll()
  } catch (error) {
    console.log(error)
    return error
  }
}
const deletePhoto = async (req) => {
  try {
    let db = req.getDb()
    let { id } = req.payload
    let imageLinksModel = db.getModel('imageLinks')
    return imageLinksModel.destroy({where: {id}})
  } catch (error) {
    console.log(error)
    return error
  }
}
module.exports = {

  s3uploadFile,
  sendSMS,
  testEmailService,
  getUploadedImageLinks,
  deletePhoto
}
