'use strict'

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('imageLinks', {
    imageLinks: {
      type: DataTypes.STRING,
      field: 'image_links',
      allowNull: false
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: true
    }
  })
}
