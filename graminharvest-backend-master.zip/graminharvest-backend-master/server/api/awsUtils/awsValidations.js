'use strict'
const joi = require('joi')
const s3uploadFile = {
  payload: {
    output: 'stream',
    allow: 'multipart/form-data'
  },
  options: {
    allowUnknown: true
  }
}

const testEmailService = {

  payload: {
    name: joi.string().required(),
    FromMail: joi.string().required(),
    subject: joi.string().required(),
    msg: joi.string().required()
  }
}
const deletePhoto = {

  payload: {
    id: joi.number().integer().required()
  }
}

module.exports = {
  s3uploadFile,
  testEmailService,
  deletePhoto
}
