'use strict'

// const logger = require('../../utils/logger')
// const httpStatus = require('http-status')
// const fs = require('fs')
// const mime = require('mime-types')
const config = require('config')
const nodemailer = require('nodemailer')
let transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: config.get('senderEmail.emailId'),
    pass: config.get('senderEmail.password')
  }
})

const s3uploadservice = async (file, uploadName, bucket, s3obj) => {
  try {
    let params = {
      'Bucket': bucket,
      'Key': uploadName,
      'Body': file,
      'ACL': 'public-read',
      ContentType: 'image'
    }

    let putObjectPromise = s3obj.putObject(params).promise()

    putObjectPromise.then(function (data) {
      console.log('Success')
      return 'Success'
    }).catch(function (err) {
      console.log(err)
      return 'Error!!!!!!!'
    })
  } catch (error) {
    console.log(error)
    throw new Error()
  }
}
const emailSendingService = async (name, subject, msg, html) => {
  try {
    var message = {
      from: 'skyborntech@gmail.com',
      to: name,
      subject,
      text: msg
    }

    if (html) message.html = html
    console.log(name, subject, msg)

    await transporter.sendMail(message)
    return ('success')
  } catch (err) {
    console.log(err)
    throw new Error('Something Went Wrong')
  }
}

module.exports = {
  s3uploadservice,
  emailSendingService
}
