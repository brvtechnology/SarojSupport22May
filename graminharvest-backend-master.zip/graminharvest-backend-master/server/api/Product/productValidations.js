'use strict'

const joi = require('joi')

const addProduct = {
  payload: {
    name: joi.string().required(),
    description: joi.string().required(),
    image: joi.string().required(),
    stock: joi.number().integer().required(),
    price: joi.number().integer().required(),
    discount: joi.number().integer().required(),
    discountType: joi.string().required(),
    productType: joi.number().integer().required(),
    paymentLink: joi.string().required(),
    info: joi.object().allow(null)
  },
  options: {
    allowUnknown: true
  }
}

const editProduct = {
  payload: {
    productId: joi.number().integer().required(),
    name: joi.string().required(),
    description: joi.string().required(),
    image: joi.string().required(),
    stock: joi.number().integer().required(),
    price: joi.number().integer().required(),
    discount: joi.number().integer().required(),
    discountType: joi.string().required(),
    productType: joi.number().integer().required(),
    paymentLink: joi.string().required(),
    info: joi.object().allow(null)
  },
  options: {
    allowUnknown: true
  }
}

const getProducts = {
  query: {
    productId: joi.number().integer().required()
  },
  options: {
    allowUnknown: true
  }
}
const getAllProductsForWeb = {
  query: {
    name: joi.string().allow(null)
  },
  options: {
    allowUnknown: true
  }
}
module.exports = {
  addProduct,
  editProduct,
  getProducts,
  getAllProductsForWeb
}
