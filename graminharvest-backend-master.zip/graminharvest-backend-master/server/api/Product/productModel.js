'use strict'

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('Product', {
    name: {
      type: DataTypes.TEXT,
      field: 'product_name',
      allowNull: false
    },
    description: {
      type: DataTypes.TEXT,
      field: 'product_description',
      allowNull: false
    },
    image: {
      type: DataTypes.TEXT,
      field: 'product_image',
      allowNull: false
    },
    stock: {
      type: DataTypes.INTEGER,
      field: 'product_stock',
      allowNull: false
    },
    price: {
      type: DataTypes.INTEGER,
      field: 'product_price',
      allowNull: false
    },
    discount: {
      type: DataTypes.INTEGER,
      field: 'discount',
      allowNull: false
    },
    discountType: {
      type: DataTypes.STRING,
      field: 'discount_type',
      allowNull: false
    },
    paymentLink: {
      type: DataTypes.TEXT,
      field: 'payment_link',
      allowNull: false
    },
    productType: {
      type: DataTypes.TEXT,
      field: 'product_type',
      allowNull: false
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: true
    }
  })
}
