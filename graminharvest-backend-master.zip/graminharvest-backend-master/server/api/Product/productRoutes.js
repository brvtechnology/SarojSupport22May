'use strict'

const config = require('config')

const productHandler = require('./productHandler')
const productValidations = require('./productValidations')

const API = '/' + config.get('app.name') + '/api/1.0/product'

const routes = []

routes.push({
  path: API + '/addproduct',
  method: 'POST',
  handler: productHandler.addProduct,
  options: {
    auth: false,
    tags: ['api'],
    validate: productValidations.addProduct
  }
})

routes.push({
  path: API + '/editProduct',
  method: 'POST',
  handler: productHandler.editProduct,
  options: {
    auth: false,
    tags: ['api'],
    validate: productValidations.editProduct
  }
})
routes.push({
  path: API + '/getAllProducts',
  method: 'GET',
  handler: productHandler.getAllProducts,
  options: {
    auth: false,
    tags: ['api'],
    validate: productValidations.getProducts
  }
})
routes.push({
  path: API + '/getAllProductsForWeb',
  method: 'GET',
  handler: productHandler.getAllProductsForWeb,
  options: {
    auth: false,
    tags: ['api'],
    validate: productValidations.getAllProductsForWeb
  }
})
// routes.push({
//   path: API + '/topProductWeb',
//   method: 'GET',
//   handler: productHandler.topProductWeb,
//   options: {
//     auth: false,
//     tags: ['api']
//   }
// })
module.exports = routes
