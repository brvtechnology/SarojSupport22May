'use strict'

const boom = require('boom')
const Hashids = require('hashids')
const logger = require('../../utils/logger')
const HASH_KEY = 'GRAMIN_HARVEST_HASH_KEY'

const addProduct = async (req) => {
  try {
    let db = req.getDb()
    let product = db.getModel('Product')
    // add friendly url
    let {payload} = req
    if (!payload.info) {
      payload.info = {}
    }
    payload.info.friendlyURL = getFriendlyURL(payload.name, Math.floor(Math.random() * 1000))
    return product.create(payload)
  } catch (error) {
    const errorMessage = `Failed to add Product Item`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const editProduct = async (req) => {
  try {
    let db = req.getDb()
    let {productId: id} = req.payload
    let product = db.getModel('Product')
    let desiredProduct = await product.findById(id)
    if (desiredProduct) {
      return desiredProduct.updateAttributes(req.payload)
    } else return boom.badRequest('Editing product details Failed')
  } catch (error) {
    const errorMessage = `Failed to edit productType`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getAllProducts = async (req) => {
  try {
    let db = req.getDb()
    let product = db.getModel('Product')
    let {productId} = req.query
    if (productId === 0) {
      // If productId is 0 backend assumes that client wants all product
      return await product.findAll()
    } else {
      return await product.findById(productId)
    }
  } catch (error) {
    const errorMessage = `Failed to get productTypes`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getAllProductsForWeb = async (req) => {
  try {
    let db = req.getDb()
    let product = db.getModel('Product')
    let ProductType = db.getModel('ProductType')
    let {name} = req.query
    if (!name) {
      // If productId is 0 backend assumes that client wants all product

      let allProducts = await product.findAll({raw: true})
      let allProductTypes = await ProductType.findAll({raw: true})
      // console.log(allProducts)
      // console.log('*********************')
      // console.log(allProductTypes)
      if (allProducts) {
        // allProducts = allProducts.map(p => p.dataValues)
        allProducts.forEach(ap => {
          // console.log('**************************************')
          // console.log(ap)
          let productType = allProductTypes.find(apt => +ap.productType === +apt.id)
          // console.log(productType)
          if (productType.info.show === 'No') ap.info.show = 'No'
          if (ap.discountType === 'Percentage') {
            ap.realPrice = ap.price
            ap.price = ap.price - (ap.price * (ap.discount * 0.01))
          } else if (ap.discountType === 'RS') {
            ap.realPrice = ap.price
            ap.price -= ap.discount
          } else throw new Error('discount type mismatch')
        })
      }
      allProducts.forEach(ap => {
        ap.productType = +ap.productType
      })
      // console.log(allProducts)
      return allProducts.filter(ap => ap.info.show === 'Yes')
    } else {
      let singleProduct = await product.findOne({where: {info: {friendlyURL: name, show: true}}})
      if (singleProduct) {
        singleProduct = singleProduct.dataValues
      } else return {}
      let productType = await ProductType.findById(singleProduct.productType)
      if (productType.info.show === 'No') singleProduct.info.show = 'No'
      singleProduct.realPrice = singleProduct.price
      if (singleProduct.info.show === 'No') return {}

      if (singleProduct.discountType === 'Percentage') {
        singleProduct.price = singleProduct.price - (singleProduct.price * (singleProduct.discount * 0.01))
      } else if (singleProduct.discountType === 'RS') {
        singleProduct.price -= singleProduct.discount
      } else throw new Error('discount type mismatch')
      return singleProduct
    }
  } catch (error) {
    const errorMessage = `Failed to get products`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getFriendlyURL = (name, id) => {
  var hashids = new Hashids(HASH_KEY, 8)
  return `${slugify(name)}-${hashids.encode(id)}`
}

const slugify = (name) => {
  const a = 'àáäâãåăæąçćčđďèéěėëêęğǵḧìíïîįłḿǹńňñòóöôœøṕŕřßşśšșťțùúüûǘůűūųẃẍÿýźžż·/_,:;'
  const b = 'aaaaaaaaacccddeeeeeeegghiiiiilmnnnnooooooprrsssssttuuuuuuuuuwxyyzzz------'
  const p = new RegExp(a.split('').join('|'), 'g')

  return name.toString().toLowerCase()
    .replace(/\s+/g, '-') // Replace spaces with -
    .replace(p, c => b.charAt(a.indexOf(c))) // Replace special characters
    .replace(/&/g, '-and-') // Replace & with 'and'
    .replace(/[^\w\-]+/g, '') // Remove all non-word characters
    .replace(/\-\-+/g, '-') // Replace multiple - with single -
    .replace(/^-+/, '') // Trim - from start of text
    .replace(/-+$/, '') // Trim - from end of text
}

// const topProductWeb = async (req) => {
//   try {
//     let db = req.getDb()
//     const ProductModel = db.getModel('Product')
//     let query1 = `SELECT count(*),   from Products where`
//   } catch (error) {
//     const errorMessage = `Failed to edit productType`
//     !error.logged && logger.error(error, errorMessage)
//     return boom.boomify(error, { statusCode: 400 })
//   }
// }

module.exports = {
  addProduct,
  editProduct,
  getAllProducts,
  getAllProductsForWeb
  // topProductWeb
}
