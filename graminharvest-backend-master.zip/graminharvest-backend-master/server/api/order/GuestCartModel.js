'use strict'

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('guest_cart', {
    uuid: {
      type: DataTypes.TEXT,
      field: 'uuid',
      allowNull: false
    },
    cartItems: {
      type: DataTypes.JSONB,
      field: 'cart_items',
      allowNull: false
    }
  })
}
