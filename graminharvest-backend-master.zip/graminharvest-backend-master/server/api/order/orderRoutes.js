'use strict'

const config = require('config')

const orderHandler = require('./orderHandler')
const orderValidations = require('./orderValidations')

const API = '/' + config.get('app.name') + '/api/1.0/order'

const routes = []

routes.push({
  path: API + '/addOrder',
  method: 'POST',
  handler: orderHandler.addOrder,
  options: {
    auth: 'jwt-app',
    tags: ['api'],
    validate: orderValidations.addOrder
  }
})
routes.push({
  path: API + '/addOrderGuest',
  method: 'POST',
  handler: orderHandler.addOrderGuest,
  options: {
    auth: false,
    tags: ['api'],
    validate: orderValidations.addOrderGuest
  }
})

routes.push({
  path: API + '/getOrderHistory',
  method: 'GET',
  handler: orderHandler.getOrderHistory,
  options: {
    auth: 'jwt-app',
    tags: ['api']
  }
})
routes.push({
  path: API + '/getCartItems',
  method: 'GET',
  handler: orderHandler.getCartItems,
  options: {
    auth: 'jwt-app',
    tags: ['api']
  }
})

routes.push({
  path: API + '/addToCart',
  method: 'POST',
  handler: orderHandler.addToCart,
  options: {
    auth: 'jwt-app',
    tags: ['api'],
    validate: orderValidations.addToCart
  }
})

routes.push({
  path: API + '/confirmPaymentStatus',
  method: 'POST',
  handler: orderHandler.confirmPaymentStatus,
  options: {
    auth: false,
    tags: ['api'],
    validate: orderValidations.confirmPaymentStatus
  }
})

routes.push({
  path: API + '/getUserOrders',
  method: 'GET',
  handler: orderHandler.getUserOrders,
  options: {
    auth: 'jwt-app',
    tags: ['api']
  }
})
routes.push({
  path: API + '/changeDeliveryStatus',
  method: 'POST',
  handler: orderHandler.changeDeliveryStatus,
  options: {
    auth: 'jwt-app',
    tags: ['api'],
    validate: orderValidations.changeDeliveryStatus
  }
})

routes.push({
  path: API + '/addOrderV3',
  method: 'POST',
  handler: orderHandler.addOrderV3,
  options: {
    auth: 'jwt-app',
    tags: ['api'],
    validate: orderValidations.addOrderV3
  }
})
routes.push({
  path: API + '/addOrderGuestV3',
  method: 'POST',
  handler: orderHandler.addOrderV3,
  options: {
    auth: false,
    tags: ['api'],
    validate: orderValidations.addOrderV3
  }
})
routes.push({
  path: API + '/getCartItemsGuest',
  method: 'GET',
  handler: orderHandler.getCartItemsGuest,
  options: {
    auth: false,
    tags: ['api'],
    validate: orderValidations.getCartItemsGuest
  }
})
routes.push({
  path: API + '/addGuestCartItems',
  method: 'POST',
  handler: orderHandler.addGuestCartItems,
  options: {
    auth: false,
    tags: ['api'],
    validate: orderValidations.addGuestCartItems
  }
})

module.exports = routes
