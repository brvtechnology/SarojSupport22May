'use strict'

const joi = require('joi')

const addOrder = {
  payload: {
    orderType: joi.string().allow(['product', 'event']),
    contact: joi.object().allow(null),
    address: joi.object().allow(null),
    info: joi.object().allow(null),
    amount: joi.number().required(),
    resetCart: joi.boolean().required()
  },
  options: {
    allowUnknown: true
  }
}
const addOrderGuest = {
  payload: {
    orderType: joi.string().allow(['product', 'event']),
    contact: joi.object().allow(null),
    address: joi.object().allow(null),
    info: joi.object().allow(null),
    amount: joi.number().required(),
    resetCart: joi.boolean().allow(null).default(false),
    cartKey: joi.string().required()
  },
  options: {
    allowUnknown: true
  }
}

const addToCart = {
  payload: {
    cartItems: joi.array().required()
  },
  options: {
    allowUnknown: true
  }
}

const confirmPaymentStatus = {
  payload: {
    payment_id: joi.string().required(),
    payment_request_id: joi.string().required(),
    status: joi.string().required()
  },
  options: {
    allowUnknown: true
  }
}

const changeDeliveryStatus = {
  payload: {
    id: joi.number().integer().required(),
    status: joi.string().required()
  },
  options: {
    allowUnknown: true
  }
}

const addOrderV3 = {
  payload: {
    contact: joi.object().allow(null),
    address: joi.object().allow(null),
    info: joi.object().allow(null),
    useWalletBalance: joi.boolean().allow(null),
    couponCode: joi.string().allow(null),
    resetCart: joi.boolean().allow(null).default(false)
  },
  options: {
    allowUnknown: true
  }
}
const getCartItemsGuest = {
  query: {
    uuid: joi.string().allow(null)
  },
  options: {
    allowUnknown: true
  }
}
const addGuestCartItems = {
  payload: {
    uuid: joi.string().allow(null),
    cartItems: joi.array().required()
  },
  options: {
    allowUnknown: true
  }
}
module.exports = {
  addOrder,
  addOrderGuest,
  addToCart,
  confirmPaymentStatus,
  changeDeliveryStatus,
  addOrderV3,
  getCartItemsGuest,
  addGuestCartItems
}
