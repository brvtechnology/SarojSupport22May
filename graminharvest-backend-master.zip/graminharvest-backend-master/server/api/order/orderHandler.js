'use strict'

const boom = require('boom')
const logger = require('../../utils/logger')
const {sendSMS} = require('../awsUtils/awsHandler')
const axios = require('axios')
const config = require('config')
const {v4} = require('uuid')
const Sequelize = require('sequelize')
const Op = Sequelize.Op
const {payMoneyFromWallet, initiatePayment, deductFromWallet} = require('../wallet/walletService')
const REDIRECT_URL = config.get('app.clientGateway') + '/profile'
const CALLBACK_URL = config.get('app.backendGateway') + '/' + config.get('app.name') + '/api/v1/wallet/confirmPaymentStatus'
const moment = require('moment')
const bangalorePincodes =
[560001, 560002, 560003, 560004, 560005, 560006, 560007, 560008, 560009, 560010, 560011, 560012, 560013, 560014, 560015, 560016, 560017, 560018, 560019, 560020, 560021, 560022, 560023, 560024, 560025, 560026, 560027, 560029, 560030, 560032, 560033, 560034, 560035, 560036, 560037, 560038, 560039, 560040, 560041, 560042, 560043, 560045, 560046, 560047, 560048, 560049, 560050, 560051, 560053, 560054, 560055, 560056, 560057, 560058, 560059, 560060, 560061, 560062, 560063, 560064, 560065, 560066, 560067, 560068, 560070, 560071, 560072, 560073, 560074, 560075, 560076, 560077, 560078, 560079, 560080, 560082, 560083, 560084, 560085, 560086, 560087, 560090, 560091, 560092, 560093, 560094, 560095, 560096, 560097, 560098, 560099, 560100, 560102, 560103, 560104, 560105, 560300, 562106, 562107, 562120, 562125, 562130, 562149, 562157]

const addOrder = async (req) => {
  /*
    1.create payment link
    2.save details backend
  */
  try {
    let db = req.getDb()
    let order = db.getModel('Order')
    let Wallet = db.getModel('UserPaymentInfo')
    let OrderTransaction = db.getModel('UserOrderTransaction')
    let TransactionTable = db.getModel('UserPaymentTransaction')
    let request = req.payload
    let {contact, address, info, useWalletBalance} = req.payload
    let {id: userId} = req.auth.credentials
    let payload = { userId, contact, address }
    payload.orderId = v4()
    // verify price
    let ProductModel = db.getModel('Product')
    let productIds = info.orders.map(p => p.id)
    let deliveryChargeComputed = bangalorePincodes.includes(Number(address.pincode)) ? 35 : 54
    let totalAmount = await getTotalPrice(ProductModel, productIds, info.orders, deliveryChargeComputed)
    let paymentLink = ''

    let totalWalletAmountToAdd = 0
    if (useWalletBalance && userId !== 0) {
      let wallet = await Wallet.findOne({where: {userId}, raw: true})
      if (!wallet) {
        return boom.badRequest('Failed to fetch user wallet')
      }
      let {userDeposit, userPromoMoney} = wallet
      let totalWalletBalance = userDeposit + userPromoMoney
      totalWalletAmountToAdd = totalWalletBalance >= totalAmount ? 0 : (totalAmount - totalWalletBalance)
    } else {
      totalWalletAmountToAdd = totalAmount
    }

    payload.totalAmount = totalAmount
    payload.walletAmount = totalWalletAmountToAdd

    if (totalWalletAmountToAdd !== 0) {
      payload.info = {
        paymentStatus: 'Initiated',
        orderInfo: info
      }
      // Get users email and phone
      let { email, phone, name } = req.payload.contact
      // Create Payment Link
      let paymentRequestBody = {
        purpose: 'BUY_PRODUCT',
        amount: totalWalletAmountToAdd.toString(),
        phone,
        email,
        buyer_name: name,
        redirect_url: REDIRECT_URL,
        send_email: true,
        webhook: CALLBACK_URL,
        send_sms: true,
        allow_repeated_payments: false
      }

      payload.info.payment = {
        before: paymentRequestBody
      }

      let paymentReq = await initiatePayment(paymentRequestBody)

      if (paymentReq && paymentReq.success) {
        payload.info.payment.after = paymentReq.payment_request
        payload.info.pid = paymentReq.payment_request.id
        paymentLink = payload.info.payment.after.longurl
        // if wallet request
        if (userId !== 0) {
          let makeTransactionDetail = {
            userId,
            orderId: payload.orderId,
            transactionAmount: totalWalletAmountToAdd,
            transactionId: payload.info.pid,
            statusCode: 0, // -1 : Failed, Success: 1, 0: Pending
            purpose: 'BUY_PRODUCT',
            paymentUrl: paymentLink,
            info: Object.assign({}, paymentReq, {paymentGatewayName: 'INSTAMOJO'})
          }
          TransactionTable.create(makeTransactionDetail)
        }
      }
    } else {
      payload.info = {
        orderInfo: info
      }

      await payMoneyFromWallet(Wallet, OrderTransaction, userId, payload.orderId, totalWalletAmountToAdd)
      payload.paymentStatus = 'Completed'
    }

    // create order : Do not wait
    order.create(payload)
    // send SMS & Email
    if (totalWalletAmountToAdd > 0) {
      sendSMS({
        phone: `+91${request.contact.phone}`,
        message: `Hi ${request.contact.name}, \nYour order has been initiated successfully. 
        \nPlease complete payment so that we can proceed farther. \nThank you for visiting www.graminharvest.com`,
        subject: 'Order'
      })
    } else {
      sendSMS({
        phone: `+91${request.contact.phone}`,
        message: `Hi ${request.contact.name}, \nYour order has been placed successfully. 
        \nThank you for visiting www.graminharvest.com`,
        subject: 'Order'
      })
    }

    if (userId !== 0) {
      // reset cart
      let Cart = db.getModel('Cart')
      let findUserCart = await Cart.findOne({where: {userId}})
      if (findUserCart) {
        await findUserCart.updateAttributes({cartItems: []})
      }
    }

    return paymentLink || 'success'
  } catch (error) {
    console.log(error)
    const errorMessage = `Failed to Place order`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getTotalPrice = async (ProductModel, productIds, orders, deliveryChargeComputed, userId, couponCode, CouponModel, CouponOrderModel) => {
  let totalDiscountedPrice = 0
  let allOrderedProducts = await ProductModel.findAll({
    where: {
      id: { [Op.in]: productIds }
    },
    raw: true
  })
  if (!allOrderedProducts) {
    return boom.badRequest('Something went wrong')
  }
  // construct amount
  allOrderedProducts.forEach(aop => {
    let endPrice = 0
    if (aop.discountType.toLowerCase() === 'percentage') {
      endPrice = aop.price - ((aop.price * aop.discount) / 100)
    } else if (aop.discountType.toLowerCase() === 'rs') {
      endPrice = aop.price - aop.discount
    } else throw new Error('Discount type not supported')
    let orderedProduct = orders.find(o => o.id === aop.id)
    totalDiscountedPrice += (endPrice * orderedProduct.quantity)
  })

  let computedPrice = totalDiscountedPrice
  // console.log('1', computedPrice)
  // console.log(couponCode)
  if (!couponCode) return computedPrice + deliveryChargeComputed
  else {
    // console.log('jhsahsaghjca')
    computedPrice = await applyCoupon({computedPrice, couponCode, CouponModel, CouponOrderModel, userId})
    // console.log('2', computedPrice)
    return computedPrice + deliveryChargeComputed
  }
}
const applyCoupon = async ({computedPrice, couponCode, CouponModel, CouponOrderModel, userId}) => {
  let [couponObj, couponOrders] = await Promise.all([CouponModel.findOne({where: {coupon_code: couponCode}, raw: true}),
    CouponOrderModel.findAll({where: {coupon_code: couponCode, user_id: userId}, raw: true})])

  isCouponApplicable({couponObj, couponOrders, computedPrice})
  let afterCouponPrice = computeNewAmount({ computedPrice, couponObj })

  await CouponOrderModel.create({
    coupon_code: couponObj.coupon_code,
    user_id: userId || 0,
    order_id: v4(),
    cashback_received: couponObj.max_cashback

  })
  return afterCouponPrice
}

const isCouponApplicable = ({couponObj, couponOrders, computedPrice}) => {
/*
    checks:
      1. is coupon code valid
      2. is couopon code expired
      3. is quota finished for user
      4. check if user has done minimum amount of purchase
*/

  if (!couponObj) throw new Error("Coupon doesn't exist")
  else if (moment(couponObj.expiry_date) < moment().utc().format()) throw new Error('OOPS!!! coupon expired')
  else if (couponOrders.length >= couponObj.allowedPerUser) throw new Error('OOPS!!! You have already exceeded maximum use for this coupon')
  else if (computedPrice < couponObj.minimum_amount_to_apply) throw new Error(`OOPS!!! To apply coupon on this order atleaset make purchase of ${couponObj.minimum_amount_to_apply}`)
}

const computeNewAmount = ({ computedPrice, couponObj }) => {
  // console.log(computedPrice)
  // console.log(couponObj)
  if (couponObj.type === 'amount') return computedPrice - couponObj.coupon_amount
  else {
    let possibleDiscount = computedPrice - Math.round((computedPrice * couponObj.coupon_amount) / 100)
    // console.log(possibleDiscount, 'possiblrdiscount')
    possibleDiscount = Math.min(couponObj.max_cashback, possibleDiscount)
    console.log(possibleDiscount, 'possiblrdiscount2')
    // possibleDiscount = couponObj.coupon_amount >= computedPrice ? 0 : possibleDiscount
    // console.log(possibleDiscount)
    return computedPrice - possibleDiscount
  }
}

const addOrderGuest = async (req) => {
  /*
1.create payment link
2.save datain backend
  */
  try {
    let db = req.getDb()
    let order = db.getModel('Order')
    let request = req.payload
    let GuestCartModel = db.getModel('guest_cart')
    let {amount, orderType, contact, address, info, resetCart, cartKey} = req.payload
    // let {id: userId} = req.auth.credentials
    let payload = { orderId: 0, orderType, contact, address }
    let dbAllotedPrice = 0
    let deliveryChargeComputed = 54
    let eventFlag = false
    let eventNames = ''
    let productNames = ''
    let j = 0
    let k = 0
    // verify price
    if (orderType === 'event') {
      let EventsModel = db.getModel('Events')
      eventFlag = true
      let eventIds = []
      info.orders.forEach(e => {
        eventIds.push(e.id)
        eventNames = eventNames + e.eventName + ','
        j = j + 1
      })
      eventNames = eventNames.substr(0, (eventNames.length - 1))
      let allEvents = await EventsModel.findAll({
        where: {
          id: { [Op.in]: eventIds }
        },
        raw: true
      })
      allEvents.forEach(ae => {
        dbAllotedPrice += ae.fee
      })
      // console.log(dbAllotedPrice, 'db alloted price')
      // console.log(amount, 'amt')
      if ((dbAllotedPrice) !== amount) throw new Error('Something Went Wrong')
    } else if (orderType === 'product') {
      let ProductModel = db.getModel('Product')
      let productIds = []
      info.orders.forEach(p => {
        productIds.push(p.id)
        productNames = productNames + p.name + ','
        k = k + 1
      })
      productNames = productNames.substr(0, (productNames.length - 1))
      let allOrderedProducts = await ProductModel.findAll({
        where: {
          id: { [Op.in]: productIds }
        },
        raw: true
      })
      // construct amount
      allOrderedProducts.forEach(aop => {
        let endPrice = 0
        if (aop.discountType === 'Percentage' || aop.discountType === 'percentage') {
          endPrice = aop.price - ((aop.price * aop.discount) / 100)
        } else if (aop.discountType === 'RS' || aop.discountType === 'rs') {
          endPrice = aop.price - aop.discount
        } else throw new Error('Discount type not supported')
        let orderedProduct = info.orders.find(o => o.id === aop.id)

        dbAllotedPrice += (endPrice * orderedProduct.quantity)
      })
      if (bangalorePincodes.includes(Number(address.pincode))) deliveryChargeComputed = 35
      // console.log(dbAllotedPrice, 'dballocatedprice')
      console.log(deliveryChargeComputed, 'deliverycharge')
      // console.log(amount, 'amount')
      // if (Math.floor((dbAllotedPrice + deliveryChargeComputed)) !== Math.floor(amount)) throw new Error('Something Went Wrong')
    } else throw new Error('Wrong Order type')

    payload.info = {
      paymentStatus: 'Initiated',
      clientOrderId: v4(),
      orderInfo: info
    }
    // Get users email and phone
    let { email, phone, name } = req.payload.contact
    // Create Payment Link
    let paymentRequestBody = {
      purpose: 'Placing Order',
      amount: amount.toString(),
      phone,
      email,
      buyer_name: name,
      redirect_url: 'https://honeyday.in/orders',
      send_email: false,
      webhook: 'https://api.honeyday.in/honeydaybfarms/api/1.0/order/confirmPaymentStatus',
      send_sms: true,
      allow_repeated_payments: false
    }

    payload.info.payment = {
      before:
        paymentRequestBody
    }

    // Instamojo headers
    const headers = config.get('instamojo.headers')

    let paymentReq = await axios({
      method: 'POST',
      url: config.get('instamojo.createrequesturl'),
      headers,
      data: paymentRequestBody
    })
    // console.log(paymentReq, 'paymentreq')
    if (paymentReq) {
      payload.info.payment.after = paymentReq.data.payment_request
      payload.info.pid = paymentReq.data.payment_request.id
    }
    // console.log(payload, '1')
    // create order : Do not wait
    await order.create(payload)
    // console.log(payload, '2')
    // send SMS & Email

    if (eventFlag) {
      sendSMS({
        phone: `+91${request.contact.phone}`,
        message: `Hi ${request.contact.name}, \nYour event booking for ${eventNames} ${(k > 1) ? 'have' : 'has'} been confirmed. 
        \nPlease complete payment so that we can proceed farther. \nThank you for visiting www.honeyday.in`,
        subject: 'Order'
      })
    } else {
      sendSMS({
        phone: `+91${request.contact.phone}`,
        message: `Hi ${request.contact.name}, \nYour order for ${productNames} ${(k > 1) ? 'have' : 'has'} been initiated successfully. 
      \nPlease complete payment so that we can proceed farther. \nThank you for visiting www.honeyday.in`,
        subject: 'Order'
      })
    }

    /* await sendSMS({
      phone: `+91${request.contact.phone}`,
      message: `Hi ${request.contact.name}, \nYour order has been initiated successfully.
      \nPlease complete payment so that we can proceed farther. \nThank you for visiting www.honeyday.in`,
      subject: 'Order'
    }) */
    // console.log('sendsms done')
    if (resetCart) {
      GuestCartModel.destroy({where: {uuid: cartKey}})
    }
    return payload.info.payment.after.longurl
  } catch (error) {
    console.log(error)
    const errorMessage = `Failed to Place order`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getOrderHistory = async (req) => {
  try {
    let db = req.getDb()
    let order = db.getModel('Order')
    return order.findAll()
  } catch (error) {
    const errorMessage = `Failed to get order history`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const addToCart = async (req) => {
  try {
    let db = req.getDb()
    let CartModel = db.getModel('Cart')
    let {cartItems} = req.payload
    let {id: userId} = req.auth.credentials
    let findUserCart = await CartModel.findOne({where: {userId}})
    if (findUserCart) {
      await findUserCart.updateAttributes({cartItems})
      return CartModel.findOne({where: {userId}})
    } else throw new Error('Cart Not Found')
  } catch (error) {
    const errorMessage = `Failed to Cart Items`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getCartItems = async (req) => {
  try {
    let db = req.getDb()
    let CartModel = db.getModel('Cart')
    let {id: userId} = req.auth.credentials
    const emptyResponse = {
      cartItems: []
    }
    let items = await CartModel.findOne({where: {userId}})
    return items || emptyResponse
  } catch (error) {
    const errorMessage = `Failed to get Cart Items`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const confirmPaymentStatus = async (req) => {
  try {
    let db = req.getDb()
    let orderModel = db.getModel('Order')
    // let ProductModel = db.getModel('Product')
    let {payment_id: paymentId, payment_request_id: paymentRequestId, status} = req.payload

    let findTransaction = await orderModel.findOne({where: {info: { pid: paymentRequestId }}})
    if (findTransaction && findTransaction.userId) {
      let isInitiated = findTransaction.info.paymentStatus === 'Initiated'
      if (isInitiated && status === 'Credit') {
        findTransaction.info.paymentStatus = 'Placed'
        let modifiedInfo = Object.assign({}, findTransaction.info, {instamojo_payment_id: paymentId})
        await findTransaction.updateAttributes({ info: modifiedInfo })
      } else if (isInitiated && status === 'Failed') {
        findTransaction.info.paymentStatus = 'Failed'
        let modifiedInfo = Object.assign({}, findTransaction.info, {instamojo_payment_id: paymentId})
        await findTransaction.updateAttributes({ info: modifiedInfo })
      }
    }

    return ('Ok')
  } catch (error) {
    // const errorMessage = `Failed to PayMoneyIntoContest`
    console.log(error)
    return ('OK')
  }
}

const getUserOrders = async (req) => {
  try {
    let db = req.getDb()
    let Order = db.getModel('Order')
    let {id: orderId} = req.auth.credentials
    let orders = await Order.findAll({where: {orderId}})
    return orders || []
  } catch (error) {
    const errorMessage = `Failed to get User Order`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}
const changeDeliveryStatus = async (req) => {
  try {
    let db = req.getDb()
    let orderModel = db.getModel('Order')
    let {id, status} = req.payload
    let order = await orderModel.findById(id)
    deliveryStatusTemplate.forEach(ds => {
      if (ds.currentStatus === status) { order.info.paymentStatus = ds.nextStatus }
      sendSMS({
        phone: `+91${order.contact.phone}`,
        message: `Hi ${order.contact.name}, \nOrder status for your order no ${id} is ${status} . 
         \nThank you for visiting www.honeyday.in`,
        subject: 'Order'
      })
    })
    return order.updateAttributes({info: order.info})
  } catch (error) {
    const errorMessage = `Failed to get productTypes`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const addOrderV2 = async (req) => {
  let db = req.getDb()
  // Db Models
  const OrderModel = db.getModel('Order')
  const WalletModel = db.getModel('UserPaymentInfo')
  const OrderTransactionModel = db.getModel('UserOrderTransaction')
  const TransactionTableModel = db.getModel('UserPaymentTransaction')
  const ProductModel = db.getModel('Product')
  let CartModel = db.getModel('Cart')

  // variables in hand
  let {contact, address, info, useWalletBalance} = req.payload
  let {id: userId} = req.auth && req.auth.credentials ? req.auth.credentials : 0
  let orderPayload = { userId, contact, address, orderId: v4() }
  // main code below
  let orderIdArr = getOrderIds({arr: info.orders})
  let deliveryChargeComputed = getDeliveryCharge({pinCode: address.pincode})

  let totalAmount = await getTotalPrice(ProductModel, orderIdArr, info.orders, deliveryChargeComputed)

  let modifiedOrderPayload = attachValueToKey({obj: orderPayload, key: 'info', val: { paymentStatus: 'Initiated', orderInfo: info }})

  let paymentReqObj = {
    purpose: 'BUY_PRODUCT',
    amount: totalAmount.toString(),
    phone: modifiedOrderPayload.phone,
    email: modifiedOrderPayload.email,
    buyer_name: modifiedOrderPayload.name,
    redirect_url: REDIRECT_URL,
    send_email: true,
    webhook: CALLBACK_URL,
    send_sms: true,
    allow_repeated_payments: false
  }

  await orderActivity({OrderModel, WalletModel, OrderTransactionModel, TransactionTableModel, modifiedOrderPayload, paymentReqObj, userId, useWalletBalance, CartModel})
}
const orderActivity = ({OrderModel, WalletModel, OrderTransactionModel, TransactionTableModel, modifiedOrderPayload, paymentReqObj, userId, useWalletBalance, CartModel}) => {
  return filterFunc({userId: modifiedOrderPayload.userId}) === 'walletFlow' ? walletFlow({OrderModel, WalletModel, OrderTransactionModel, TransactionTableModel, modifiedOrderPayload, paymentReqObj, userId, useWalletBalance, CartModel}) : directFlow({OrderModel, WalletModel, OrderTransactionModel, TransactionTableModel, modifiedOrderPayload, paymentReqObj, userId})
}
const filterFunc = ({userId}) => userId ? 'walletFlow' : 'directFlow'

const directFlow = async ({OrderModel, TransactionTableModel, modifiedOrderPayload, paymentReqObj, userId}) => {
  let paymentReq = await initiatePayment(paymentReqObj)

  if (paymentReq && paymentReq.success) {
    let after = paymentReq.payment_request
    let pid = paymentReq.payment_request.id
    let paymentLink = modifiedOrderPayload.info.payment.after.longurl

    TransactionTableModel.create({
      userId,
      orderId: modifiedOrderPayload.orderId,
      transactionAmount: paymentReqObj.amount,
      transactionId: pid,
      statusCode: 0, // -1 : Failed, Success: 1, 0: Pending
      purpose: 'BUY_PRODUCT',
      paymentUrl: paymentLink,
      info: Object.assign({}, paymentReq, {paymentGatewayName: 'INSTAMOJO'})
    })
    let finalInfo = Object.assign({}, modifiedOrderPayload.info, {after, pid})

    let finalPayload = Object.assign({}, modifiedOrderPayload, finalInfo)

    OrderModel.create(finalPayload)
    sendSMS({
      phone: `+91${paymentReqObj.phone}`,
      message: `Hi ${paymentReqObj.name}, \nYour order has been placed successfully. 
    \nThank you for visiting www.graminharvest.com`,
      subject: 'Order'
    })
    return paymentLink || 'success'
  } else throw new Error('Something went Wrong!!! Try again')
}

const walletFlow = async ({OrderModel, WalletModel, OrderTransactionModel, TransactionTableModel, modifiedOrderPayload, paymentReqObj, userId, useWalletBalance, CartModel}) => {
  let decidedAmount = await decideAmountFunc({WalletModel, amount: paymentReqObj.amount, userId, useWalletBalance})
  let modifiedPaymentReqObj = Object.assign({}, paymentReqObj, {amount: decidedAmount})
  let paymentLink = ''
  let finalPayload

  if (!decidedAmount) { await payMoneyFromWallet(WalletModel, OrderTransactionModel, userId, OrderTransactionModel.orderId, decidedAmount) } else {
    let paymentReq = await initiatePayment(modifiedPaymentReqObj)

    if (paymentReq && paymentReq.success) {
      let after = paymentReq.payment_request
      let pid = paymentReq.payment_request.id
      paymentLink = modifiedOrderPayload.info.payment.after.longurl
      let decidedAmount = await decideAmountFunc({WalletModel, amount: paymentReqObj.amount, userId, useWalletBalance})
      TransactionTableModel.create({
        userId,
        orderId: modifiedOrderPayload.orderId,
        transactionAmount: decidedAmount,
        transactionId: pid,
        statusCode: 0, // -1 : Failed, Success: 1, 0: Pending
        purpose: 'BUY_PRODUCT',
        paymentUrl: paymentLink,
        info: Object.assign({}, paymentReq, {paymentGatewayName: 'INSTAMOJO'})
      })
      let finalInfo = Object.assign({}, modifiedOrderPayload.info, {after, pid})

      finalPayload = Object.assign({}, modifiedOrderPayload, finalInfo)
    }

    // OrderModel.create(finalPayload)
    await createOrder({OrderModel, finalPayload, decidedAmount})
    await clearCart({CartModel, userId})
    sendSMS({
      phone: `+91${paymentReqObj.phone}`,
      message: `Hi ${paymentReqObj.name}, \nYour order has been placed successfully. 
    \nThank you for visiting www.graminharvest.com`,
      subject: 'Order'
    })
    return paymentLink || 'success'
  }
}
const getOrderIds = ({arr}) => arr.map(a => a.id)
const getDeliveryCharge = ({pinCode}) => bangalorePincodes.includes(Number(pinCode)) ? 35 : 54

const attachValueToKey = ({obj, key, val}) => {
  [obj][key] = val
  return obj
}

const decideAmountFunc = async ({WalletModel, amount, userId, useWalletBalance}) => {
  let findMoneyInWallet = await WalletModel.findOne({where: {user_id: userId}})
  return useWalletBalance ? Math.max(amount - findMoneyInWallet.userPromoMoney, 0) : amount
}

const createOrder = ({finalPayload, decidedAmount, OrderModel}) => {
  let completedObj = Object.assign({}, finalPayload, {paymentStatus: 'Completed'})
  return decidedAmount ? OrderModel.create(completedObj) : OrderModel.create(finalPayload)
}
const clearCart = async ({CartModel, userId}) => {
  let findUserCart = await CartModel.findOne({where: {userId}})
  if (findUserCart) {
    await findUserCart.updateAttributes({cartItems: []})
  }
}

const addOrderV3 = async (req) => {
  try {
  // Db Instance
    let db = req.getDb()
    // Db Models
    const OrderModel = db.getModel('Order')
    const WalletModel = db.getModel('UserPaymentInfo')
    const TransactionTableModel = db.getModel('UserPaymentTransaction')
    const ProductModel = db.getModel('Product')
    // const CartModel = db.getModel('Cart')
    const CouponModel = db.getModel('Coupons')
    const CouponOrderModel = db.getModel('coupon_orders')
    let Cart = db.getModel('Cart')
    let res
    // variables in hand
    // req.auth.credentials.id = 45
    let {contact, address, info, useWalletBalance, couponCode, resetCart} = req.payload
    let userId = (req.auth && req.auth.credentials) ? req.auth.credentials.id : 0
    // let userId = 45
    let orderPayload = { userId, contact, address, orderId: v4() }
    // main code below
    let productIds = getOrderIds({arr: info.orders})
    let deliveryChargeComputed = getDeliveryCharge({pinCode: address.pincode})
    couponCode = userId ? couponCode : null
    let totalAmount = await getTotalPrice(ProductModel, productIds, info.orders, deliveryChargeComputed, userId, couponCode, CouponModel, CouponOrderModel)
    console.log(totalAmount)
    // let x = 1
    // if (x) return 'blah'
    if (+userId === 0) {
      res = await directPaymentFlow({totalAmount, orderPayload, info, OrderModel, userId, TransactionTableModel})
    } else {
      res = await walletPaymentFlow({ totalAmount, orderPayload, info, OrderModel, TransactionTableModel, userId, useWalletBalance, WalletModel })
      return res
    }
    // RESET CART
    if (resetCart) {
      let findUserCart = await Cart.findOne({where: {userId}})
      if (findUserCart) {
        await findUserCart.updateAttributes({cartItems: []})
      }
    }
    return res
  } catch (err) {
    return boom.badRequest('Failed to add your order')
  }
}

const directPaymentFlow = async ({ totalAmount, orderPayload, info, OrderModel, TransactionTableModel, userId }) => {
  /*
  checkout status:

  1. 1000: User did not choose to pay from wallet
  2. 1001: User Not Logged iN/gUEST uSER

  */

  let initiatePayment = await initiatePaymentRequest({totalAmount, orderPayload, info})
  info = initiatePayment.info

  info.paymentStatus = 'Initiated'
  let paymentLink = ''

  if (initiatePayment && initiatePayment.paymentReq && initiatePayment.paymentReq.success) {
    info.payment.after = initiatePayment.paymentReq.payment_request
    info.pid = initiatePayment.paymentReq.payment_request.id
    paymentLink = initiatePayment.paymentReq.payment_request.longurl
  }
  info.checkoutStatus = userId ? 1000 : 1001

  let payload = {
    userId,
    orderId: orderPayload.orderId,
    contact: orderPayload.contact,
    totalAmount,
    walletAmount: 0,
    address: orderPayload.address,
    info
  }
  await OrderModel.create(payload)

  await TransactionTableModel.create({
    userId,
    orderId: orderPayload.orderId,
    transactionAmount: totalAmount,
    transactionId: info.pid,
    statusCode: 0,
    purpose: 'BUY_PRODUCT',
    paymentUrl: paymentLink,
    info
  })
  sendSMS({
    phone: `+91${orderPayload.contact.phone}`,
    message: `Hi ${orderPayload.contact.name}, \nYour order has been initiated successfully.
    \nPlease complete the payment in order to continue 
    \nThank you for visiting www.graminharvest.com`,
    subject: 'Order'
  })
  return {
    hasPaymentLink: true,
    paymentLink
  }
}
const initiatePaymentRequest = async ({totalAmount, orderPayload, info}) => {
  info = {
    paymentStatus: 'Initiated',
    orderInfo: info
  }

  // Get users email and phone
  let { email, phone, name } = orderPayload.contact
  // Create Payment Link
  let paymentRequestBody = {
    purpose: 'BUY_PRODUCT',
    amount: totalAmount.toString(),
    phone,
    email,
    buyer_name: name,
    redirect_url: REDIRECT_URL,
    send_email: true,
    webhook: CALLBACK_URL,
    send_sms: true,
    allow_repeated_payments: false
  }

  // saving the response of what user tried before payment
  info.payment = {
    before: paymentRequestBody
  }
  let paymentReq = await initiatePayment(paymentRequestBody)

  return {paymentReq, info}
}

const walletPaymentFlow = async ({ TransactionTableModel, totalAmount, orderPayload, info, OrderModel, userId, useWalletBalance, WalletModel }) => {
  console.log('1')
  let res
  console.log(res)
  !useWalletBalance ? res = await directPaymentFlow({ totalAmount, orderPayload, info, OrderModel, userId, TransactionTableModel }) : res = await withWalletFlow({ totalAmount, orderPayload, info, OrderModel, userId, WalletModel, TransactionTableModel })
  return res
}
const withWalletFlow = async ({ totalAmount, orderPayload, info, OrderModel, userId, WalletModel, TransactionTableModel }) => {
  console.log('2')
  let res
  console.log(res)
  let currentWalletBalance = await WalletModel.findOne({where: {user_id: userId}, raw: true})
  console.log(currentWalletBalance)
  let modifiedTotalAmount = totalAmount - (currentWalletBalance.userPromoMoney + currentWalletBalance.userDeposit)
  console.log(totalAmount)
  console.log(modifiedTotalAmount)
  if (modifiedTotalAmount <= 0) {
    res = await swiftlyPlaceOrder({ totalAmount, orderPayload, info, OrderModel, userId, WalletModel, moneyToDeductFromWallet: totalAmount, currentWalletBalance, TransactionTableModel })
  } else res = divergePlaceOrder({ totalAmount, orderPayload, info, OrderModel, userId, WalletModel, moneyToDeductFromWallet: (currentWalletBalance.userDeposit + currentWalletBalance.userPromoMoney), currentWalletBalance, TransactionTableModel })
  return res
}

const swiftlyPlaceOrder = async ({ totalAmount, TransactionTableModel, orderPayload, info, OrderModel, userId, WalletModel, moneyToDeductFromWallet }) => {
  console.log('3')
  info = {
    paymentStatus: 'Placed',
    orderInfo: info
  }
  info.checkoutStatus = 1002 // wallet has enough balance
  let payload = {
    userId,
    orderId: orderPayload.orderId,
    contact: orderPayload.contact,
    totalAmount,
    walletAmount: moneyToDeductFromWallet,
    address: orderPayload.address,
    info
  }
  await OrderModel.create(payload)
  await TransactionTableModel.create({
    userId,
    orderId: orderPayload.orderId,
    transactionAmount: totalAmount,
    transactionId: v4(),
    statusCode: 1,
    purpose: 'BUY_PRODUCT',
    paymentUrl: '',
    info
  })
  await deductFromWallet({WalletModel, moneyToDeductFromWallet, userId})
  sendSMS({
    phone: `+91${orderPayload.contact.phone}`,
    message: `Hi ${orderPayload.contact.name}, \nYour order has been placed successfully. 
    \nThank you for visiting www.graminharvest.com`,
    subject: 'Order'
  })
  return {
    hasPaymentLink: false,
    isCompleted: true,
    message: 'Your order has been placed successfully'
  }
}
const divergePlaceOrder = async ({ totalAmount, TransactionTableModel, orderPayload, info, OrderModel, userId, WalletModel, moneyToDeductFromWallet }) => {
  let initiatePayment = await initiatePaymentRequest({totalAmount: (totalAmount - moneyToDeductFromWallet), orderPayload, info})
  info = initiatePayment.info

  info.paymentStatus = 'Initiated'
  let paymentLink = ''
  if (initiatePayment && initiatePayment.paymentReq && initiatePayment.paymentReq.success) {
    info.payment.after = initiatePayment.paymentReq.payment_request
    info.pid = initiatePayment.paymentReq.payment_request.id
    paymentLink = initiatePayment.paymentReq.payment_request.longurl
  }
  info.checkoutStatus = 1003 // money deducted from walet and had to be paid

  let payload = {
    userId,
    orderId: orderPayload.orderId,
    contact: orderPayload.contact,
    totalAmount: (totalAmount - moneyToDeductFromWallet),
    walletAmount: moneyToDeductFromWallet,
    address: orderPayload.address,
    info
  }
  await OrderModel.create(payload)
  await TransactionTableModel.create({
    userId,
    orderId: orderPayload.orderId,
    transactionAmount: totalAmount,
    transactionId: info.pid,
    statusCode: 0,
    purpose: 'BUY_PRODUCT',
    paymentUrl: paymentLink,
    info
  })
  sendSMS({
    phone: `+91${orderPayload.contact.phone}`,
    message: `Hi ${orderPayload.contact.name}, \nYour order has been initiated successfully.
    \nPlease complete the payment in order to continue
    \nThank you for visiting www.graminharvest.com`,
    subject: 'Order'
  })
  return {
    hasPaymentLink: true,
    paymentLink
  }
}
const placeOrderSuccessfully = async ({orderModel, orderObj}) => {
  orderObj.info.paymentStatus = 'Placed'
  await orderModel.update({info: orderObj.info}, {where: {orderId: orderObj.orderId}})
}
const getCartItemsGuest = async (req) => {
  let db = req.getDb()
  // Db Models
  const GuestCartModel = db.getModel('guest_cart')
  let {uuid} = req.query
  const emptyResponse = {
    cartItems: []
  }
  if (!uuid) return emptyResponse
  else {
    let items = await GuestCartModel.findOne({where: {uuid}})
    return items || emptyResponse
  }
}
const addGuestCartItems = async (req) => {
  let db = req.getDb()
  // Db Models
  const GuestCartModel = db.getModel('guest_cart')
  let {uuid, cartItems} = req.payload
  if (!uuid) {
    uuid = v4()
    return GuestCartModel.create({uuid, cartItems})
  } else {
    let guestCart = await GuestCartModel.findOne({where: {uuid}, raw: true})

    if (!guestCart) {
      return boom.badRequest('No Guest Cart Found with that id')
    }
    await GuestCartModel.update({cartItems}, {where: {uuid}})
    return GuestCartModel.findOne({where: {uuid}, raw: true})
  }
}
const deliveryStatusTemplate = [
  {

    id: 1,
    currentStatus: 'Initiated',
    nextStatus: 'Placed'
  },
  {
    id: 2,
    currentStatus: 'Placed',
    nextStatus: 'Shipped'
  },
  {
    id: 3,
    currentStatus: 'Shipped',
    nextStatus: 'Delivered'
  }
]

module.exports = {
  addOrder,
  addOrderGuest,
  getOrderHistory,
  addToCart,
  getCartItems,
  confirmPaymentStatus,
  getUserOrders,
  changeDeliveryStatus,
  addOrderV2,
  addOrderV3,
  placeOrderSuccessfully,
  getCartItemsGuest,
  addGuestCartItems

}
