'use strict'

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('Cart', {
    userId: {
      type: DataTypes.INTEGER,
      field: 'user_id',
      allowNull: false
    },
    cartItems: {
      type: DataTypes.JSONB,
      field: 'cart_items',
      allowNull: false
    }
  })
}
