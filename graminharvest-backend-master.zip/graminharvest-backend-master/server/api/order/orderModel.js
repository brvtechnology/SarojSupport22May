'use strict'

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('Order', {
    userId: {
      type: DataTypes.INTEGER,
      field: 'user_id',
      allowNull: false
    },
    orderId: {
      type: DataTypes.UUID,
      field: 'order_id',
      allowNull: true
    },
    contact: {
      type: DataTypes.JSONB,
      field: 'contact',
      allowNull: true
    },
    totalAmount: {
      type: DataTypes.DOUBLE,
      field: 'total_amount',
      allowNull: false
    },
    walletAmount: {
      type: DataTypes.DOUBLE,
      field: 'wallet_amount',
      allowNull: false
    },
    address: {
      type: DataTypes.JSONB,
      field: 'address',
      allowNull: true
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: true
    }
  })
}
