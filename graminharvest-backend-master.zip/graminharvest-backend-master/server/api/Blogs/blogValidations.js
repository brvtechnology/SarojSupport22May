'use strict'

const joi = require('joi')

const addABlog = {
  payload: {
    name: joi.string().required(),
    blog_body: joi.string().allow(null),
    description: joi.string().required(),
    info: joi.object().allow(null)
  },
  options: {
    allowUnknown: true
  }
}

const editABlog = {
  payload: {
    blogId: joi.number().integer().required(),
    name: joi.string().required(),
    description: joi.string().required(),
    blog_body: joi.string().allow(null),
    info: joi.object().allow(null)
  },
  options: {
    allowUnknown: true
  }
}

const getAllBlogs = {
  query: {
    blogId: joi.number().integer().required()
  },
  options: {
    allowUnknown: true
  }
}
const changeBlogStatus = {
  payload: {
    blogId: joi.number().integer().required(),
    newStatus: joi.string().required()
  },
  options: {
    allowUnknown: true
  }
}
const getAllBlogsWeb = {
  query: {
    blogId: joi.number().integer().required()
  },
  options: {
    allowUnknown: true
  }
}
module.exports = {
  editABlog,
  addABlog,
  getAllBlogs,
  changeBlogStatus,
  getAllBlogsWeb
}
