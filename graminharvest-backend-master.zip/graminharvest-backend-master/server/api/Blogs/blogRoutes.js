'use strict'

const config = require('config')

const productTypeHandler = require('./blogHandler')
const productTypeValidations = require('./blogValidations')

const API = '/' + config.get('app.name') + '/api/1.0/blog'

const routes = []

routes.push({
  path: API + '/addABlog',
  method: 'POST',
  handler: productTypeHandler.addABlog,
  options: {
    auth: false,
    tags: ['api'],
    validate: productTypeValidations.addABlog
  }
})

routes.push({
  path: API + '/editABlog',
  method: 'POST',
  handler: productTypeHandler.editABlog,
  options: {
    auth: false,
    tags: ['api'],
    validate: productTypeValidations.editABlog
  }
})

routes.push({
  path: API + '/getAllBlogs',
  method: 'GET',
  handler: productTypeHandler.getAllBlogs,
  options: {
    auth: false,
    tags: ['api'],
    validate: productTypeValidations.getAllBlogs
  }
})
routes.push({
  path: API + '/changeBlogStatus',
  method: 'POST',
  handler: productTypeHandler.changeBlogStatus,
  options: {
    auth: false,
    tags: ['api'],
    validate: productTypeValidations.changeBlogStatus
  }
})
routes.push({
  path: API + '/getAllBlogsWeb',
  method: 'GET',
  handler: productTypeHandler.getAllBlogsWeb,
  options: {
    auth: false,
    tags: ['api'],
    validate: productTypeValidations.getAllBlogsWeb
  }
})

module.exports = routes
