'use strict'

const boom = require('boom')

const logger = require('../../utils/logger')

const addABlog = async (req) => {
  try {
    let db = req.getDb()

    console.log(req.payload)
    let blogModel = db.getModel('Blog')
    return await blogModel.create(req.payload)
  } catch (error) {
    const errorMessage = `Failed to add Blog Item`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const editABlog = async function (req) {
  try {
    let db = req.getDb()
    let {blogId: id} = req.payload
    let blogModel = db.getModel('Blog')
    let desiredBlog = await blogModel.findById(id)
    if (desiredBlog) {
      return desiredBlog.updateAttributes(req.payload)
    } else return boom.badRequest('Editing Blog Failed')
  } catch (error) {
    const errorMessage = `Failed to edit Blog`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getAllBlogs = async (req) => {
  try {
    let db = req.getDb()
    let blogModel = db.getModel('Blog')
    if (req.query.blogId === 0) {
      return await blogModel.findAll()
    } else {
      return await blogModel.findById(req.query.blogId)
    }
  } catch (error) {
    const errorMessage = `Failed to get blogs`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}
const changeBlogStatus = async function (req) {
  try {
    let db = req.getDb()
    let {blogId: id, newStatus} = req.payload
    let blogModel = db.getModel('Blog')
    let desiredBlog = await blogModel.findById(id)
    if (desiredBlog) {
      if (desiredBlog && desiredBlog.info.show === newStatus) return 'Success'
      else {
        console.log('here')
        let newInfo = Object.assign({}, desiredBlog.info, {show: newStatus})
        await desiredBlog.updateAttributes({info: newInfo})
        return 'Success'
      }
    } else return boom.badRequest('Editing Blog Failed')
  } catch (error) {
    const errorMessage = `Failed to edit Blog`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getAllBlogsWeb = async (req) => {
  try {
    let db = req.getDb()
    let blogModel = db.getModel('Blog')

    // If 0 is passed we are going to pass only blog Desc and name It tells that
    // web needs show on blog front page all blogs
    if (req.query.blogId === 0) {
      let allBlogs = await blogModel.findAll({raw: true})

      allBlogs.forEach(blog => {
        delete blog.blogContent
      })
      console.log(allBlogs)
      return allBlogs.filter(ab => ab.info.show === 'Yes')
    } else {
      let singleBlog = await blogModel.findById(req.query.blogId)
      if (singleBlog.info.show === 'No') return {}
      else return singleBlog
    }
  } catch (error) {
    const errorMessage = `Failed to get blogs`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

module.exports = {
  editABlog,
  addABlog,
  getAllBlogs,
  changeBlogStatus,
  getAllBlogsWeb
}
