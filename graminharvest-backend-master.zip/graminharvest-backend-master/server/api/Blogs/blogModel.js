'use strict'

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('Blog', {
    name: {
      type: DataTypes.STRING,
      field: 'blog_title',
      allowNull: false
    },
    description: {
      type: DataTypes.STRING,
      field: 'blog_desc',
      allowNull: false
    },
    blogContent: {
      type: DataTypes.TEXT,
      field: 'blog_content',
      allowNull: false
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: false
    }
  })
}
