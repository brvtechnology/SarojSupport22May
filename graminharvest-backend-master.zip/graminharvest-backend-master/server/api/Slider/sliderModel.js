'use strict'

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('Slider', {
    title: {
      type: DataTypes.STRING,
      field: 'title',
      allowNull: false
    },
    subTitle: {
      type: DataTypes.STRING,
      field: 'sub_title',
      allowNull: true
    },
    imgUrl: {
      type: DataTypes.STRING,
      field: 'img_url',
      allowNull: false
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: false
    }
  })
}
