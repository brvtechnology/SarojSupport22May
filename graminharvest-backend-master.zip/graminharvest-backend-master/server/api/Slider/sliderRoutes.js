'use strict'

const config = require('config')

const sliderHandler = require('./sliderHandler')
const sliderValidations = require('./sliderValidations')

const API = '/' + config.get('app.name') + '/api/1.0/slider'

const routes = []

routes.push({
  path: API + '/addNewSlider',
  method: 'POST',
  handler: sliderHandler.addNewSlider,
  options: {
    auth: false,
    tags: ['api'],
    validate: sliderValidations.addNewSlider
  }
})

routes.push({
  path: API + '/editNewSlider',
  method: 'POST',
  handler: sliderHandler.editNewSlider,
  options: {
    auth: false,
    tags: ['api'],
    validate: sliderValidations.editNewSlider
  }
})

routes.push({
  path: API + '/getSliders',
  method: 'GET',
  handler: sliderHandler.getSliders,
  options: {
    auth: false,
    tags: ['api'],
    validate: sliderValidations.getSliders
  }
})
routes.push({
  path: API + '/getSlidersWeb',
  method: 'GET',
  handler: sliderHandler.getSlidersWeb,
  options: {
    auth: false,
    tags: ['api'],
    validate: sliderValidations.getSlidersWeb
  }
})

module.exports = routes
