'use strict'

const boom = require('boom')

const logger = require('../../utils/logger')

const addNewSlider = async function (req) {
  try {
    let db = req.getDb()
    let slider = db.getModel('Slider')
    let result = await slider.create(req.payload)
    return result
  } catch (error) {
    const errorMessage = `Failed to add New Slider`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const editNewSlider = async function (req) {
  try {
    let db = req.getDb()
    let {sliderId: id} = req.payload
    let slider = db.getModel('Slider')
    let desiredslider = await slider.findById(id)
    if (desiredslider) {
      return desiredslider.updateAttributes(req.payload)
    } else return boom.badRequest('Editing slider Failed')
  } catch (error) {
    const errorMessage = `Failed to edit slider`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getSliders = async (req) => {
  try {
    let db = req.getDb()
    let sliders = db.getModel('Slider')
    let {sliderId} = req.query
    if (sliderId === 0) {
      // If productId is 0 backend assumes that client wants all product
      return await sliders.findAll()
    } else {
      return await sliders.findById(sliderId)
    }
  } catch (error) {
    const errorMessage = `Failed to get sliders`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getSlidersWeb = async (req) => {
  try {
    let db = req.getDb()
    let sliders = db.getModel('Slider')
    let {sliderId} = req.query
    if (sliderId === 0) {
      // If productId is 0 backend assumes that client wants all product
      let allSlider = await sliders.findAll({raw: true})
      return allSlider.filter(as => as.info.show === 'Yes')
    } else {
      let singleSlider = await sliders.findById(sliderId)
      if (singleSlider.info.show === 'Yes') return singleSlider
      else return {}
    }
  } catch (error) {
    const errorMessage = `Failed to get sliders`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}
module.exports = {
  addNewSlider,
  editNewSlider,
  getSliders,
  getSlidersWeb
}
