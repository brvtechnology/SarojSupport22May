'use strict'

const joi = require('joi')

const addNewSlider = {
  payload: {
    title: joi.string().required(),
    subTitle: joi.string().allow(null),
    imgUrl: joi.string().required(),
    info: joi.object().allow(null)
  },
  options: {
    allowUnknown: true
  }
}

const editNewSlider = {
  payload: {
    sliderId: joi.number().integer().required(),
    title: joi.string().required(),
    subTitle: joi.string().allow(null),
    imgUrl: joi.string().required(),
    info: joi.object().allow(null)
  },
  options: {
    allowUnknown: true
  }
}

const getSliders = {
  query: {
    sliderId: joi.number().integer().required()
  },
  options: {
    allowUnknown: true
  }
}

const getSlidersWeb = {
  query: {
    sliderId: joi.number().integer().required()
  },
  options: {
    allowUnknown: true
  }
}

module.exports = {
  addNewSlider,
  editNewSlider,
  getSliders,
  getSlidersWeb
}
