'use strict'

const joi = require('joi')

const addproductType = {
  payload: {
    name: joi.string().required(),
    info: joi.object().allow(null)
  },
  options: {
    allowUnknown: true
  }
}

const editproductType = {
  payload: {
    productTypeId: joi.number().integer().required(),
    name: joi.string().required(),
    info: joi.object().allow(null)
  },
  options: {
    allowUnknown: true
  }
}

const getproductTypes = {
  query: {
    productId: joi.number().integer().required()
  },
  options: {
    allowUnknown: true
  }
}
const getproductTypesWeb = {
  query: {
    productId: joi.number().integer().required()
  },
  options: {
    allowUnknown: true
  }
}

module.exports = {
  addproductType,
  editproductType,
  getproductTypes,
  getproductTypesWeb
}
