'use strict'

const boom = require('boom')

const logger = require('../../utils/logger')

const addproductType = async function (req, res) {
  try {
    let db = req.getDb()
    let productType = db.getModel('ProductType')
    let result = await productType.create(req.payload)
    return result
  } catch (error) {
    const errorMessage = `Failed to add Product Item`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const editproductType = async function (req) {
  try {
    let db = req.getDb()
    let {productTypeId: id} = req.payload
    let productType = db.getModel('ProductType')
    let desiredproductType = await productType.findById(id)
    if (desiredproductType) {
      return desiredproductType.updateAttributes(req.payload)
    } else return boom.badRequest('Editing productType Failed')
  } catch (error) {
    const errorMessage = `Failed to edit productType`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getproductTypes = async (req) => {
  try {
    let db = req.getDb()
    let productTypes = db.getModel('ProductType')
    let {productId} = req.query
    if (productId === 0) {
      // If productId is 0 backend assumes that client wants all product
      return await productTypes.findAll()
    } else {
      return await productTypes.findById(productId)
    }
  } catch (error) {
    const errorMessage = `Failed to get productTypes`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

const getproductTypesWeb = async (req) => {
  try {
    let db = req.getDb()
    let productTypes = db.getModel('ProductType')
    let {productId} = req.query
    if (productId === 0) {
      // If productId is 0 backend assumes that client wants all product
      let allProductTypes = await productTypes.findAll({raw: true})
      return allProductTypes.filter(apt => apt.info.show === 'Yes')
    } else {
      let singleProductType = await productTypes.findById(productId)
      if (singleProductType.info.show === 'No') return {}
      else return singleProductType
    }
  } catch (error) {
    const errorMessage = `Failed to get productTypes`
    !error.logged && logger.error(error, errorMessage)
    return boom.boomify(error, { statusCode: 400 })
  }
}

module.exports = {
  addproductType,
  editproductType,
  getproductTypes,
  getproductTypesWeb
}
