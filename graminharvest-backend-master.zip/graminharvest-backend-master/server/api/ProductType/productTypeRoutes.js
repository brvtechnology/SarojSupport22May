'use strict'

const config = require('config')

const productTypeHandler = require('./productTypeHandler')
const productTypeValidations = require('./productTypeValidations')

const API = '/' + config.get('app.name') + '/api/1.0/productType'

const routes = []

routes.push({
  path: API + '/addproductType',
  method: 'POST',
  handler: productTypeHandler.addproductType,
  options: {
    auth: false,
    tags: ['api'],
    validate: productTypeValidations.addproductType
  }
})

routes.push({
  path: API + '/editproductType',
  method: 'POST',
  handler: productTypeHandler.editproductType,
  options: {
    auth: false,
    tags: ['api'],
    validate: productTypeValidations.editproductType
  }
})

routes.push({
  path: API + '/getproductTypes',
  method: 'GET',
  handler: productTypeHandler.getproductTypes,
  options: {
    auth: false,
    tags: ['api'],
    validate: productTypeValidations.getproductTypes
  }
})

routes.push({
  path: API + '/getproductTypesWeb',
  method: 'GET',
  handler: productTypeHandler.getproductTypesWeb,
  options: {
    auth: false,
    tags: ['api'],
    validate: productTypeValidations.getproductTypesWeb
  }
})

module.exports = routes
