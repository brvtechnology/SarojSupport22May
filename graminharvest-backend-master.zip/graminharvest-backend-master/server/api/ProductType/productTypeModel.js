'use strict'

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('ProductType', {
    name: {
      type: DataTypes.STRING,
      field: 'name',
      allowNull: false
    },
    info: {
      type: DataTypes.JSONB,
      field: 'info',
      allowNull: true
    }
  })
}
