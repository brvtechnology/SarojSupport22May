'use strict'

// require new relic at the top only in production environment
if (process.env.NODE_ENV === 'production') {
  require('newrelic')
}

const Hapi = require('hapi')
const Boom = require('boom')
const Basic = require('hapi-auth-basic')
const config = require('config')
const plugins = require('./plugins')

const routes = require('./routes')
const logger = require('./server/utils/logger')
const auth = require('./server/utils/auth')

const server = Hapi.server({
  host: config.get('app.host'),
  port: config.get('app.port'),
  routes: {
    cors: true,
    validate: {
      failAction: async (request, h, err) => {
        if (process.env.NODE_ENV === 'production') {
          logger.error('ValidationError:', err.message)
          throw Boom.badRequest(`Invalid request payload input`)
        } else {
          logger.error(err)
          throw err
        }
      }
    }
  }
})

server.ext('onPreResponse', (request, h) => {
  const response = request.response
  if (!response.isBoom) {
    return h.continue
  }

  const is4xx = response.output.statusCode >= 400 && response.output.statusCode < 500
  if (is4xx && response.data) {
    response.output.payload.data = response.data
  }
  return h.continue
})

const gracefulStopServer = function () {
  // Wait 10 secs for existing connection to close and then exit.
  server.stop({timeout: 10 * 1000}, () => {
    logger.info('Shutting down server')
    process.exit(0)
  })
}

process.on('uncaughtException', err => {
  logger.error(err, 'Uncaught exception')
  process.exit(1)
})

process.on('unhandledRejection', (reason, promise) => {
  logger.error({
    promise: promise,
    reason: reason
  }, 'unhandledRejection')
  process.exit(1)
})

process.on('SIGINT', gracefulStopServer)
process.on('SIGTERM', gracefulStopServer)

// start server when all plugins are loaded and routes configured
const start = async () => {
  try {
    // basic auth
    await server.register(Basic)
    server.auth.strategy('basic', 'basic', { validate: auth.validateBasicAuth })
    // register plugins
    await server.register(plugins)
    // add auth strategy
    server.auth.strategy('jwt-app', 'jwt',
      { key: config.get('authSecrets.app'),
        validate: auth.validateAppJWT,
        verifyOptions: { algorithms: [ 'HS256' ] }
      })
    // attach routes
    server.route(routes)
    await server.start()
    console.log(`server running at ${server.info.uri}`)
  } catch (error) {
    logger.error(error)
    process.exit(1)
  }
}

start()
