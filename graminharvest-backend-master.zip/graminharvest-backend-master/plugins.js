'use strict'

/**
 * Vendor modules
 */
const Inert = require('inert')
const Vision = require('vision')
const HapiSwagger = require('hapi-swagger')
const Good = require('good')
const HapiJWT = require('hapi-auth-jwt2')
const config = require('config')
const HapiSequelize = require('hapi-sequelizejs')
const Sequelize = require('sequelize')

/**
 * Internal modules
 */
const Package = require('./package.json')

const DEVELOPMENT = 'development'
const evn = config.util.getEnv('NODE_ENV')
const isDev = DEVELOPMENT === evn

// db config
const dbName = config.get('db.name')

const dbUser = isDev ? config.get('db.dev.user') : process.evn.DB_USER
const dbPassword = isDev ? config.get('db.dev.password') : process.evn.DB_PASSWORD
const dbHost = isDev ? config.get('db.dev.host') : process.evn.HOST

// sequlizer config
const sequelize = new Sequelize(dbName, dbUser, dbPassword, {
  host: dbHost,
  dialect: 'postgres',
  operatorsAliases: false,

  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  }
})

/**
 * exports array of plugins with configuration.
 * @type {Array}
 */
let plugins = []

plugins.push(HapiJWT)

if (isDev) {
  // add hapi swagger integration
  plugins = plugins.concat([Inert,
    Vision,
    {
      plugin: HapiSwagger,
      payloadType: 'form',
      options: {
        info: {
          'title': Package.description,
          'version': Package.version,
          'contact': {
            'email': 'skyborntech@gmail.com'
          }
        },
        pathPrefixSize: 4,
        documentationPath: '/doc',
        expanded: 'none',
        jsonEditor: true,
        sortEndpoints: 'method',
        auth: 'basic'
      }
    }])

  // add good console for log reporting
  plugins.push({
    plugin: Good,
    options: {
      reporters: {
        console: [{
          module: 'good-console'
        }, 'stdout']
      }
    }
  })
}

plugins.push({
  plugin: HapiSequelize,
  options: [
    {
      name: 'graminharvest', // db name
      models: ['./server/**/*Model.js'], // name all model with suffix as Model.js like questionModel.js
      sequelize: sequelize, // sequelize instance
      sync: true // sync models - default false
    }
  ]
})

module.exports = plugins
