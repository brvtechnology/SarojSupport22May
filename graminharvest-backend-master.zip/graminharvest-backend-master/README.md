# Install dependencies
$ yarn

# Start Server
$ yarn start