import Vue from 'vue'
import Router from 'vue-router'
import ProductType from '@/components/ProductType'
import Products from '@/components/Products'
import Upload from '@/components/Upload'
import Gallery from '@/components/Gallery'
import Blogs from '@/components/Blogs'
import Blog from '@/components/Blog'
import BlogEdit from '@/components/BlogEdit'
import Login from '@/components/Login'
import Home from '@/components/Home'
import Coupons from '@/components/Coupons'
import Order from '@/components/Order'
import Users from '@/components/Users'
import * as Cookies from 'js-cookie'

Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/producttypes',
      name: 'ProductType',
      component: ProductType
    },
    {
      path: '/products',
      name: 'Products',
      component: Products
    },
    {
      path: '/upload',
      name: 'Upload',
      component: Upload
    },
    {
      path: '/gallery',
      name: 'Gallery',
      component: Gallery
    },
    {
      path: '/blogs',
      name: 'Blogs',
      component: Blogs
    },
    {
      path: '/blog',
      name: 'Blog',
      component: Blog
    },
    {
      path: '/blog/:blogId',
      name: 'BlogEdit',
      component: BlogEdit,
      props: true
    },
    {
      path: '/login',
      name: 'login',
      component: Login,
      meta: {
        hideNavbar: true,
        hideToolbar: true,
        hideFooter: true
      }
    },
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    {
      path: '/coupons',
      name: 'coupons',
      component: Coupons
    },
    {
      path: '/orderhistory',
      name: 'Order',
      component: Order
    },
    {
      path: '/users',
      name: 'Users',
      component: Users
    }
  ],
  mode: 'history'
}
)

router.beforeEach((to, from, next) => {
  const auth = Cookies.get('token')
  const user = Cookies.get('user')

  if (!(auth) && to.path !== '/login') {
    // redirect to login if not logged in
    next({path: '/login'})
  } else if ((auth || user) && to.path === '/login') {
    next({path: '/'})
  } else {
    next()
  }
})

export default router
