import axios from 'axios'
import * as Cookies from 'js-cookie'
// import config from '../../config'
// default base url
// const defaultBaseUrl = 'http://' + config.dev.api_host + ':' + (process.env.PORT || config.dev.api_port)
const defaultBaseUrl = 'http://localhost:8181'
// const defaultBaseUrl = 'http://ec2-13-127-209-248.ap-south-1.compute.amazonaws.com:8181'

/**
 * Create a new Axios client instance
 */
const getClient = (baseUrl = defaultBaseUrl) => {
  const options = {
    baseURL: baseUrl
  }
  let auth = Cookies.get('token')
  let user = Cookies.get('user')
  if (auth && user) {
    options.headers = {
      Authorization: auth
    }
  }

  const client = axios.create(options)

  // Add a request interceptor
  client.interceptors.request.use(
    config => {
      return config
    },
    error => Promise.reject(error)
  )

  // Add a response interceptor
  client.interceptors.response.use(
    response => {
      return response
    },
    error => {
      return Promise.reject(error)
    }
  )

  return client
}

/**
 * Default api client
 * we can extend this client and add new method
 */
class ApiClient {
  constructor (baseUrl = null) {
    this.client = getClient(baseUrl)
  }

  get (url, conf = {}) {
    return this.client.get(url, conf)
      .then(response => Promise.resolve(response))
      .catch(error => Promise.reject(error))
  }

  delete (url, conf = {}) {
    return this.client.delete(url, conf)
      .then(response => Promise.resolve(response))
      .catch(error => Promise.reject(error))
  }

  head (url, conf = {}) {
    return this.client.head(url, conf)
      .then(response => Promise.resolve(response))
      .catch(error => Promise.reject(error))
  }

  options (url, conf = {}) {
    return this.client.options(url, conf)
      .then(response => Promise.resolve(response))
      .catch(error => Promise.reject(error))
  }

  post (url, data = {}, conf = {}) {
    return this.client.post(url, data, conf)
      .then(response => Promise.resolve(response))
      .catch(error => Promise.reject(error))
  }

  put (url, data = {}, conf = {}) {
    return this.client.put(url, data, conf)
      .then(response => Promise.resolve(response))
      .catch(error => Promise.reject(error))
  }

  patch (url, data = {}, conf = {}) {
    return this.client.patch(url, data, conf)
      .then(response => Promise.resolve(response))
      .catch(error => Promise.reject(error))
  }
}

export { ApiClient }

/**
 * Base HTTP Client
 */
export default {
  get (url, conf = {}) {
    return getClient().get(url, conf)
      .then(response => Promise.resolve(response))
      .catch(error => Promise.reject(error))
  },

  delete (url, conf = {}) {
    return getClient().delete(url, conf)
      .then(response => Promise.resolve(response))
      .catch(error => Promise.reject(error))
  },

  head (url, conf = {}) {
    return getClient().head(url, conf)
      .then(response => Promise.resolve(response))
      .catch(error => Promise.reject(error))
  },

  options (url, conf = {}) {
    return getClient().options(url, conf)
      .then(response => Promise.resolve(response))
      .catch(error => Promise.reject(error))
  },

  post (url, data = {}, conf = {}) {
    return getClient().post(url, data, conf)
      .then(response => Promise.resolve(response))
      .catch(error => Promise.reject(error))
  },

  put (url, data = {}, conf = {}) {
    return getClient().put(url, data, conf)
      .then(response => Promise.resolve(response))
      .catch(error => Promise.reject(error))
  },

  patch (url, data = {}, conf = {}) {
    return getClient().patch(url, data, conf)
      .then(response => Promise.resolve(response))
      .catch(error => Promise.reject(error))
  }
}
