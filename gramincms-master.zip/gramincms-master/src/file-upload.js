import api from './api'

export { upload }
function upload (formData) {
  return api.post('/graminharvest/api/1.0/aws/s3/uploadFile', formData)
    // get data
    .then(x => {
      return x.data
    // add0 url field
    })
    .catch(error => {
      throw (error)
    })
}
