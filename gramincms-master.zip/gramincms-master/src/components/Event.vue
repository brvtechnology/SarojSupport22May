<template>
  <div>
    <error v-if='this.requestError' :requestError ="requestError"></error>
    <v-toolbar flat color="white">
      <v-toolbar-title>Create New Event</v-toolbar-title>
      <v-divider
        class="mx-2"
        inset
        vertical
      ></v-divider>
      <v-spacer></v-spacer>
      <v-dialog v-model="dialog" max-width="500px">
        <v-btn slot="activator" color="primary" dark class="mb-2">New Item</v-btn>
         <v-form ref="form" v-model="valid" lazy-validation>
          <v-card>
          <v-card-title ref="form" v-model="valid" lazy-validation>
            <span class="headline">{{ formTitle }}</span>
          </v-card-title>
        
          <v-card-text >
            <v-container grid-list-md>
              <v-layout wrap >
                <v-flex xs12 >
                    <v-text-field
                      v-model="editedItem.eventName"
                      color="deep-purple"
                      label="Event Name"
                      style="min-height: 96px"
                      :rules="nameRules"
                    ></v-text-field>
                </v-flex>
                 <v-flex xs12>
                  <label>Event Description</label>
                  <v-textarea
                    solo
                    name="input-7-4"
                    color="deep-purple"
                    v-model="editedItem.eventDescription" label="Event Description"
                     :rules="descRules"
                  ></v-textarea>
                </v-flex>
                <v-flex xs12>
                  <label>Event Address</label>
                  <v-textarea
                    solo
                    name="input-7-4"
                    color="deep-purple"
                    v-model="editedItem.eventAddress" label="Event Address"
                    :rules="descRules"
                  ></v-textarea>
                </v-flex>
                <v-flex xs12>
                  <v-menu
                    ref="menu"
                    :close-on-content-click="false"
                    v-model="menu"
                    :nudge-right="40"
                    :return-value.sync="picker"
                    lazy
                    transition="scale-transition"
                    offset-y
                    full-width
                    min-width="290px"
                  >
                  <v-text-field
                      slot="activator"
                      v-model="picker"
                      label="Choose Date"
                      prepend-icon="event"
                      readonly
                    ></v-text-field>
                    <v-date-picker v-model="picker" no-title scrollable>
                      <v-spacer></v-spacer>
                      <v-btn flat color="primary" @click="menu = false">Cancel</v-btn>
                      <v-btn flat color="primary" @click="$refs.menu.save(picker)">OK</v-btn>
                    </v-date-picker>
                  </v-menu>
                </v-flex>
                <v-flex xs12>
                  <v-dialog
                    ref="dialog"
                    v-model="modal"
                    :return-value.sync="time"
                    persistent
                    lazy
                    full-width
                    width="290px"
                  >
                    <v-text-field
                      slot="activator"
                      v-model="time"
                      label="Choose Time"
                      prepend-icon="access_time"
                      readonly
                    ></v-text-field>
                    <v-time-picker
                      v-if="modal"
                      v-model="time"
                      full-width
                    >
                      <v-spacer></v-spacer>
                      <v-btn flat color="primary" @click="modal = false">Cancel</v-btn>
                      <v-btn flat color="primary" @click="$refs.dialog.save(time)">OK</v-btn>
                    </v-time-picker>
                  </v-dialog>
              </v-flex>
                <v-flex xs12 >
                    <v-text-field
                      v-model.number="editedItem.eventDuration"
                      color="deep-purple"
                      hint= "In Hours"
                      label="Event Duration"
                      style="min-height: 96px"
                      :rules="numbersRules"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12 >
                    <v-text-field
                      v-model="editedItem.paymentLink"
                      color="deep-purple"
                      hint= "Instamojo Link"
                      label="Payment Link"
                      style="min-height: 96px"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12 >
                    <v-text-field
                      v-model.number="editedItem.fee"
                      color="deep-purple"
                      label="Event fee"
                      style="min-height: 96px"
                      :rules="numbersRules"
                    ></v-text-field>
                </v-flex>
                <v-flex>
                  <v-select
                  :items="items"
                  label="Show"
                  v-model="editedItem.show"
                  :rules="productTypeShowRules"
                  ></v-select>
                </v-flex> 
              </v-layout>
            </v-container>
          </v-card-text>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn color="blue darken-1" flat @click.native="close">Cancel</v-btn>
            <v-btn color="blue darken-1" flat :disabled="!valid" @click.native="save">Save</v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
      </v-dialog>
    </v-toolbar>
    <v-data-table
      :headers="headers"
      :items="events"
      hide-actions
      class="elevation-1"
    >
      <template slot="items" slot-scope="props">
        <td>{{ props.item.eventName }}</td>
        <td class="text-xs-left">{{ props.item.id }}</td>
        <td class="text-xs-left">{{ props.item.eventAddress }}</td>
        <td class="text-xs-left">{{ props.item.eventDate }}</td>
        <td class="text-xs-center">{{ props.item.info.show }}</td>
        <td class="justify-center layout px-0">
          <v-icon
            small
            class="mr-2"
            @click="editItem(props.item)"
          >
            edit
          </v-icon>
        </td>
      </template>
    </v-data-table>
  </div>
</template>

<script>
  // import axios from 'axios'
  import api from '../api'
  import error from './Error.vue'
  export default {
    components: {
      error
    },
    data: () => ({
      dialog: false,
      requestError: false,
      menu: false,
      valid: true,
      picker: new Date().toISOString().substr(0, 10),
      reactive: false,
      modal: false,
      time: null,
      headers: [
        {
          text: 'Event Name',
          align: 'left',
          sortable: false,
          value: 'name'
        },
        { text: 'Event Id', value: 'id' },
        { text: 'Event Address', value: 'desc' },
        { text: 'Event Date', value: 'desc' },
        { text: 'Show in Website', value: 'show' },
        { text: 'Actions', value: 'name', sortable: false }
      ],
      events: [],
      nameRules: [
        v => !!v || 'This field is required',
        v => (v && v.length <= 20) || 'This field can not be more than 20 characters'
      ],
      descRules: [
        v => !!v || 'This field is required',
        v => (v && v.length <= 100) || 'This field can not be more than 100 characters'
      ],
      productTypeShowRules: [
        v => !!v || 'Atleast choose one choice'
      ],
      numbersRules: [
        v => !!v || 'This field is a required field',
        v => (v && typeof (v) === 'number') || 'This field accepts a number'
      ],
  
      editedIndex: -1,
      editedItem: {
        eventName: '',
        eventDescription: '',
        eventAddress: '',
        eventDuration: null,
        paymentLink: '',
        fee: null,
        id: null,
        show: ''
      },
      items: ['Yes', 'No']
    }),
  
    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'New Item' : 'Edit Item'
      }
    },

    watch: {
      dialog (val) {
        val || this.close()
      }
    },

    created () {
      this.getEvents()
    },

    methods: {
      getEvents () {
        // get all the product types by asking product id = 0
        api.get(`/graminharvest/api/1.0/event/getEvents?eventId=0`)
          .then(events => {
            this.events = events.data
            console.log(this.events)
          }).catch(error => {
            console.log(error)
            this.requestError = error
          })
      },

      editItem (item) {
        console.log(item)
        console.log(this.picker)
        this.editedIndex = item.id
        this.editedItem = {...item}
        this.editedItem.show = item.info.show
        this.picker = item.eventDate
        this.time = item.eventTime
        this.dialog = true
      },
      close () {
        this.dialog = false
        setTimeout(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        }, 300)
      },

      save () {
        if (this.$refs.form.validate()) {
          if (this.editedIndex > -1) {
            let payload = this.editedItem
            payload.info = Object.assign({}, {show: payload.show})
            delete payload.show
            payload.eventId = this.editedIndex
            payload.eventDate = this.picker
            console.log(this.time, 'time')
            payload.eventTime = this.time
            console.log(payload)
            api.post(`/graminharvest/api/1.0/event/editEvent`, payload)
              .then(() => {
                console.log('Success')
                this.$router.go(0)
              })
          } else {
            console.log(this.editedItem)
            let payload = this.editedItem
            payload.info = Object.assign({}, {show: payload.show})
            delete payload.show
            delete payload.id
            payload.eventDate = this.picker
            payload.eventTime = this.time
            console.log(payload)
            api.post(`/graminharvest/api/1.0/event/addEvent`, payload)
              .then(() => {
                console.log('Success')
                this.$router.go(0)
              })
          }
          this.close()
        }
      }
    }
  }
  </script>