<template>
    <div>
      <error v-if='this.requestError' :requestError ="requestError"></error>
        <v-toolbar flat color="white">
            <v-toolbar-title>Blogs</v-toolbar-title>
            
            <v-divider
            class="mx-2"
            inset
            vertical
            ></v-divider>
           
            <v-spacer></v-spacer>
            <v-btn color="primary" dark class="mb-2" @click ="pushToNewBlog">New Item</v-btn>
        </v-toolbar>
         <v-tabs fixed-tabs>
                  <v-tab
                    v-for="n in tabName"
                    :key="n.id"
                    grow
                    @click="n.id === 1 ? published = 'Yes' : published = 'No'"
                >
                    {{ n.name }}
                </v-tab>
                </v-tabs>
                <v-divider></v-divider>
                <v-divider></v-divider>
          <v-layout>
            <v-flex v-if="this.blogs">
                <v-card v-for="blog in filteredBlog" :key="blog.id">
                    <v-card-title class="cursor--link" primary-title @click="goToExistingBlog(blog.id)">
                        <div>
                        <h3 class="headline mb-0">{{blog.name}}</h3>
                        <div>{{blog.description}}</div>
                        </div>
                    </v-card-title>
                    <v-card-actions>
                      <v-spacer></v-spacer>
                      <v-btn color="primary"  @click.native="saveBlogAsDraft" @click="changeBlogStatus(blog.id)">{{published === 'Yes' ? 'Unpublish' : 'Publish'}}</v-btn>
                    </v-card-actions>
                </v-card>
            </v-flex>
          </v-layout>
           <v-spacer></v-spacer>
          <v-divider></v-divider>
    </div>
</template>
<script>
import api from '../api'
import error from './Error.vue'
export default {
  components: {
    error
  },
  data: () => ({
    blogs: [],
    requestError: false,
    tabName: [
      {
        id: 1,
        name: 'Published'
      },
      {
        id: 2,
        name: 'Draft'

      }
    ],
    published: 'Yes'

  }),
  created () {
    this.getAllBlogs()
  },
  computed: {
    filteredBlog () {
      return this.blogs.filter(b => {
        return b.info.show === this.published
      })
    }
  },
  methods: {
    getAllBlogs () {
      api.get(`/graminharvest/api/1.0/blog/getAllBlogs?blogId=0`)
        .then((blogs) => {
          this.blogs = blogs.data
        })
    },
    pushToNewBlog () {
      this.$router.push('/blog')
    },
    goToExistingBlog (blogId) {
      console.log('herer')
      this.$router.push({path: `/blog/${blogId}`, params: {blogId}})
    },
    changeBlogStatus (blogId) {
      let newStatus
      if (this.published === 'Yes') newStatus = 'No'
      else newStatus = 'Yes'
      api.post(`/graminharvest/api/1.0/blog/changeBlogStatus`, Object.assign({}, {blogId}, {newStatus}))
        .then(() => {
          this.$router.go(0)
        }).catch(error => {
          console.log(error)
          this.requestError = error
        })
    }
  }
}
</script>

