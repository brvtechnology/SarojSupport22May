<template>
<div>
     <v-flex xs12>
            <v-card color="red darken-2" class="white--text">
              <v-card-title primary-title>
                <div class="headline">OOPS!!! Error Occured</div>
              </v-card-title>
              <div>Message : {{this.requestError.config.data || 'Something Wrong Happened'}}</div>
            </v-card>
          </v-flex>
  </div>  
</template>
<script>
export default {
  props: ['requestError']
}
</script>
