<template>
  <div>
    <error v-if='this.requestError' :requestError ="requestError"></error>
    <v-toolbar flat color="white">
      <v-toolbar-title>Coupons</v-toolbar-title>
      <v-divider
        class="mx-2"
        inset
        vertical
      ></v-divider>
      <v-spacer></v-spacer>
      <v-dialog v-model="dialog" max-width="500px">
        <v-btn slot="activator" color="primary" dark class="mb-2">New Item</v-btn>
         <v-form ref="form" v-model="valid" lazy-validation>
          <v-card>
          <v-card-title ref="form" v-model="valid" lazy-validation>
            <span class="headline">{{ formTitle }}</span>
          </v-card-title>
        
          <v-card-text >
            <v-container grid-list-md>
              <v-layout wrap >
                <v-flex xs12>
                    <v-text-field
                      v-model="editedItem.coupon_code"
                      color="deep-purple"
                      label="Coupon Code"
                      style="min-height: 96px"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                  <label>Description(Will be auto created if empty)</label>
                  <v-textarea
                    solo
                    name="input-7-4"
                    color="deep-purple"
                    v-model="editedItem.description" label="Description"
                  ></v-textarea>
                </v-flex>
                 <v-flex xs12>
                   <v-date-picker v-model="picker" no-title scrollable>
                      <v-spacer></v-spacer>
                    </v-date-picker>
                </v-flex>
                <v-flex xs12>
                    <v-text-field
                      v-model.number="editedItem.allowedPerUser"
                      color="deep-purple"
                      label="Allowed Per User"
                      style="min-height: 96px"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                    <v-text-field
                      v-model.number="editedItem.max_cashback"
                      color="deep-purple"
                      label="Max Cashback"
                      style="min-height: 96px"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                    <v-text-field
                      v-model="editedItem.minimum_amount_to_apply"
                      color="deep-purple"
                      label="Min. Amount to Apply"
                      style="min-height: 96px"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                    <v-text-field
                      v-model.number="editedItem.coupon_amount"
                      color="deep-purple"
                      label="Coupon AMount"
                      style="min-height: 96px"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                    <v-select
                  :items="type"
                  label="Discount Type"
                  v-model="editedItem.type"
                  ></v-select>
                </v-flex> 
              </v-layout>
            </v-container>
          </v-card-text>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn color="blue darken-1" flat @click.native="close">Cancel</v-btn>
            <v-btn color="blue darken-1" flat :disabled="!valid" @click.native="save">Save</v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
      </v-dialog>
    </v-toolbar>
    <v-data-table
      :headers="headers"
      :items="coupons"
      hide-actions
      class="elevation-1"
    >
      <template slot="items" slot-scope="props">
        <td>{{ props.item.coupon_code }}</td>
        <td class="text-xs-left">{{ props.item.type }}</td>
        <td class="text-xs-left">{{ props.item.description }}</td>
        <td class="text-xs-center">{{ props.item.expiry_date | formatDate}}</td>
        <td class="text-xs-center">{{ props.item.allowedPerUser }}</td>
        <td class="text-xs-center">{{ props.item.minimum_amount_to_apply}}</td>
        <td class="text-xs-center">{{ props.item.coupon_amount }}</td>
        <td class="text-xs-center">{{ props.item.max_cashback }}</td>
        <td class="justify-center layout px-0">
          <v-btn
            color="blue darken-1" flat
            @click.native="expireCoupon(props.item.coupon_code)"
          >
            Expire</v-btn>
          
        </td>
      </template>
    </v-data-table>
  </div>
</template>

<script>
  import api from '../api'
  import error from './Error.vue'
import moment from 'moment'
  export default {
    components: {
      error
    },
    data: () => ({
      dialog: false,
      requestError: false,
      picker: new Date().toISOString().substr(0, 10),
      valid: true,
      hint: null,
      headers: [
        {
          text: 'Coupon Code',
          align: 'left',
          sortable: false,
          value: 'coupon_code'
        },
        { text: 'Type', value: 'type' },
        { text: 'Description', value: 'description' },
        { text: 'Expiry Date', value: 'expiry_date' },
        { text: 'Allowed Per User', value: 'allowedPerUser' },
        { text: 'Min. Amt', value: 'minimum_amount_to_apply' },
        { text: 'Coupon Amt', value: 'coupon_amount' },
        { text: 'Max Cashback', value: 'max_cashback' },
        { text: 'Actions', value: 'name', sortable: false }
      ],
      coupons: [],
  
      editedIndex: -1,
      editedItem: {
        coupon_code: null,
        description: null,
        expiry_date: null,
        allowedPerUser: null,
        minimum_amount_to_apply: null,
        coupon_amount: null,
        max_cashback: null,
        type: null
      },
      defaultItem: {
        coupon_code: null,
        description: null,
        expiry_date: null,
        allowedPerUser: null,
        minimum_amount_to_apply: null,
        coupon_amount: null,
        max_cashback: null
      },
      type: ['percentage', 'rs']
    }),
  
    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'New Item' : 'Edit Item'
      }
    },
    filters: {
      formatDate (date) {
        return moment(date).format('MM/DD/YYYY')
      }
    },
    watch: {
      dialog (val) {
        val || this.close()
      }
    },

    created () {
      this.getCoupons()
    },

    methods: {
      expireCoupon (item) {
        api.post(`/graminharvest/api/1.0/coupon/expireCoupon`, {coupon_code: item})
          .then(() => this.$router.go(0))
      },
      getCoupons () {
        // get all the Coupons by asking product id = 0
        api.get(`/graminharvest/api/1.0/coupon/getCoupons`)
          .then((coupons) => {
            this.coupons = coupons.data
          }).catch(error => {
            console.log(error)
            this.requestError = error
          })
      },

      editItem (item) {
        console.log(item)
        console.log(this.editedItem)
        /*
        coupon_code: null,
        description: null,
        expiry_date: null,
        allowedPerUser: null,
        minimum_amount_to_apply: null,
        coupon_amount: null,
        max_cashback: null,
        type: null
  
        */
        this.editedIndex = item.id
        this.editedItem.coupon_code = item.coupon_code
        this.editedItem.description = item.description
        this.picker = moment(item.expiry_date).format('YYYY-MM-DD')
        this.editedItem.allowedPerUser = item.allowedPerUser
        this.editedItem.minimum_amount_to_apply = item.minimum_amount_to_apply
        this.editedItem.coupon_amount = item.coupon_amount
        this.editedItem.max_cashback = item.max_cashback
        this.editedItem.type = item.type
        this.dialog = true
      },
      close () {
        this.dialog = false
        setTimeout(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        }, 300)
      },

      save () {
        let payload = {
          coupon_code: this.editedItem.coupon_code,
          description: this.editedItem.description ? this.editedItem.description : `Use code ${this.editedItem.coupon_code} to get upto ${this.editedItem.coupon_amount} ${this.editedItem.type.toLowerCse() === 'rs' ? 'Rs off' : '% off'}`,
          expiry_date: moment(this.picker),
          allowedPerUser: this.editedItem.allowedPerUser,
          type: this.editedItem.type,
          minimum_amount_to_apply: this.editedItem.minimum_amount_to_apply,
          coupon_amount: this.editedItem.coupon_amount,
          max_cashback: this.editedItem.max_cashback
        }
  
        api.post(`/graminharvest/api/1.0/coupon/addCoupon`, payload)
          .then(() => {
            console.log('Success')
            this.$router.go(0)
          }).catch(error => {
            console.log(error)
            this.requestError = error
          })
        this.close()
      }
    }

  }
</script> 