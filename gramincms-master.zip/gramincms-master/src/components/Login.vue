<template>
<v-container fluid fill-height class="loginOverlay">
<v-layout flex align-center justify-center>
  <v-flex xs12 sm4 elevation-6>
    <v-toolbar class="pt-5 blue darken-4">
                <v-toolbar-title class="white--text"><h4>Gramin CMS</h4></v-toolbar-title>
    </v-toolbar>
    <v-card>
      <v-card-text class="pt-4">
        <div>
            <v-form v-model="valid" ref="form">
              <v-text-field
                label="Enter your e-mail address"
                v-model="email"
                :rules="emailRules"
                :error-messages="errorHelpText.email"
                required
              ></v-text-field>
              <v-text-field
                label="Enter your password"
                v-model="password"
                min="8"
                :append-icon="e1 ? 'visibility' : 'visibility_off'"
                :append-icon-cb="() => (e1 = !e1)"
                :type="e1 ? 'password' : 'text'"
                :rules="passwordRules"
                :error-messages="errorHelpText.password"
                counter
                required
              ></v-text-field>
              <v-layout justify-space-between>
                  <v-btn @click="submit" :class=" { 'blue darken-4 white--text' : valid, disabled: !valid }">Login</v-btn>
              </v-layout>
            </v-form>
        </div>
      </v-card-text>
    </v-card>
  </v-flex>
</v-layout>
</v-container>
</template>

<script>
// import axios from 'axios'
import * as Cookies from 'js-cookie'
import api from '../api'

export default {
  data () {
    return {
      valid: false,
      errorHelpText: {
        email: null,
        password: null
      },
      e1: true,
      password: '',
      passwordRules: [
        (v) => !!v || 'Password is required'
      ],
      email: '',
      emailRules: [
        (v) => !!v || 'E-mail is required',
        (v) => /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(v) || 'E-mail must be valid'
      ]
    }
  },
  methods: {
    submit () {
      if (this.$refs.form.validate()) {
        this.login()
        // this.$refs.form.$el.submit()
      } else {
        this.valid = false
        this.$refs.form.reset()
      }
    },
    clear () {
      this.$refs.form.reset()
    },
    login () {
      let payload = {
        email: this.email,
        password: this.password
      }
      api.post(`/graminharvest/api/1.0/user/login`, payload)
        .then((data) => {
          // console.log('Login Success')
          console.log(data)
          Cookies.set('user', data.data.user)
          Cookies.set('token', data.data.token)
          this.$router.push('/')
        }).catch(r => {
          this.errorHelpText.email = null
          this.errorHelpText.password = null
          let response = r.response
          if (response.status === 400) {
            if (response.data.message.includes('Email')) {
              this.errorHelpText.email = response.data.message
            } else if (response.data.message.includes('password')) {
              this.errorHelpText.password = response.data.message
            } else {
              this.errorHelpText.other = response.data.message
            }
            this.valid = true
            this.$refs.form.reset()
          }
          // return Promise.reject(response)
        })
    }
  }
}
</script>

<style>

</style>
