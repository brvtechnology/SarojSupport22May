<template>
  <div>
    <error v-if='this.requestError' :requestError ="requestError"></error>
    <v-toolbar flat color="white">
      <v-toolbar-title>Home</v-toolbar-title>
      <v-divider
        class="mx-2"
        inset
        vertical
      ></v-divider>
      <v-spacer></v-spacer>
      <v-dialog v-model="dialog" max-width="500px">
        <v-btn slot="activator" color="primary" dark class="mb-2">New Item</v-btn>
         <v-form ref="form" v-model="valid" lazy-validation>
          <v-card>
          <v-card-title ref="form" v-model="valid" lazy-validation>
            <span class="headline">{{ formTitle }}</span>
          </v-card-title>
        
          <v-card-text >
            <v-container grid-list-md>
              <v-layout wrap >
                <v-flex xs12>
                    <v-text-field
                      v-model="editedItem.title"
                      color="deep-purple"
                      label="Slider Title"
                      style="min-height: 96px"
                      :rules="nameRules"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                    <v-text-field
                      v-model="editedItem.subTitle"
                      color="deep-purple"
                      label="Sub Title"
                      style="min-height: 96px"
                      :rules="nameRules"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                    <v-text-field
                      v-model="editedItem.imgUrl"
                      color="deep-purple"
                      label="Image Link"
                      style="min-height: 96px"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                  <v-select
                  :items="items"
                  label="Show"
                  v-model="editedItem.show"
                  :rules="productTypeShowRules"
                  ></v-select>
                </v-flex> 
              </v-layout>
            </v-container>
          </v-card-text>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn color="blue darken-1" flat @click.native="close">Cancel</v-btn>
            <v-btn color="blue darken-1" flat :disabled="!valid" @click.native="save">Save</v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
      </v-dialog>
    </v-toolbar>
    <v-data-table
      :headers="headers"
      :items="slide"
      hide-actions
      class="elevation-1"
    >
      <template slot="items" slot-scope="props">
        <td>{{ props.item.title }}</td>
        <td class="text-xs-left">{{ props.item.subTitle }}</td>
         <td><v-img
                  :src="`${props.item.imgUrl}`"
                  aspect-ratio="1"
                  class="grey lighten-2"
                ></v-img></td>
        <td class="text-xs-center">{{ props.item.info.show }}</td>
        <td class="justify-center layout px-0">
          <v-icon
            small
            class="mr-2"
            @click="editItem(props.item)"
          >
            edit
          </v-icon>
        </td>
      </template>
    </v-data-table>
  </div>
</template>

<script>
  // import axios from 'axios'
  import api from '../api'
  import error from './Error.vue'
  export default {
    components: {
      error
    },
    data: () => ({
      dialog: false,
      requestError: false,
      valid: true,
      headers: [
        {
          text: 'Title',
          align: 'left',
          sortable: false,
          value: 'title'
        },
        { text: 'SubTitle', value: 'subtitle' },
        { text: 'Image Link', value: 'img_link' },
        { text: 'Show in Website', value: 'show' },
        { text: 'Actions', value: 'name', sortable: false }
      ],
      slide: [],
      nameRules: [
        v => !!v || 'This field is required',
        v => (v && v.length <= 20) || 'Max 20 characters allowed'
      ],
      productTypeShowRules: [
        v => !!v || 'Atleast choose one choice'
      ],
  
      editedIndex: -1,
      editedItem: {
        title: '',
        subTitle: '',
        imgUrl: '',
        show: ''
      },
      items: ['Yes', 'No']
    }),
  
    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'New Item' : 'Edit Item'
      }
    },

    watch: {
      dialog (val) {
        val || this.close()
      }
    },

    created () {
      this.getImgForSlider()
    },

    methods: {
      getImgForSlider () {
        // get all the product types by asking product id = 0
        api.get(`/graminharvest/api/1.0/slider/getSliders?sliderId=0`)
          .then(slide => {
            this.slide = slide.data
          }).catch(error => {
            console.log(error)
            this.requestError = error
          })
      },

      editItem (item) {
        console.log(item)
        this.editedIndex = item.id
        this.editedItem.title = item.title
        this.editedItem.subTitle = item.subTitle
        this.editedItem.imgUrl = item.imgUrl
        this.editedItem.show = item.info.show
        this.dialog = true
      },
      close () {
        this.dialog = false
        setTimeout(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        }, 300)
      },

      save () {
        if (this.$refs.form.validate()) {
          if (this.editedIndex > -1) {
            console.log(this.editedItem)
            // prepare data for db
            let payload = {}
            payload.title = this.editedItem.title
            payload.subTitle = this.editedItem.subTitle
            payload.imgUrl = this.editedItem.imgUrl
            payload.info = this.editedItem
            payload.sliderId = this.editedIndex
  
            api.post(`/graminharvest/api/1.0/slider/editNewSlider`, payload)
              .then(() => {
                console.log('Success')
                this.$router.go(0)
              }).catch(error => {
                console.log(error)
                this.requestError = error
              })
          } else {
            console.log(this.editedItem)
  
            // prepare data for db
            let payload = {}
            payload.title = this.editedItem.title
            payload.subTitle = this.editedItem.subTitle
            payload.imgUrl = this.editedItem.imgUrl
            payload.info = Object.assign({}, {show: this.editedItem.show})
  
            api.post(`/graminharvest/api/1.0/slider/addNewSlider`, payload)
              .then(() => {
                console.log('Success')
                this.$router.go(0)
              }).catch(error => {
                console.log(error)
                this.requestError = error
              })
          }
          this.close()
        }
      }
    }
  }
</script>