<template>
  <div>
    <error v-if='this.requestError' :requestError ="requestError"></error>
    <v-data-table
      :headers="headers"
      :items="orders"
      hide-actions
      class="elevation-1"
    >
      <template slot="items" slot-scope="props">
        <td>{{ props.item.id }}</td>
        <td class="text-xs-left">{{ props.item.orderId }}</td>
        <td class="text-xs-left">{{ props.item.orderType }}</td>
        <td class="text-xs-left">{{ props.item.info.clientOrderId }}</td>
        <td class="text-xs-center">{{ props.item.amount}}</td>
        <td class="text-xs-center">{{ props.item.contact | formatJson }}</td>
        <td class="text-xs-center">{{ props.item.address | formatJson }}</td>
        <td class="text-xs-center">{{  props.item.productArr  }}</td>
        <td class="text-xs-center">{{(props.item.createdAt)}}</td>
        <td class="text-xs-center">{{  props.item.info.paymentStatus  }}</td>
        <td class="text-xs-center" v-if="props.item.info.paymentStatus === 'Initiated'"><v-btn color="info" @click="changeStatus(props.item.id,'Initiated')">Place Order</v-btn></td>
        <td class="text-xs-center" v-if="props.item.info.paymentStatus === 'Placed'"><v-btn color="info" @click="changeStatus(props.item.id,'Placed')">Ship Order</v-btn></td>
        <td class="text-xs-center" v-if="props.item.info.paymentStatus === 'Shipped'"><v-btn color="success" @click="changeStatus(props.item.id, 'Shipped')">Order Delivered</v-btn></td>
      </template>
    </v-data-table>
  </div>
</template>

<script>
  import api from '../api'
  import error from './Error.vue'
  import moment from 'moment'
  export default {
    components: {
      error
    },
    data: () => ({
      dialog: false,
      requestError: false,
      headers: [
        {
          text: 'Order Id',
          align: 'left',
          value: 'id'
        },
        { text: 'product/Event Id', value: 'orderId' },
        { text: 'Order Type', value: 'orderType' },
        { text: 'Client Order Id', value: 'ClientOrderId' },
        { text: 'Price', value: 'price' },
        { text: 'Contact Details', value: 'contact' },
        { text: 'Address', value: 'address' },
        {text: 'Products Bought', value: 'products'},
        {text: 'Order Date', value: 'orderDate'},
        {text: 'Payment  Status', value: 'paymentStatus'},
        {text: 'Action', value: 'changeStatus'}
      ],
      orders: []
    }),
  
    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'New Item' : 'Edit Item'
      }
    },
    created () {
      this.getOrders()
    },

    methods: {
      changeStatus (id, status) {
        api.post(`/graminharvest/api/1.0/order/changeDeliveryStatus`, {id, status})
          .then(() => {
            this.$router.go(0)
          })
      },
      getOrders () {
        api.get(`/graminharvest/api/1.0/order/getOrderHistory`)
          .then((orders) => {
            this.orders = orders.data
  
            this.orders.forEach(o => {
              o.createdAt = moment(o.createdAt).format('MM/DD/YYYY')
              o.productArr = []
              if (o.info.orderInfo.amount) o.amount = o.info.orderInfo.amount
              if (o.info.orderInfo.orders) {
                o.info.orderInfo.orders.forEach(eo => {
                  o.productArr.push({name: eo.name, quantity: eo.quantity})
                })
              }
            })
          }).catch(error => {
            console.log(error)
            this.requestError = error
          })
      }
    },
    filters: {
      formatJson (item) {
        console.log(item)
        if (item) {
          return Object.keys(item).map(i => item[i]).join(',')
        } else return 'N.A'
      }
    }
  }
</script> 