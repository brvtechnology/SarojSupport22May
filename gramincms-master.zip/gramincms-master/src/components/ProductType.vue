<template>
  <div>
    <error v-if='this.requestError' :requestError ="requestError"></error>
    <v-toolbar flat color="white">
      <v-toolbar-title>Product Types</v-toolbar-title>
      <v-divider
        class="mx-2"
        inset
        vertical
      ></v-divider>
      <v-spacer></v-spacer>
      <v-dialog v-model="dialog" max-width="500px">
        <v-btn slot="activator" color="primary" dark class="mb-2">New Item</v-btn>
         <v-form ref="form" v-model="valid" lazy-validation>
          <v-card>
          <v-card-title ref="form" v-model="valid" lazy-validation>
            <span class="headline">{{ formTitle }}</span>
          </v-card-title>

          <v-card-text >
            <v-container grid-list-md>
              <v-layout wrap >
                <v-flex xs12>
                    <v-text-field
                      v-model="editedItem.name"
                      color="deep-purple"
                      label="Product Type Name"
                      style="min-height: 96px"
                      :rules="productTypeNameRules"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                  <label>Description</label>
                  <v-textarea
                    solo
                    name="input-7-4"
                    color="deep-purple"
                    v-model="editedItem.desc" label="Description"
                    :rules="productTypeDescRules"
                  ></v-textarea>
                </v-flex>
                <v-flex xs12>
                  <v-text-field
                    v-model="editedItem.image"
                    color="deep-purple"
                    label="Product Image"
                    style="min-height: 96px"
                    :rules="required"
                  ></v-text-field>
                </v-flex>
                <v-flex>
                  <v-select
                  :items="items"
                  label="Show"
                  v-model="editedItem.show"
                  :rules="productTypeShowRules"
                  ></v-select>
                </v-flex>
              </v-layout>
            </v-container>
          </v-card-text>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn color="blue darken-1" flat @click.native="close">Cancel</v-btn>
            <v-btn color="blue darken-1" flat :disabled="!valid" @click.native="save">Save</v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
      </v-dialog>
    </v-toolbar>
    <v-data-table
      :headers="headers"
      :items="productTypes"
      hide-actions
      class="elevation-1"
    >
      <template slot="items" slot-scope="props">
        <td>{{ props.item.name }}</td>
        <td class="text-xs-left">{{ props.item.id }}</td>
        <td class="text-xs-left">
          <v-img
            v-if="props.item.info.image"
            :src="`${props.item.info.image}`"
            aspect-ratio="1"
            class="grey lighten-2"
          ></v-img>
        </td>
        <td class="text-xs-left">{{ props.item.info.desc }}</td>
        <td class="text-xs-center">{{ props.item.info.show }}</td>
        <td class="justify-center layout px-0">
          <v-icon
            small
            class="mr-2"
            @click="editItem(props.item)"
          >
            edit
          </v-icon>
        </td>
      </template>
    </v-data-table>
  </div>
</template>

<script>
  import api from '../api'
  import error from './Error.vue'
  export default {
    components: {
      error
    },
    data: () => ({
      dialog: false,
      requestError: false,
      valid: true,
      headers: [
        {
          text: 'Product Subcategory Name',
          align: 'left',
          sortable: false,
          value: 'name'
        },
        { text: 'ProductType Id', value: 'id' },
        { text: 'Image', value: 'image' },
        { text: 'Description', value: 'desc' },
        { text: 'Show in Website', value: 'show' },
        { text: 'Actions', value: 'name', sortable: false }
      ],
      productTypes: [],
      productTypeNameRules: [
        v => !!v || 'Product Type Name is required',
        v => (v && v.length <= 20) || 'This field must be less than 20 characters'
      ],
      productTypeDescRules: [
        v => !!v || 'Product Type Description is required',
        v => (v && v.length <= 100) || 'This field must be less than 100 characters'
      ],
      productTypeShowRules: [
        v => !!v || 'Atleast choose one choice'
      ],
      required: [
        v => !!v || 'This field is required'
      ],
      editedIndex: -1,
      editedItem: {
        name: '',
        id: null,
        desc: '',
        image: '',
        show: ''
      },
      defaultItem: {
        name: '',
        id: null,
        desc: '',
        image: '',
        show: ''
      },
      items: ['Yes', 'No']
    }),

    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'New Item' : 'Edit Item'
      }
    },

    watch: {
      dialog (val) {
        val || this.close()
      }
    },

    created () {
      this.getProductTypes()
    },

    methods: {
      getProductTypes () {
        // get all the product types by asking product id = 0
        api.get(`/graminharvest/api/1.0/productType/getproductTypes?productId=0`)
          .then(productTypes => {
            this.productTypes = productTypes.data
            console.log(this.productTypes)
          }).catch(error => {
            console.log(error)
            this.requestError = error
          })
      },

      editItem (item) {
        console.log(item)
        this.editedIndex = item.id
        this.editedItem.name = item.name
        this.editedItem.desc = item.info.desc
        this.editedItem.image = item.info.image
        this.editedItem.show = item.info.show
        this.dialog = true
      },
      close () {
        this.dialog = false
        setTimeout(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        }, 300)
      },

      save () {
        if (this.$refs.form.validate()) {
          if (this.editedIndex > -1) {
            let infoData = (Object.assign({}, this.editedItem))
            // prepare data for db
            let payload = {}
            payload.name = infoData.name
            delete infoData.name
            delete infoData.id
            payload.info = infoData
            payload.productTypeId = this.editedIndex

            api.post(`/graminharvest/api/1.0/productType/editproductType`, payload)
              .then(() => {
                console.log('Success')
                this.$router.go(0)
              }).catch(error => {
                console.log(error)
                this.requestError = error
              })
          } else {
            let infoData = (Object.assign({}, this.editedItem))
            // prepare data for db
            let payload = {}
            payload.name = infoData.name
            delete infoData.name
            payload.info = infoData
            payload.productTypeId = this.editedIndex

            api.post(`/graminharvest/api/1.0/productType/addproductType`, payload)
              .then(() => {
                console.log('Success')
                this.$router.go(0)
              }).catch(error => {
                console.log(error)
                this.requestError = error
              })
          }
          this.close()
        }
      }
    }
  }
</script>
