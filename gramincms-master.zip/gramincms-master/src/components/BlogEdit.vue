<template>
    <div>
      <error v-if='this.requestError' :requestError ="requestError"></error>
       <v-flex xs12>
        <v-btn color="primary"  :disabled="!valid" @click.native="saveBlogAsDraft">Save</v-btn>
        <v-container grid-list-md text-xs-center>
                <v-form ref="form" v-model="valid" lazy-validation>
                <v-flex xs12>
                    <v-text-field
                      v-model="blogName"
                      color="deep-purple"
                      label="Blog Name"
                      style="min-height: 96px"
                      :rules="nameRules"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                  <label>Description</label>
                  <v-textarea
                    solo
                    name="input-7-4"
                    color="deep-purple"
                    v-model="blogDescription" label="Description"
                    :rules="descRules"
                  ></v-textarea>
                </v-flex>
                <quill-editor v-model="content"
                        ref="myQuillEditor"
                        :options="editorOption"
                        >
                </quill-editor>
            </v-form>
        </v-container>
       </v-flex>
    </div>
</template>
<script>
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'
import { quillEditor } from 'vue-quill-editor'
import api from '../api'
import error from './Error.vue'
export default {
  components: {
    quillEditor,
    error
  },
  props: ['blogId'],
  data () {
    return {
      content: '',
      blogName: '',
      blogDescription: '',
      editorOption: {
      },
      nameRules: [
        v => !!v || ' This is required',
        v => (v && v.length <= 30) || 'Name must be less than 30 characters'
      ],
      descRules: [
        v => !!v || ' This is required',
        v => (v && v.length <= 100) || 'Name must be less than 100 characters'
      ],
      valid: true,
      requestError: false
    }
  },
  created () {
    this.getBlogData()
  },
  methods: {
    saveBlogAsDraft () {
      if (this.$refs.form.validate()) {
        let payload = Object.assign({}, {blogId: this.blogId}, {name: this.blogName}, {description: this.blogDescription}, {blogContent: this.content}, {info: {'show': 'No'}})
        api.post('/graminharvest/api/1.0/blog/editABlog', payload)
          .then((data) => {
            this.$router.push({name: 'Blogs'})
          })
      }
    },
    getBlogData () {
      api.get(`/graminharvest/api/1.0/blog/getAllBlogs?blogId=${this.blogId}`)
        .then((data) => {
          let blog = data.data
          this.content = blog.blogContent
          this.blogDescription = blog.description
          this.blogName = blog.name
        }).catch(error => {
          console.log(error)
          this.requestError = error
        })
    }
  }
}
</script>

