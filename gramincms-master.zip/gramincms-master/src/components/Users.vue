<template>
  <div>
    <v-data-table
      :headers="headers"
      :items="users "
      hide-actions
      class="elevation-1"
    >
      <template slot="items" slot-scope="props">
        <td class="text-xs-left">{{ props.item.id }}</td>
        <td class="text-xs-left">{{ props.item.name }}</td>
        <td><v-img
                  :src="`${props.item.picture}`"
                  aspect-ratio="2.6"
                  class="grey lighten-2"
                ></v-img></td>
        <td class="text-xs-right">{{ props.item.email}}</td>
        
      </template>
    </v-data-table>
  </div>
</template>

<script>
  import api from '../api'
  import error from './Error.vue'
  export default {
    components: {
      error
    },
    data: () => ({
      users: null,
      headers: [
        { text: 'User Id', value: 'userId' },
        { text: 'User Name', value: 'name' },
        { text: 'User Photo', value: 'userPhoto' },
        { text: 'User Email', value: 'email' }
      ]
    }),
    created () {
      this.getAllUsers()
    },

    methods: {
      getAllUsers () {
        api.get(`/graminharvest/api/1.0/user/web/allUsers`)
          .then((users) => {
            this.users = users.data
            this.user.forEach(u => {
              u.name = u.first_name + u.last_name
              console.log(u.name)
            })
          })
      }
    }
  }
</script> 