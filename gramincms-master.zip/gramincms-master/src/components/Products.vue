<template>
  <div>
    <error v-if='this.requestError' :requestError ="requestError"></error>
    <v-toolbar flat color="white">
      <v-toolbar-title>Products</v-toolbar-title>
      <v-divider
        class="mx-2"
        inset
        vertical
      ></v-divider>
      <v-spacer></v-spacer>
      <v-dialog v-model="dialog" max-width="500px">
        <v-btn slot="activator" color="primary" dark class="mb-2">New Item</v-btn>
         <v-form ref="form" v-model="valid" lazy-validation>
          <v-card>
          <v-card-title ref="form" v-model="valid" lazy-validation>
            <span class="headline">{{ formTitle }}</span>
          </v-card-title>
        
          <v-card-text >
            <v-container grid-list-md>
              <v-layout wrap >
                <v-flex xs12>
                    <v-text-field
                      v-model="editedItem.name"
                      color="deep-purple"
                      label="Product Name"
                      style="min-height: 96px"
                      :rules="productNameRules"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                  <label>Description</label>
                  <v-textarea
                    solo
                    name="input-7-4"
                    color="deep-purple"
                    v-model="editedItem.description" label="Description"
                    :rules="descRules"
                  ></v-textarea>
                </v-flex>
                 <v-flex xs12>
                    <v-text-field
                      v-model="editedItem.image"
                      color="deep-purple"
                      label="Product Image"
                      style="min-height: 96px"
                      :rules="descRules"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                    <v-text-field
                      v-model.number="editedItem.price"
                      color="deep-purple"
                      label="Item Price"
                      style="min-height: 96px"
                      :rules="productNumbersRules"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                    <v-text-field
                      v-model.number="editedItem.stock"
                      color="deep-purple"
                      label="Item in Stock"
                      style="min-height: 96px"
                      :rules="productNumbersRules"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                    <v-text-field
                      v-model="editedItem.paymentLink"
                      color="deep-purple"
                      label="Product Payment Link"
                      style="min-height: 96px"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                    <v-text-field
                      v-model.number="editedItem.discount"
                      color="deep-purple"
                      label="Product Disount"
                      style="min-height: 96px"
                      hint = "Provide 0 if No discount avaliable"
                      :rules="productNumbersRules"
                    ></v-text-field>
                </v-flex>
                <v-flex xs12>
                    <v-select
                  :items="discountType"
                  label="Product Discount Type"
                  v-model="editedItem.discountType"
                  :rules="productTypeShowRules"
                  ></v-select>
                </v-flex>
                <v-flex>
                  <v-select
                  :items="findProductTypeNames"
                  label="Product Category"
                  v-model="editedItem.productType"
                  :rules="productTypeShowRules"
                  ></v-select>
                </v-flex> 
                <v-flex>
                  <v-select
                  :items="items"
                  label="Show"
                  v-model="editedItem.show"
                  :rules="productTypeShowRules"
                  ></v-select>
                </v-flex> 
              </v-layout>
            </v-container>
          </v-card-text>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn color="blue darken-1" flat @click.native="close">Cancel</v-btn>
            <v-btn color="blue darken-1" flat :disabled="!valid" @click.native="save">Save</v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
      </v-dialog>
    </v-toolbar>
    <v-data-table
      :headers="headers"
      :items="products"
      hide-actions
      class="elevation-1"
    >
      <template slot="items" slot-scope="props">
        <td>{{ props.item.name }}</td>
        <td class="text-xs-left">{{ props.item.id }}</td>
        <td class="text-xs-left">{{ props.item.description }}</td>
        <td><v-img
                  :src="`${props.item.image}`"
                  aspect-ratio="1"
                  class="grey lighten-2"
                ></v-img></td>
        <td class="text-xs-center">{{ props.item.price}}</td>
        <td class="text-xs-center">{{ props.item.stock }}</td>
        <td class="text-xs-center">{{ props.item.productType}}</td>
        <td class="text-xs-center">{{ props.item.info.show|| 'No' }}</td>
        <td class="justify-center layout px-0">
          <v-icon
            small
            class="mr-2"
            @click="editItem(props.item)"
          >
            edit
          </v-icon>
        </td>
      </template>
    </v-data-table>
  </div>
</template>

<script>
  import api from '../api'
  import error from './Error.vue'
  export default {
    components: {
      error
    },
    data: () => ({
      dialog: false,
      requestError: false,
      valid: true,
      hint: null,
      headers: [
        {
          text: 'Product  Name',
          align: 'left',
          sortable: false,
          value: 'name'
        },
        { text: 'Product Id', value: 'id' },
        { text: 'Description', value: 'description' },
        { text: 'Image', value: 'image' },
        { text: 'Price', value: 'price' },
        { text: 'Stock', value: 'stock' },
        { text: 'Product Category', value: 'productType' },
        { text: 'Show in Website', value: 'show' },
        { text: 'Actions', value: 'name', sortable: false }
      ],
      products: [],
      productTypes: [],
      productNameRules: [
        v => !!v || 'Product Type Name is required',
        v => (v && v.length <= 20) || 'This field can not be more than 20 characters'
      ],
      descRules: [
        v => !!v || 'This field is required',
        v => (v && v.length <= 100) || 'This field can not be more than 100 characters'
      ],
      productTypeShowRules: [
        v => !!v || 'Atleast choose one choice'
      ],
      productNumbersRules: [
        v => !!v || 'This field is a required field',
        v => (v && typeof (v) === 'number') || 'This field accepts a number'
      ],
  
      editedIndex: -1,
      editedItem: {
        name: '',
        id: null,
        description: '',
        image: '',
        price: null,
        stock: null,
        productType: null,
        show: '',
        discount: null,
        discountType: '',
        paymentLink: ''
  
      },
      defaultItem: {
        name: '',
        id: null,
        desc: '',
        show: ''
      },
      items: ['Yes', 'No'],
      discountType: ['Percentage', 'RS']
    }),
  
    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'New Item' : 'Edit Item'
      },
      findProductTypeNames () {
        return this.productTypes.map(prot => prot.name)
      },
      paymentGatewayPrice () {
        if (this.editedItem.discount === 'Percentage') {
          this.hint = (this.editedItem.price) - (this.editedItem.price * (this.editedItem.discount * 0.01))
        } else this.hint = (this.editedItem.price - this.editedItem.discount)
      }
    },

    watch: {
      dialog (val) {
        val || this.close()
      }
    },

    created () {
      this.getProducts()
    },

    methods: {
      getProducts () {
        // get all the products by asking product id = 0
        Promise.all([
          api.get(`/graminharvest/api/1.0/productType/getproductTypes?productId=0`),
          api.get(`/graminharvest/api/1.0/product/getAllProducts?productId=0`)
        ])
          .then(([productTypes, products]) => {
            products.data.forEach(pr => {
              productTypes.data.forEach(prot => {
                if (pr.productType === prot.id) {
                  pr.productType = prot.name
                }
              })
            })
            this.products = products.data
            this.productTypes = productTypes.data
          }).catch(error => {
            console.log(error)
            this.requestError = error
          })
      },

      editItem (item) {
        console.log(item)
        console.log(this.editedItem)
        this.editedIndex = item.id
        this.editedItem.name = item.name
        this.editedItem.description = item.description
        this.editedItem.image = item.image
        this.editedItem.price = item.price
        this.editedItem.stock = item.stock
        this.editedItem.productType = item.productType
        this.editedItem.show = item.info.show || 'No'
        this.editedItem.discount = item.discount
        this.editedItem.discountType = item.discountType
        this.editedItem.paymentLink = item.paymentLink
        this.dialog = true
      },
      close () {
        this.dialog = false
        setTimeout(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        }, 300)
      },

      save () {
        if (this.$refs.form.validate()) {
          console.log(this.editedItem, 'editedindex')
          if (this.editedIndex > -1) {
            // prepare data for db
            let payload = {}
            let tempProductType = this.editedItem.productType
            delete this.editedItem.productType
            // find product id of this product
            let desiredProductType = this.productTypes.find(pt => pt.name === tempProductType)
  
            payload.productType = desiredProductType.id
  
            Object.assign(payload, this.editedItem)
            console.log(payload, 'payload')
            payload.productId = this.editedIndex
            payload.info = Object.assign({}, {show: this.editedItem.show})
            console.log(payload, 'payload')
            api.post(`/graminharvest/api/1.0/product/editProduct`, payload)
              .then(() => {
                console.log('Success')
                this.$router.go(0)
              }).catch(error => {
                console.log(error)
                this.requestError = error
              })
          } else {
            let payload = {}
            let tempProductType = this.editedItem.productType
            delete this.editedItem.productType
            // find product id of this product
            let desiredProductType = this.productTypes.find(pt => pt.name === tempProductType)
  
            payload.productType = desiredProductType.id
  
            Object.assign(payload, this.editedItem)
            console.log(payload, 'payload')
            payload.info = Object.assign({}, {show: this.editedItem.show})
            console.log(payload, 'payload')
  
            api.post(`/graminharvest/api/1.0/product/addproduct`, payload)
              .then(() => {
                console.log('Success')
                this.$router.go(0)
              }).catch(error => {
                console.log(error)
                this.requestError = error
              })
          }
          this.close()
        }
      }

    }
  }
</script> 