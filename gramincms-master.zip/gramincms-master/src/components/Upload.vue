<template>
  <div>
    <error v-if='this.requestError' :requestError ="requestError"></error>
    <v-toolbar flat color="white">
      <v-toolbar-title>Upload</v-toolbar-title>
      <v-divider
        class="mx-2"
        inset
        vertical
      ></v-divider>
      <v-spacer></v-spacer>
    </v-toolbar>
     <form enctype="multipart/form-data" novalidate v-if="isInitial || isSaving">
        <h1>Upload images</h1>
        <div class="dropbox">
          <input type="file" multiple  :name="uploadFieldName" :disabled="isSaving" @change="filesChange($event.target.name, $event.target.files)" accept="image/*" class="input-file">
            <p v-if="isInitial">
              Drag your file(s) here to begin<br> or click to browse
            </p>
            <p v-if="isSaving">
              Uploading {{ fileCount }} files...
            </p>
        </div>
      </form>
      <!--SUCCESS-->
      <div v-if="isSuccess">
        <h2>Uploaded {{ uploadedFiles.length }} file(s) successfully.</h2>
        <p>
          <a href="javascript:void(0)" @click="reset()">Upload again</a>
        </p>
      </div>
      <!--Failed-->
      <div v-if="isFailed">
        <h2>Uploaded failed.</h2>
        <p>
          <a href="javascript:void(0)" @click="reset()">Try again</a>
        </p>
        <pre>{{ uploadError }}</pre>
      </div>
      
    <v-data-table
      :headers="headers"
      :items="images"
      hide-actions
      class="elevation-1"
    >
      <template slot="items" slot-scope="props">
        <td class="text-xs-left">{{ props.item.id }}</td>
        <td><v-img
                  :src="`${props.item.imageLinks}`"
                  aspect-ratio="2.6"
                  class="grey lighten-2"
                ></v-img></td>
        <td class="justify-right layout px-0">
          <v-btn color="info"
           v-clipboard:copy="props.item.imageLinks"
            v-clipboard:success="onCopy"
            v-clipboard:error="onError"
          >Copy Link</v-btn>
        </td>
        <td class="justify-right layout px-0">
          <v-btn color="error"
          @click="deletePhoto(props.item.id)"
          >Delete</v-btn>
        </td>
      </template>
    </v-data-table>
     <v-snackbar
      v-model="snackbar"
      :multi-line="mode === 'multi-line'"
      :timeout="timeout"
 
    >
      {{ text }}
      <v-btn
        color="pink"
        flat
        @click="snackbar = false"
      >
        Close
      </v-btn>
    </v-snackbar>
  </div>
</template>

<script>
  import api from '../api'
  import {upload} from '../file-upload.js'
  import Vue from 'vue'
  import VueClipboard from 'vue-clipboard2'
  import error from './Error.vue'
  
  Vue.use(VueClipboard)
  const STATUS_INITIAL = 0
  const STATUS_SAVING = 1
  const STATUS_SUCCESS = 2
  const STATUS_FAILED = 3

  export default {
    components: {
      error
    },
    data: () => ({
      headers: [
        { text: 'Image Id', value: 'id' },
        { text: 'Image', value: 'imageLinks' },
        { text: 'Actions', value: 'copy', sortable: false }
      ],
      mode: null,
      requestError: false,
      timeout: null,
      text: null,
      uploadedFiles: [],
      uploadError: null,
      currentStatus: null,
      uploadFieldName: 'photos',
      images: [],
      message: 'Copy Link',
      snackbar: false
    }),
  
    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'New Item' : 'Edit Item'
      },
      isInitial () {
        return this.currentStatus === STATUS_INITIAL
      },
      isSaving () {
        return this.currentStatus === STATUS_SAVING
      },
      isSuccess () {
        return this.currentStatus === STATUS_SUCCESS
      },
      isFailed () {
        return this.currentStatus === STATUS_FAILED
      }

    },
    created () {
      this.getUploadedImageLists()
    },

    methods: {
      deletePhoto (photoId) {
        api.post(`/graminharvest/api/1.0/aws/deletePhoto`, {id: photoId})
          .then(() => {
            this.$router.go(0)
          })
      },
      getUploadedImageLists () {
        api.get(`/graminharvest/api/1.0/aws/getUploadedImageLinks`)
          .then((links) => {
            this.images = links.data
          }).catch(error => {
            console.log(error)
            this.requestError = error
          })
      },
      reset () {
      // reset form to initial state
        this.currentStatus = STATUS_INITIAL
        this.uploadedFiles = []
        this.uploadError = null
      },
      save (formData) {
      // upload data to the server
        this.currentStatus = STATUS_SAVING
        upload(formData)
          .then(x => {
            this.uploadedFiles = [].concat(x)
            console.log(this.uploadedFiles)
            this.currentStatus = STATUS_SUCCESS
            this.$router.go(0)
          })
          .catch(err => {
            this.uploadError = err.response
            this.currentStatus = STATUS_FAILED
          })
      },
      filesChange (fieldName, fileList) {
      // handle file changes
        const formData = new FormData()

        if (!fileList.length) return

        // append the files to FormData
        Array
          .from(Array(fileList.length).keys())
          .map(x => {
            formData.append(fieldName, fileList[x], fileList[x].name)
          })

        // save it
        this.save(formData)
      },
      onCopy: function (e) {
        this.text = 'you just copied:  ' + e.text
        this.snackbar = true
      },
      onError: function (e) {
        alert('Failed to copy texts')
      }
    },
    mounted () {
      this.reset()
    }

}
</script>
<!-- SASS styling -->
<style lang="scss" scoped>
  .dropbox {
    outline: 2px dashed grey; /* the dash box */
    outline-offset: -10px;
    background: lightcyan;
    color: dimgray;
    padding: 10px 10px;
    min-height: 200px; /* minimum height */
    position: relative;
    cursor: pointer;
  }

  .input-file {
    opacity: 0; /* invisible but it's there! */
    width: 100%;
    height: 200px;
    position: absolute;
    cursor: pointer;
  }

  .dropbox:hover {
    background: lightblue; /* when mouse over to the drop zone, change color */
  }

  .dropbox p {
    font-size: 1.2em;
    text-align: center;
    padding: 50px 0;
  }
</style>
