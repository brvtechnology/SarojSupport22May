<template>
  <v-app id="inspire">
    <v-navigation-drawer
      v-model="drawer"
      fixed
      app
      v-if="showNavbar()"
    >
      <v-list large>
        <v-list-tile to = '/'>
          <v-list-tile-action>
            <v-icon>home</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title>Home</v-list-tile-title>
          </v-list-tile-content>  
        </v-list-tile>
      </v-list>
      <v-list large v-for="item in items" :key="item.id">
        <v-list-tile :to="item.route">
          <v-list-tile-action>
            <v-icon>list</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title>{{item.name}}</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>
      </v-list>
      <v-btn color='red' class='logout' @click="logout" dark>Logout</v-btn>
    </v-navigation-drawer>
    <v-toolbar color="blue" dark fixed app v-if="showToolbar()">
      <v-toolbar-side-icon @click.stop="drawer = !drawer"></v-toolbar-side-icon>
      <v-toolbar-title>Gramin CMS</v-toolbar-title>
    </v-toolbar>
    <v-content>
    <router-view></router-view>
    </v-content>
    <v-footer color="indigo" app v-if="showFooter()">
      <span class="white--text">&copy; 2017</span>
    </v-footer>
  </v-app>
</template>

<script>
import Vue from 'vue'
import Router from 'vue-router'
import * as Cookies from 'js-cookie'

Vue.use(Router)

export default {
  data: () => ({
    drawer: null,
    items: [
      {
        id: 1,
        name: 'Product Types',
        route: '/producttypes'
      },
      {
        id: 2,
        name: 'Products',
        route: '/products'
      },
      {
        id: 3,
        name: 'Upload',
        route: '/upload'
      },
      {
        id: 4,
        name: 'Gallery',
        route: '/gallery'
      },
      {
        id: 5,
        name: 'Blogs',
        route: '/blogs'
      },
      {
        id: 6,
        name: 'Users',
        route: '/users'
      },
      {
        id: 7,
        name: 'Order History',
        route: '/orderhistory'
      },
      {
        id: 8,
        name: 'Coupons',
        route: '/coupons'
      }
    ]
  }),

  props: {
    source: String
  },
  methods: {
    showNavbar () {
      if (this.$route.meta.hideNavbar) {
        return false
      }
      return true
    },
    showToolbar () {
      if (this.$route.meta.hideToolbar) {
        return false
      }
      return true
    },
    showFooter () {
      if (this.$route.meta.hideFooter) {
        return false
      }
      return true
    },
    logout () {
      Cookies.remove('token')
      Cookies.remove('user')
      this.$router.push('/')
      this.$router.go(0)
    }
  }
}
</script>

<style>
body {
  margin: 0;
}

#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  max-block-size: 50%
}

main {
  text-align: center;
  margin-top: 40px;
}

header {
  margin: 0;
  height: 56px;
  padding: 0 16px 0 24px;
  background-color: #35495E;
  color: #ffffff;
}

header span {
  display: block;
  position: relative;
  font-size: 20px;
  line-height: 1;
  letter-spacing: .02em;
  font-weight: 400;
  box-sizing: border-box;
  padding-top: 16px;
}

.cursor--link {
  cursor: pointer;
}

.logout {
  margin-left: 40px;
  margin-top: 60px;
}
</style>
